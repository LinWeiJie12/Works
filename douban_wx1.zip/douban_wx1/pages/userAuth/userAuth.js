// pages/userAuth/userAuth.js
//获取应用实例
const app = getApp();


Page({
   

  /**
   * 页面的初始数据
   */
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 判断全局数据仓库中是否存在userInfo
    if (app.globalData.userInfo) {
      //设置页面状态方法
      this.setData({
        //将全局数据仓库中的用户信息，设置给页面中的userInfo状态数据
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })

      //情况1，发生跳转
      this.goIndex();

    } else if (this.data.canIUse) {
      console.log("canIUse为true,可以使用，接下来往app应用中注册相关userInfoReadyCallback！");
      // 由于 getUserInfo 是网络请求(异步)，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况

      // 在app实例中注册 userInfoReadyCallback(方法/行为)
      // app.userInfoReadyCallback
      app.uirc = res => {

        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })

        //情况2，发生跳转
        this.goIndex();
      }

    } else {

      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })

          //情况3，发生跳转
          this.goIndex();
        }
      })

    }

  },

  //授权成功跳转到首页！
  goIndex() {
    // wx.redirectTo({
    //   url: '../index/index'
    // });
    wx.switchTab({
      url: '../index/index',
    });
  },
    //授权成功跳转到首页！
  
  //获取用户信息的回调函数
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })

   this.goIndex();

  },



})