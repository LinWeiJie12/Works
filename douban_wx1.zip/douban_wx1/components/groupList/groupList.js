// //内容列表组件

// // const {
// //   canvasTool,
// //   config
// // } = require("../../utils/index");

// Component({
//   /**
//    * 组件的属性列表
//    */
//   properties: {
//     //接口地址
//     url: {
//       type: String,
//       value: ''
//     }
//   },

//   /**
//    * 组件的初始数据
//    */
//   data: {
//     title:"",
//     list:[]
//   },

//   /**
//    * 组件的方法列表
//    */
//   methods: {
    
//     //请求服务器，加载数据
//     intData() {
//       let reqTask = wx.request({
//         url: `${config.serverUrl}/${this.data.url}`,
//         data: {},
//         method: 'get',
//         dataType: 'json',
//         success: (result) => {
         

//           this.setData({
//             title: result.data.subject_collection_items[0].cover.booktitle,
//             list: result.data.subject_collection_items
//           });

//           console.log(this.data.title);
//           console.log(this.data.list);

//         },
//         fail: () => {},
//         complete: () => {}
//       });
//     }
//   },
//   lifetimes: {
//     ready() {
//       this.intData();
//     },
//     detached() {
//       // 在组件实例被从页面节点树移除时执行
//     },
//   }
// })