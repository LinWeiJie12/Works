// components/searchGoods/searchGoods.js
const {
  canvasTool,
  config
} = require("../../utils/index");


Component({
  /**
   * 组件的属性列表
   */
  properties: {
    //接口地址
    url: {
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    title: "",
    list: [],
    //颜色列表
    themeList:[
      "red",
      "green",
      "#3463d9",
      "#d79d1a",
      "#4F9DED",
      "#FF4055",
      "#3BA94D"
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {
    initData(){
      //
      // console.log(Math.floor(Math.random() * 7));
      // console.log(this.data.themeList[Math.floor(Math.random() * 7)]);

      if (this.data.url==""){
        return;
      }

      wx.request({
        url: `${config.serverUrl}/${this.data.url}`,
        data: {},
        method: 'get',
        dataType: 'json',
        success: (result) => {
          let list =result.data.list;
          for(let i=0;i<list.length;i++){
            list[i].color = this.data.themeList[Math.floor(Math.random() * 7)];
          }
          console.log(list);

          this.setData({
            title: result.data.title,
            list: result.data.list
          });

        },
        fail: () => { },
        complete: () => { }
      });
    }

  },
  lifetimes: {
    ready() {
      this.initData();
    },
    detached() {
      // 在组件实例被从页面节点树移除时执行
    },
  }
})
