const appTools = {};
appTools.canvasTool = require("canvasTool.js");
appTools.config = require("config.js");
appTools.util = require("util.js");

module.exports = appTools;