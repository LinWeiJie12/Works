//项目中的配置文件模块
const baseSettingMap = {
    serverUrl: "http://localhost:3006/api"
  };
  
  module.exports = baseSettingMap;