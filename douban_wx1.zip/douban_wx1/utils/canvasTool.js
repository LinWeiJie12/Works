// 全局模块中的画图工具模块

const modObj = {
    //画圆方法
    drawCircle() {
        console.log("画圆！");
    }
};


//通过 module.exports 导出模块接口
module.exports = modObj;
