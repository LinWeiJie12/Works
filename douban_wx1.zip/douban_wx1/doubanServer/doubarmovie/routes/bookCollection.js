//API接口：畅销书接口
//接口如下：
// -最受关注的虚构类图书


module.exports = (apiRouter) => {
    //接口：最受关注的虚构类图书
    apiRouter.get("/book_fiction", (req, res, next) => {
        res.send({
            "count": 8,
            "start": 0,
            "subject_collection_items": [{
                "original_price": null,
                "rating": {
                    "count": 299,
                    "max": 10,
                    "value": 9.2
                },
                "actions": [],
                "date": null,
                "year": ["2019-11"],
                "card_subtitle": "\u80e1\u8fc1 \/ 2019 \/ \u8bd1\u6797\u51fa\u7248\u793e",
                "recommend_comment": "\u62cd\u7535\u5f71\u65f6\uff0c\u4ed6\u53eb\u80e1\u6ce2\uff1b\u5199\u5c0f\u8bf4\u65f6\uff0c\u4ed6\u53eb\u80e1\u8fc1\u3002 \u2014\u2014 Mm\u840cmM\u7684\u77ed\u8bc4",
                "id": "34866400",
                "title": "\u5927\u8c61\u5e2d\u5730\u800c\u5750",
                "wish_count": 5020,
                "label": null,
                "interest": null,
                "type": "book",
                "onsale": true,
                "description": "",
                "price": null,
                "press": ["\u8bd1\u6797\u51fa\u7248\u793e"],
                "info": "\u80e1\u8fc1\/\u8bd1\u6797\u51fa\u7248\u793e\/2019-11",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/book\/34866400",
                "release_date": null,
                "author": ["\u80e1\u8fc1"],
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/subject\/l\/public\/s33516881.jpg",
                    "width": 0,
                    "shape": "rectangle",
                    "height": 0
                },
                "uri": "douban:\/\/douban.com\/book\/34866400",
                "subtype": "",
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 69,
                    "max": 10,
                    "value": 9.2
                },
                "actions": [],
                "date": null,
                "year": ["2019-11"],
                "card_subtitle": "[\u6ce2\u5170] \u626c\u00b7\u6ce2\u6258\u8328\u57fa Jean Potocki \/ 2019 \/ \u6d66\u777f\u6587\u5316\u00b7\u6e56\u5357\u6587\u827a\u51fa\u7248\u793e",
                "recommend_comment": "\u9163\u7545\u6dcb\u6f13\uff01 \u2014\u2014 noodles\u7684\u77ed\u8bc4",
                "id": "34808267",
                "title": "\u8428\u62c9\u6208\u8428\u624b\u7a3f",
                "wish_count": 5198,
                "label": null,
                "interest": null,
                "type": "book",
                "onsale": true,
                "description": "",
                "price": null,
                "press": ["\u6d66\u777f\u6587\u5316\u00b7\u6e56\u5357\u6587\u827a\u51fa\u7248\u793e"],
                "info": "[\u6ce2\u5170] \u626c\u00b7\u6ce2\u6258\u8328\u57fa\/Jean Potocki\/\u6d66\u777f\u6587\u5316\u00b7\u6e56\u5357\u6587\u827a\u51fa\u7248\u793e\/2019-11",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/book\/34808267",
                "release_date": null,
                "author": ["[\u6ce2\u5170] \u626c\u00b7\u6ce2\u6258\u8328\u57fa"],
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/subject\/l\/public\/s33492042.jpg",
                    "width": 0,
                    "shape": "rectangle",
                    "height": 0
                },
                "uri": "douban:\/\/douban.com\/book\/34808267",
                "subtype": "",
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 125,
                    "max": 10,
                    "value": 9.3
                },
                "actions": [],
                "date": null,
                "year": ["2019-10"],
                "card_subtitle": "\u7ae5\u4f1f\u683c \/ 2019 \/ \u540e\u6d6a\u4e28\u56db\u5ddd\u4eba\u6c11\u51fa\u7248\u793e",
                "recommend_comment": "\u4f60\u5f97\u8981\u591f\u8fbd\u9614\u624d\u80fd\u591f\u6df1\u9083\uff0c\u300a\u897f\u5317\u96e8\u300b\u5c31\u662f\u8fd9\u6837\u3002\u50cf\u5927\u5730\u5438\u6536\u4e86\u6cea\u6c34\uff0c\u4ee5\u4e00\u79cd\u201c\u5c06\u6b7b\u4e4b\u4eba\u201d\u7279\u6709\u7684\u8fbd\u9614\uff0c\u7a7f\u5165\u5730\u5fc3\uff0c\u62b5\u8fbe\u6587\u5b66\u7684\u5fc3\u810f\uff1a\u4e00\u79cd\u590d\u6742\u65e0\u6bd4\u7684\u5584\u826f\u3002\u2014\u2014\u53f0\u6e7e\u5c0f\u8bf4\u5bb6 \u80e1\u6dd1\u96ef \u2014\u2014 \u540e\u6d6a\u7684\u77ed\u8bc4",
                "id": "34835536",
                "title": "\u897f\u5317\u96e8",
                "wish_count": 3390,
                "label": null,
                "interest": null,
                "type": "book",
                "onsale": true,
                "description": "",
                "price": null,
                "press": ["\u540e\u6d6a\u4e28\u56db\u5ddd\u4eba\u6c11\u51fa\u7248\u793e"],
                "info": "\u7ae5\u4f1f\u683c\/\u540e\u6d6a\u4e28\u56db\u5ddd\u4eba\u6c11\u51fa\u7248\u793e\/2019-10",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/book\/34835536",
                "release_date": null,
                "author": ["\u7ae5\u4f1f\u683c"],
                "cover": {
                    "url": "https://img1.doubanio.com\/view\/subject\/l\/public\/s33486117.jpg",
                    "width": 0,
                    "shape": "rectangle",
                    "height": 0
                },
                "uri": "douban:\/\/douban.com\/book\/34835536",
                "subtype": "",
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 128,
                    "max": 10,
                    "value": 9.4
                },
                "actions": [],
                "date": null,
                "year": ["2019-11"],
                "card_subtitle": "[\u7f8e] \u7279\u5fb7\u00b7\u59dc \/ 2019 \/ \u8bd1\u6797\u51fa\u7248\u793e",
                "recommend_comment": "\u53ea\u8bb2\u65b0\u589e\u56db\u7bc7\u3002\u300a\u5927\u5bc2\u9759\u300b\u51e0\u5e74\u524d\u5c31\u8bfb\u8fc7\uff0c\u867d\u4ece\u540e\u8bb0\u5f97\u77e5\u4e66\u5199\u521d\u8877\u5e76\u975e\u8fd9\u6837\uff0c\u4f46\u5149\u4ece\u5b87\u5b99\u5fae\u6ce2\u80cc\u666f\u8f90\u5c04\u5230\u4e9a\u9a6c\u900a\u68ee\u6797\u9e66\u9e49\u9e23\u53eb\u7684\u8de8\u5ea6\uff0c\u60f3\u8c61\u8eab\u8fb9\u719f\u77e5\u751f\u7269\u7684\u964c\u751f\u79d8\u5bc6\u3001\u591a\u667a\u6167\u751f\u547d\u5171\u5b58\u7684\u610f\u4e49\u5c31\u6fc0\u52a8\u5f97\u8981\u547d\u3002\u300a\u53cc\u9762\u771f\u76f8\u300b\u6700\u63a5\u8fd1\u4f5c\u8005\u4e00\u8d2f\u98ce\u683c\uff0c\u53cc\u7ebf\u5bf9\u7167\uff0c\u601d\u8fa8\u3002\u53e3\u8ff0\u5230\u4e66\u9762\u5230\u7b97\u6cd5\u8bb0\u5fc6\u53d6\u4ee3\u56de\u5fc6\uff0c\u81ea\u8fc7\u53bb\u63a8\u60f3\u51fa\u672a\u6765\uff0c\u5f88\u6709\u70b9\u300a\u8d4f\u5fc3\u60a6\u76ee\u300b\u3002\u300a\u8110\u300b\u4ee4\u4eba\u627e\u56de\u521d\u8bfb\u300a\u5df4\u6bd4\u4f26\u5854\u300b\u6216\u300a\u5730\u72f1\u662f\u4e0a\u5e1d\u4e0d\u5728\u4e4b\u5904\u300b\u90a3\u79cd\u5bf9\u795e\u79d8\u6e90\u5934\u56de\u6eaf\u7684\u60ac\u7591\u53ca\u5bf9\u4fe1\u4ef0\u906d\u5230\u8d28\u7591\u7684\u6e38\u79fb\uff0c\u6ca1\u6709\u809a\u8110\u7684\u6700\u521d\u4e4b\u4eba\u548c\u6ca1\u6709\u5e74\u8f6e\u7684\u6700\u521d\u4e4b\u6811\uff0c\u4ee5\u592a\u5b87\u5b99\u4e2d\u552f\u4e00\u9759\u6b62\u7684\u884c\u661f\uff0c\u7531\u6b64\u5f15\u53d1\u7684\u8fde\u9501\u53cd\u5e94\u76f8\u5f53\u51fa\u5f69\u3002\u300a\u7126\u8651\u662f\u81ea\u7531\u5f15\u8d77\u7684\u7729\u6655\u300b\u662f\u628a\u4eba\u4eec\u4ee5\u4e3a\u4e0d\u8fc7\u5982\u6b64\u7684\u5e73\u884c\u4e16\u754c\u5199\u5230\u5f15\u8d77\u4eba\u4eec\u6000\u7591\u4e00\u5207\u4e0d\u90a3\u4e48\u7b80\u5355\u7684\u7a0b\u5ea6\uff0c\u5e76\u7ec8\u4e8e\u60f3\u8d77\uff0c\u5c3d\u7ba1\u6709\u65f6\u8fc7\u4e8e\u7ec6\u817b\u7684\u6982\u5ff5\u6f14\u7ece\u8ba9\u4ed6\u50cf\u4e2a\u5b66\u8005\uff0c\u4f46\u7279\u5fb7\u59dc\u786e\u5b9e\u662f\u975e\u5e38\u51fa\u8272\u7684SF\u5c0f\u8bf4\u5bb6\u3002 \u2014\u2014 \u4eb2\u7231\u7684\u7325\u7410\u732a\u7684\u77ed\u8bc4",
                "id": "34672176",
                "title": "\u547c\u5438",
                "wish_count": 3275,
                "label": null,
                "interest": null,
                "type": "book",
                "onsale": true,
                "description": "",
                "price": null,
                "press": ["\u8bd1\u6797\u51fa\u7248\u793e"],
                "info": "[\u7f8e] \u7279\u5fb7\u00b7\u59dc\/\u8bd1\u6797\u51fa\u7248\u793e\/2019-11",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/book\/34672176",
                "release_date": null,
                "author": ["[\u7f8e] \u7279\u5fb7\u00b7\u59dc"],
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/subject\/l\/public\/s33516832.jpg",
                    "width": 0,
                    "shape": "rectangle",
                    "height": 0
                },
                "uri": "douban:\/\/douban.com\/book\/34672176",
                "subtype": "",
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 117,
                    "max": 10,
                    "value": 8.5
                },
                "actions": [],
                "date": null,
                "year": ["2019-11"],
                "card_subtitle": "\u4e03\u6708 \/ 2019 \/ \u4eba\u6c11\u6587\u5b66\u51fa\u7248\u793e",
                "recommend_comment": "\u6ca1\u60f3\u5230\u5c0f\u8bf4\u4ece\u5199\u5b8c\u5230\u51fa\u7248\u5c45\u7136\u8fc7\u53bb\u4e86\u4e09\u5e74\uff0c\u4e09\u5e74\u65f6\u95f4\u53d1\u751f\u4e86\u5f88\u591a\u4e8b\u60c5\uff1a\u6211\u56de\u5230\u6210\u90fd\u4ece\u5f85\u4e1a\u5230\u4e0a\u73ed\u518d\u5230\u8f9e\u804c\u5168\u804c\u5199\u4f5c\uff1bP\u793e\u53d1\u5e03\u4e86\u6e38\u620f\u300a\u7fa4\u661f\u300b\u5bb3\u6211\u5dee\u70b9\u60f3\u6539\u5c0f\u8bf4\u540d\uff1b\u8f9e\u804c\u4e24\u5e74\u95f4\u53c8\u5199\u4e86\u767e\u4e07\u5b57\uff1b\u5c31\u5728\u5c0f\u8bf4\u51fa\u7248\u524d\u5915\u751f\u4e86\u5c0f\u5b9d\u5b9d\uff1b\u5c0f\u8bf4\u4e2d\u7684\u5173\u952e\u8bbe\u65bdF\u00b7A\u00b7S\u00b7T\u4ece\u5f53\u5e74\u5efa\u8bbe\u4e2d\u5230\u73b0\u5728\u5df2\u7ecf\u542f\u7528\u4e24\u5e74\uff1b\u6211\u6ce8\u9500\u4e86\u8c46\u74e3\u5e10\u53f7\uff0c\u53c8\u91cd\u65b0\u6ce8\u518c\u2026\u2026\u4e09\u5e74\u4e4b\u540e\u518d\u8bfb\u81ea\u5df1\u8fd9\u7bc7\u5c0f\u8bf4\uff0c\u8fd8\u662f\u86ee\u559c\u6b22\u548c\u4e3a\u4e4b\u81ea\u8c6a\u7684\uff0c\u4e5f\u5e0c\u671b\u5927\u5bb6\u80fd\u559c\u6b22\u3002 \u2014\u2014 \u4e4c\u62c9\u62c9\u7684\u77ed\u8bc4",
                "id": "34841937",
                "title": "\u7fa4\u661f",
                "wish_count": 2899,
                "label": null,
                "interest": null,
                "type": "book",
                "onsale": true,
                "description": "",
                "price": null,
                "press": ["\u4eba\u6c11\u6587\u5b66\u51fa\u7248\u793e"],
                "info": "\u4e03\u6708\/\u4eba\u6c11\u6587\u5b66\u51fa\u7248\u793e\/2019-11",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/book\/34841937",
                "release_date": null,
                "author": ["\u4e03\u6708"],
                "cover": {
                    "url": "https://img1.doubanio.com\/view\/subject\/l\/public\/s33490619.jpg",
                    "width": 0,
                    "shape": "rectangle",
                    "height": 0
                },
                "uri": "douban:\/\/douban.com\/book\/34841937",
                "subtype": "",
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 1964,
                    "max": 10,
                    "value": 8.7
                },
                "actions": [],
                "date": null,
                "year": ["2019-10-1"],
                "card_subtitle": "[\u65e5]\u5c0f\u6797\u6cf0\u4e09 \/ 2019 \/ \u5317\u4eac\u65f6\u4ee3\u534e\u6587\u4e66\u5c40",
                "recommend_comment": "\u94bb\u77f3\u4e00\u6837\u786c\u7684\u79d1\u5e7b\u4f5c\u54c1\u3002\n\u795e\u7ecf\u79d1\u5b66+\u65f6\u95f4\u65c5\u884c+\u91cf\u5b50\u529b\u5b66\uff0c\u51e0\u5927\u6700\u592f\u7684\u5143\u7d20\u7ed3\u5408\u5728\u4e00\u8d77\uff0c\u6210\u5c31\u4e86\u8fd9\u4e00\u90e8\u7ecf\u5178\u3002\n\u53d9\u8ff0\u7684\u53e3\u543b\u4e5f\u5f88\u6709\u65e5\u5f0f\u79c1\u5c0f\u8bf4\u7684\u98ce\u91c7\uff0c\u76f8\u5f53\u6709\u98ce\u5473\u3002 \u2014\u2014 tiiiiiiiiin\u7684\u77ed\u8bc4",
                "id": "30359030",
                "title": "\u9189\u6b65\u7537",
                "wish_count": 6339,
                "label": null,
                "interest": null,
                "type": "book",
                "onsale": true,
                "description": "",
                "price": null,
                "press": ["\u5317\u4eac\u65f6\u4ee3\u534e\u6587\u4e66\u5c40"],
                "info": "[\u65e5]\u5c0f\u6797\u6cf0\u4e09\/\u5317\u4eac\u65f6\u4ee3\u534e\u6587\u4e66\u5c40\/2019-10-1",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/book\/30359030",
                "release_date": null,
                "author": ["[\u65e5]\u5c0f\u6797\u6cf0\u4e09"],
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/subject\/l\/public\/s33499480.jpg",
                    "width": 0,
                    "shape": "rectangle",
                    "height": 0
                },
                "uri": "douban:\/\/douban.com\/book\/30359030",
                "subtype": "",
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 112,
                    "max": 10,
                    "value": 7.7
                },
                "actions": [],
                "date": null,
                "year": ["2019-10"],
                "card_subtitle": "\u674e\u5510 \/ 2019 \/ \u5317\u4eac\u51fa\u7248\u96c6\u56e2\u00b7\u5317\u4eac\u5341\u6708\u6587\u827a\u51fa\u7248\u793e",
                "recommend_comment": "\u8bfb\u7684\u8fc7\u7a0b\u4e2d\u65f6\u5e38\u4f1a\u60f3\u5230\u9ec4\u9526\u6811\u7684\u300a\u96e8\u300b \u2014\u2014 \u84dd\u5f00\u590f\u7684\u77ed\u8bc4",
                "id": "34856420",
                "title": "\u70ed\u5e26",
                "wish_count": 2558,
                "label": null,
                "interest": null,
                "type": "book",
                "onsale": true,
                "description": "",
                "price": null,
                "press": ["\u5317\u4eac\u51fa\u7248\u96c6\u56e2\u00b7\u5317\u4eac\u5341\u6708\u6587\u827a\u51fa\u7248\u793e"],
                "info": "\u674e\u5510\/\u5317\u4eac\u51fa\u7248\u96c6\u56e2\u00b7\u5317\u4eac\u5341\u6708\u6587\u827a\u51fa\u7248\u793e\/2019-10",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/book\/34856420",
                "release_date": null,
                "author": ["\u674e\u5510"],
                "cover": {
                    "url": "https://img1.doubanio.com\/view\/subject\/l\/public\/s33499829.jpg",
                    "width": 0,
                    "shape": "rectangle",
                    "height": 0
                },
                "uri": "douban:\/\/douban.com\/book\/34856420",
                "subtype": "",
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 120,
                    "max": 10,
                    "value": 8.1
                },
                "actions": [],
                "date": null,
                "year": ["2019-11"],
                "card_subtitle": "\u5f20\u7f9e \/ 2019 \/ \u540e\u6d6a\u4e28\u56db\u5ddd\u6587\u827a\u51fa\u7248\u793e",
                "recommend_comment": "\u5bf9\u5f20\u7f9e\u7684\u4f5c\u54c1\u4e0d\u964c\u751f\uff0c\u4f46\u5f88\u591a\u4eba\u53ef\u80fd\u6ca1\u8bfb\u8fc7\u300a\u5927\u8c61\u300b\u300a\u7011\u5e03\u300b\u300a\u6563\u88c5\u9ebb\u96c0\u300b\uff0c\u65e0\u8bba\u662f\u8bd7\u8fd8\u662f\u5c0f\u8bf4\uff0c\u5f20\u7f9e\u90fd\u5728\u63a2\u7d22\u66f4\u4e3a\u672c\u8d28\u7684\u4e1c\u897f\u2014\u2014\u8d85\u8d8a\u8bed\u8a00\uff08\u8bed\u4e49\uff09\u7684\u8bed\u8a00\uff0c\u800c\u518d\u5f80\u6df1\u5904\uff0c\u5176\u7ec8\u6781\u9762\u8c8c\u662f\u8a00\u4e4b\u65e0\u7269\u3002\u201c\u5199\u4f5c\u201d\u5728\u5f20\u7f9e\u7684\u5b9e\u8df5\u4e2d\uff0c\u662f\u8d85\u8d8a\u201c\u5199\u4f5c\u201d\u7684\u827a\u672f\u6982\u5ff5\u3002\u867d\u7136\u300a\u9e45\u300b\u7528\u4e86\u5341\u51e0\u4e07\u5b57\u5199\u4e00\u5934\u9e45\uff0c\u4f46\u8fd9\u5934\u9e45\u59cb\u7ec8\u53ea\u662f\u4e00\u5934\u9e45\uff0c\u800c\u9e45\u8bed\u7684\u4e16\u754c\u4e5f\u53ea\u6709\u4e09\u4e2a\u8bcd\u6c47\uff1a\u9e45\u3001\u9e45\u9e45\u3001\u9e45\u9e45\u9e45\u3002\uff08\u8bf4\u53e5\u4eba\u8bdd\uff1a\u63a8\u8350\u3002 \u2014\u2014 \u9a6c\u63b0\u63b0\u7684\u77ed\u8bc4",
                "id": "34821348",
                "title": "\u9e45",
                "wish_count": 2142,
                "label": null,
                "interest": null,
                "type": "book",
                "onsale": true,
                "description": "",
                "price": null,
                "press": ["\u540e\u6d6a\u4e28\u56db\u5ddd\u6587\u827a\u51fa\u7248\u793e"],
                "info": "\u5f20\u7f9e\/\u540e\u6d6a\u4e28\u56db\u5ddd\u6587\u827a\u51fa\u7248\u793e\/2019-11",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/book\/34821348",
                "release_date": null,
                "author": ["\u5f20\u7f9e"],
                "cover": {
                    "url": "https://img9.doubanio.com\/view\/subject\/l\/public\/s33489514.jpg",
                    "width": 0,
                    "shape": "rectangle",
                    "height": 0
                },
                "uri": "douban:\/\/douban.com\/book\/34821348",
                "subtype": "",
                "reviewer_name": "",
                "null_rating_reason": ""
            }],
            "total": 100,
            "subject_collection": {
                "subject_type": "",
                "subtitle": "",
                "background_color_scheme": {
                    "is_dark": true,
                    "primary_color_light": "727272",
                    "secondary_color": "f4f4f9",
                    "primary_color_dark": "4c4c4c"
                },
                "updated_at": null,
                "id": "book_fiction",
                "show_header_mask": false,
                "medium_name": "",
                "description": "",
                "short_name": "",
                "n_followers": null,
                "cover_url": "",
                "show_rank": true,
                "sharing_url": "https:\/\/www.douban.com\/doubanapp\/dispatch?uri=\/subject_collection\/book_fiction\/",
                "subject_count": 100,
                "name": "\u6700\u53d7\u5173\u6ce8\u7684\u865a\u6784\u7c7b\u56fe\u4e66",
                "url": "https:\/\/m.douban.com\/app_topic\/book_fiction",
                "uri": "douban:\/\/douban.com\/subject_collection\/book_fiction",
                "mini_program_page": "",
                "icon_fg_image": "",
                "more_description": "",
                "mini_program_name": "",
                "display": {
                    "layout": "list"
                }
            }
        });
    });
};