//API接口：国产电视剧
//接口如下：
// -近期值得看的国产剧
// -近期值得看的综艺节目
// -近期值得看的综艺节目


module.exports = (apiRouter) => {

    //API接口：近期值得看的国产剧
    apiRouter.get("/tv_domestic", (req, res, next) => {
        res.send({
            "count": 8,
            "start": 0,
            "subject_collection_items": [{
                "original_price": null,
                "rating": {
                    "count": 45513,
                    "max": 10,
                    "value": 8.0
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u53e4\u88c5 \/ \u5b59\u7693 \/ \u5f20\u82e5\u6600 \u674e\u6c81",
                "recommend_comment": "\u8fd9\u5267\u771f\u662f\u8d85\u8c6a\u534e\u9635\u5bb9\u5440\uff0c\u60f3\u770b\u9648\u9053\u660e\u548c\u5f20\u82e5\u6600\u7684\u7236\u5b50\u5927\u620f\uff0c\u5f88\u559c\u6b22\u8fbe\u5eb7\u4e66\u8bb0\u6f14\u7684\u9648\u840d\u840d\u3002 \u2014\u2014 \u9ed1\u8272\u661f\u671f\u4e94\u7684\u77ed\u8bc4",
                "id": "25853071",
                "title": "\u5e86\u4f59\u5e74",
                "label": null,
                "actors": ["\u5f20\u82e5\u6600", "\u674e\u6c81", "\u9648\u9053\u660e"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u53e4\u88c5 \/ \u5b59\u7693 \/ \u5f20\u82e5\u6600 \u674e\u6c81",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/25853071",
                "release_date": "11.26",
                "cover": {
                    "url": "https://img1.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2575362797.jpg",
                    "width": 5675,
                    "shape": "rectangle",
                    "height": 8000
                },
                "uri": "douban:\/\/douban.com\/tv\/25853071",
                "subtype": "",
                "directors": ["\u5b59\u7693"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 21089,
                    "max": 10,
                    "value": 7.5
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u7231\u60c5 \u53e4\u88c5 \/ \u6768\u6587\u519b \/ \u7f57\u664b \u674e\u4e00\u6850",
                "recommend_comment": "\u5f53\u7687\u5e1d\u4e0d\u5bb9\u6613\uff0c\u5f53\u7687\u5e1d\u513f\u5b50\u66f4\u4e0d\u5bb9\u6613\u3002\u8fd8\u597d\u8427\u5b9a\u6743\u6709\u8001\u5e08\u8205\u8205\u548c\u5c0f\u8868\u54e5\uff0c\u4e0d\u7136\u65e9\u665a\u88ab\u674e\u67cf\u821f\u4e00\u5bb6\u6b3a\u8d1f\u6b7b\u3002 \u2014\u2014 Jay Chou\u7684\u77ed\u8bc4",
                "id": "27114834",
                "title": "\u9e64\u5533\u534e\u4ead",
                "label": null,
                "actors": ["\u7f57\u664b", "\u674e\u4e00\u6850", "\u9ec4\u5fd7\u5fe0"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u7231\u60c5 \u53e4\u88c5 \/ \u6768\u6587\u519b \/ \u7f57\u664b \u674e\u4e00\u6850",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/27114834",
                "release_date": "11.12",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2574014902.jpg",
                    "width": 1080,
                    "shape": "rectangle",
                    "height": 1919
                },
                "uri": "douban:\/\/douban.com\/tv\/27114834",
                "subtype": "",
                "directors": ["\u6768\u6587\u519b"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 21472,
                    "max": 10,
                    "value": 7.3
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u52a8\u4f5c \u6b66\u4fa0 \/ \u4e8e\u4e2d\u4e2d \/ \u8bb8\u51ef \u5f20\u6995\u5bb9",
                "recommend_comment": "\u8fd9\u662f\u4ec0\u4e48\u667a\u969c\u5267\u60c5\uff0c\u662f\u7ed9\u5c0f\u5b66\u751f\u770b\u7684\u5417\uff0c\u6beb\u65e0\u903b\u8f91\uff0c\u611f\u89c9\u667a\u5546\u53d7\u5230\u4e86\u4fae\u8fb1 \u2014\u2014 \u732b\u6bd4\u72d7\u53ef\u7231\u7684\u77ed\u8bc4",
                "id": "26877434",
                "title": "\u4ece\u524d\u6709\u5ea7\u7075\u5251\u5c71",
                "label": null,
                "actors": ["\u8bb8\u51ef", "\u5f20\u6995\u5bb9", "\u6731\u5143\u51b0"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u52a8\u4f5c \u6b66\u4fa0 \/ \u4e8e\u4e2d\u4e2d \/ \u8bb8\u51ef \u5f20\u6995\u5bb9",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/26877434",
                "release_date": "11.12",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2574861321.jpg",
                    "width": 1080,
                    "shape": "rectangle",
                    "height": 1520
                },
                "uri": "douban:\/\/douban.com\/tv\/26877434",
                "subtype": "",
                "directors": ["\u4e8e\u4e2d\u4e2d"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 5584,
                    "max": 10,
                    "value": 5.9
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u9648\u94ed\u7ae0 \/ \u738b\u5b50\u6587 \u5f20\u9c81\u4e00",
                "recommend_comment": "\u9ebb\u96c0\u7684\u65f6\u5019\u5c31\u5f88\u559c\u6b22\u5f20\u9c81\u4e00\uff0c\u8fd9\u90e8\u5267\u4e2d\u7684\u8bb8\u6717\u4e0d\u4e00\u6837\u7684\u98ce\u683c\u5c55\u73b0\uff0c\u4e5f\u5f88\u6709\u770b\u5934 \u2014\u2014 \u9b3c\u9b3c\u7684\u77ed\u8bc4",
                "id": "30299385",
                "title": "\u7b2c\u4e8c\u6b21\u4e5f\u5f88\u7f8e",
                "label": null,
                "actors": ["\u738b\u5b50\u6587", "\u5f20\u9c81\u4e00", "\u4e8e\u660e\u52a0"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u9648\u94ed\u7ae0 \/ \u738b\u5b50\u6587 \u5f20\u9c81\u4e00",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30299385",
                "release_date": "11.20",
                "cover": {
                    "url": "https://img1.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2548259207.jpg",
                    "width": 1800,
                    "shape": "rectangle",
                    "height": 2700
                },
                "uri": "douban:\/\/douban.com\/tv\/30299385",
                "subtype": "",
                "directors": ["\u9648\u94ed\u7ae0"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 2494,
                    "max": 10,
                    "value": 5.5
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u6797\u598d \/ \u5f20\u5929\u7231 \u9648\u67cf\u9716",
                "recommend_comment": "\u6211\u5f88\u4e50\u610f\u6253\u4e94\u661f\u7684\u5076\u50cf\u5267\uff0c\u8fd1\u671f\u56fd\u4ea7\u5076\u50cf\u5267\u4e2d\u7684\u8bda\u610f\u4e4b\u4f5c\u4e86\u3002\u5b9e\u666f\u62cd\u6444\u3001\u4e3b\u6f14\u5168\u90e8\u7eaf\u6b63\u6cd5\u8bed\u53d1\u97f3\u8fd9\u4e9b\u5c0f\u7ec6\u8282\u4e0d\u8bf4\uff0c\u5267\u96c6\u8282\u594f\u4e24\u4f4d\u4e3b\u6f14\u4e5f\u662f\u62ff\u634f\u5f97\u5f20\u5f1b\u6709\u5ea6\uff0c\u8f7b\u677e\u6d3b\u6cfc\u3002\u5468\u5c14\u6587\u7684\u6bd2\u820c\u51b7\u6f20\u548c\u674e\u5357\u6069\u7684\u6d3b\u6cfc\u4e50\u89c2\u90fd\u5145\u5206\u5c55\u73b0\uff0c\u4e24\u4e2a\u4eba\u7684\u503c\u5f97\u80af\u5b9a\u7684\u6f14\u6280\u4e00\u4e0b\u5c31\u51b3\u5b9a\u4e86\u6574\u90e8\u5267\u5267\u60c5\u4e3b\u7ebf\u7684\u8d28\u91cf\uff0c\u5b8c\u5168\u4e0d\u5c34\u5c2c \u2014\u2014 \u98ce\u5341\u4e94\u6b4c\u7684\u77ed\u8bc4",
                "id": "30206447",
                "title": "\u9cc4\u9c7c\u4e0e\u7259\u7b7e\u9e1f",
                "label": null,
                "actors": ["\u5f20\u5929\u7231", "\u9648\u67cf\u9716", "\u5434\u660a\u5bb8"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u6797\u598d \/ \u5f20\u5929\u7231 \u9648\u67cf\u9716",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30206447",
                "release_date": "11.18",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2574617662.jpg",
                    "width": 4205,
                    "shape": "rectangle",
                    "height": 6000
                },
                "uri": "douban:\/\/douban.com\/tv\/30206447",
                "subtype": "",
                "directors": ["\u6797\u598d"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 8620,
                    "max": 10,
                    "value": 5.3
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u60ac\u7591 \/ \u9f9a\u671d\u6656 \/ \u8042\u8fdc \u5b8b\u8f76",
                "recommend_comment": "\u51b2\u7740\u8fd9\u6ca1\u5815\u80ce\u4e8b\u60c5\u5c31\u4e0d\u4f1a\u53d1\u751f  \u6211\u7684\u5988\u5988\u662f\u8d85\u4eba\u4e0d\u7528\u5403\u996d\u4e0d\u7528\u7761\u89c9\u8fd9\u79cd\u8bcd\u513f\u4e24\u661f\u6ca1\u6cd5\u66f4\u591a \u2014\u2014 \u6a31\u6843\u5c0f\u88ab\u7a9d\u7684\u77ed\u8bc4",
                "id": "30329153",
                "title": "\u5fc3\u7075\u6cd5\u533b",
                "label": null,
                "actors": ["\u8042\u8fdc", "\u5b8b\u8f76", "\u82a6\u82b3\u751f"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u60ac\u7591 \/ \u9f9a\u671d\u6656 \/ \u8042\u8fdc \u5b8b\u8f76",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30329153",
                "release_date": "11.18",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2574108882.jpg",
                    "width": 3576,
                    "shape": "rectangle",
                    "height": 6355
                },
                "uri": "douban:\/\/douban.com\/tv\/30329153",
                "subtype": "",
                "directors": ["\u9f9a\u671d\u6656"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 1305,
                    "max": 10,
                    "value": 8.7
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u53f0\u6e7e \/ \u7231\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u9ec4\u5929\u4ec1 \/ \u67ef\u4f73\u5b3f \u8bb8\u5149\u6c49",
                "recommend_comment": "\u8fd8\u662f\u6709\u79c1\u5fc3\uff0c\u5fc3\u88ab\u8bb8\u5149\u6c49\u638f\u7a7a \u2014\u2014 \u54ea\u554a\u54ea\u554a\u7684\u77ed\u8bc4",
                "id": "30468961",
                "title": "\u60f3\u89c1\u4f60",
                "label": null,
                "actors": ["\u67ef\u4f73\u5b3f", "\u8bb8\u5149\u6c49", "\u65bd\u67cf\u5b87"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": false,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u53f0\u6e7e \/ \u7231\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u9ec4\u5929\u4ec1 \/ \u67ef\u4f73\u5b3f \u8bb8\u5149\u6c49",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30468961",
                "release_date": "11.17",
                "cover": {
                    "url": "https://img1.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2573026979.jpg",
                    "width": 1000,
                    "shape": "rectangle",
                    "height": 1334
                },
                "uri": "douban:\/\/douban.com\/tv\/30468961",
                "subtype": "",
                "directors": ["\u9ec4\u5929\u4ec1"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 29380,
                    "max": 10,
                    "value": 8.4
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u9999\u6e2f \/ \u5267\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u53f6\u9547\u8f89 \/ \u9648\u5c71\u806a \u674e\u65bd\u5b05",
                "recommend_comment": "2019\u6bd4\u8f83\u770b\u5f97\u5165\u773c\u7684\u6e2f\u5267\uff0c\u4e0d\u8fc7\u53c8\u65e5\u5e38\u9ed1\u5927\u9646\u4eba\uff08\u4e0d\u662f\u4f4e\u7d20\u8d28\u7684\u6e38\u5ba2\u5c31\u662f\u5403\u5927\u8336\u996d\u7684\u52ab\u532a\uff09\uff0c\u60f3\u5f53\u5e74\u5185\u5730\u5c0f\u5b69\u5f53\u8857\u4fbf\u6eba\u88ab\u5168\u6e2f\u8ba8\u4f10\uff0c\u518d\u770b\u770b\u8fd1\u51e0\u4e2a\u6708\u5168\u6e2f\u9a9a\u4e71\uff0c\u5374\u79f0\u4e3a\u516c\u6c11\u6297\u547d\uff0c\u4e0d\u514d\u6709\u4e9b\u611f\u53f9\u550f\u5618\u3002\u5e0c\u671b\u4ee5\u540e\u8fd8\u6709\u673a\u4f1a\u770b\u5230\u66f4\u597d\u7684\u6e2f\u5267\u3002 \u2014\u2014 \u591c\u6b87\u5fae\u6059\u7684\u77ed\u8bc4",
                "id": "30156074",
                "title": "\u91d1\u5bb5\u5927\u53a6",
                "label": null,
                "actors": ["\u9648\u5c71\u806a", "\u674e\u65bd\u5b05", "\u5f20\u66e6\u96ef"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": false,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u9999\u6e2f \/ \u5267\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u53f6\u9547\u8f89 \/ \u9648\u5c71\u806a \u674e\u65bd\u5b05",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30156074",
                "release_date": "09.16",
                "cover": {
                    "url": "https://img1.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2569014827.jpg",
                    "width": 540,
                    "shape": "rectangle",
                    "height": 811
                },
                "uri": "douban:\/\/douban.com\/tv\/30156074",
                "subtype": "",
                "directors": ["\u53f6\u9547\u8f89"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }],
            "total": 50,
            "subject_collection": {
                "subject_type": "",
                "subtitle": "",
                "background_color_scheme": {
                    "is_dark": true,
                    "primary_color_light": "72261b",
                    "secondary_color": "f9f5f4",
                    "primary_color_dark": "4c1912"
                },
                "updated_at": null,
                "id": "tv_domestic",
                "display": {
                    "layout": "list"
                },
                "show_header_mask": false,
                "medium_name": "",
                "description": "",
                "short_name": "\u56fd\u4ea7\u5267",
                "n_followers": null,
                "cover_url": "",
                "show_rank": true,
                "sharing_url": "https:\/\/www.douban.com\/doubanapp\/dispatch?uri=\/subject_collection\/tv_domestic\/",
                "subject_count": 50,
                "name": "\u8fd1\u671f\u70ed\u95e8\u56fd\u4ea7\u5267",
                "url": "https:\/\/m.douban.com\/app_topic\/tv_domestic",
                "uri": "douban:\/\/douban.com\/subject_collection\/tv_domestic",
                "mini_program_page": "",
                "icon_fg_image": "",
                "more_description": "",
                "mini_program_name": "",
                "show_filter_playable": true
            }
        });
    });

    //API接口：近期值得看的综艺节目
    apiRouter.get("/tv_variety_show", (req, res, next) => {
        res.send({
            "count": 8,
            "start": 0,
            "subject_collection_items": [{
                "original_price": null,
                "rating": {
                    "count": 3173,
                    "max": 10,
                    "value": 6.1
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u8131\u53e3\u79c0 \/ \u8c2d\u6653\u8679 \/ \u8881\u548f\u4eea \u5434\u6615",
                "recommend_comment": "\u63d0\u524d\u770b\u4e86\u7b2c\u4e00\u671f\uff0c\u6881\u9f99\u8001\u5e08\u662f\u60ca\u559c\uff0c\u5361\u59c6\u4e00\u5b9a\u8981\u5e38\u9a7b\u554a \u2014\u2014 Hisummer\uff01\u7684\u77ed\u8bc4",
                "id": "34840338",
                "title": "\u5410\u69fd\u5927\u4f1a \u7b2c\u56db\u5b63",
                "label": null,
                "actors": ["\u8881\u548f\u4eea", "\u5434\u6615", "\u5f20\u7ecd\u521a"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u8131\u53e3\u79c0 \/ \u8c2d\u6653\u8679 \/ \u8881\u548f\u4eea \u5434\u6615",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/34840338",
                "release_date": "11.30",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2572914273.jpg",
                    "width": 690,
                    "shape": "rectangle",
                    "height": 977
                },
                "uri": "douban:\/\/douban.com\/tv\/34840338",
                "subtype": "",
                "directors": ["\u8c2d\u6653\u8679"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 28580,
                    "max": 10,
                    "value": 8.8
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u4f55\u8212 \/ \u4f55\u7085 \u6492\u8d1d\u5b81",
                "recommend_comment": "\u301011.30\u66f4\u65b0\uff1a\u7b2c\u4e09\u6848\u4f9d\u7136\u7cbe\u5f69\uff01\u5267\u672c\u5f88\u4f18\u79c0\uff0c\u5173\u6ce8\u793e\u4f1a\u95ee\u9898\uff0c\u53cd\u8f6c\u4e5f\u5f88\u5e26\u611f\u3002\u65b0\u4eba\u621a\u8587\u548c\u4faf\u660e\u660a\u73a9\u5f97\u4e0d\u9519\uff0c\u6001\u5ea6\u79ef\u6781\u8ba4\u771f\uff0c\u601d\u8def\u4e5f\u6709\u6761\u7406\u3002\u8bc4\u5206\u518d\u6da8\u70b9\u5427\uff01\u503c\u5f979\u5206\u7684\uff01\u3011\u5176\u5b9e\u56e2\u9b42\u6211\u5012\u6ca1\u4ec0\u4e48\u592a\u5927\u6267\u5ff5\uff08\u4f46\u662f\u53cc\u5317\u5fc5\u987b\u5728\uff09\uff0c\u6bd5\u7adf\u4e5f\u9700\u8981\u65b0\u9c9c\u8840\u6db2\u3002\u53ea\u662f\u5e0c\u671b\u8282\u76ee\u7ec4\u597d\u597d\u6253\u78e8\u5267\u672c\uff0c\u597d\u597d\u63a8\u7406\u3002\u81ea\u4ece\u6050\u6016\u7ae5\u8c23\u51fa\u5708\u4ee5\u540e\uff0c\u8282\u76ee\u7ec4\u5c31\u597d\u50cf\u8d70\u4e0a\u4e86\u4e00\u4e2a\u602a\u5708\uff0c\u4e00\u5473\u8ffd\u6c42\u4e0d\u5207\u5b9e\u9645\u7684\u8111\u6d1e\u53cd\u8f6c\u548c\u6050\u6016\u6c1b\u56f4\uff0c\u800c\u5ffd\u89c6\u6545\u4e8b\u672c\u8eab\uff0c\u5931\u53bb\u4e86\u539f\u6c41\u539f\u5473\u3002\u5148\u9001\u4e0a\u8001\u7c89\u7684\u4e94\u661f\u3002 \u2014\u2014 30\u5929\u4fee\u6539\u4e00\u6b21\u7684\u77ed\u8bc4",
                "id": "30446494",
                "title": "\u660e\u661f\u5927\u4fa6\u63a2 \u7b2c\u4e94\u5b63",
                "label": null,
                "actors": ["\u4f55\u7085", "\u6492\u8d1d\u5b81", "\u767d\u656c\u4ead"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u4f55\u8212 \/ \u4f55\u7085 \u6492\u8d1d\u5b81",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30446494",
                "release_date": "11.08",
                "cover": {
                    "url": "https://img9.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2574618624.jpg",
                    "width": 3000,
                    "shape": "rectangle",
                    "height": 4142
                },
                "uri": "douban:\/\/douban.com\/tv\/30446494",
                "subtype": "",
                "directors": ["\u4f55\u8212"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 28642,
                    "max": 10,
                    "value": 8.1
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u8131\u53e3\u79c0 \/ \u9a6c\u4e1c \u8521\u5eb7\u6c38",
                "recommend_comment": "\u601d\u7ef4\u903b\u8f91\u6bd4\u4e0d\u8fc7\u773c\u6cea\u548c\u6492\u6cfc\u6253\u6eda \u2014\u2014 \u6211\u662f\u8c01\u7684\u77ed\u8bc4",
                "id": "33441919",
                "title": "\u5947\u8469\u8bf4 \u7b2c\u516d\u5b63",
                "label": null,
                "actors": ["\u9a6c\u4e1c", "\u8521\u5eb7\u6c38", "\u674e\u8bde"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u8131\u53e3\u79c0 \/ \u9a6c\u4e1c \u8521\u5eb7\u6c38",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/33441919",
                "release_date": "10.31",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2571064755.jpg",
                    "width": 1080,
                    "shape": "rectangle",
                    "height": 1920
                },
                "uri": "douban:\/\/douban.com\/tv\/33441919",
                "subtype": "",
                "directors": [],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 26227,
                    "max": 10,
                    "value": 6.9
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u5b59\u4eae\u4eae \/ \u6c99\u6ea2 \u9648\u51ef\u6b4c",
                "recommend_comment": "\u8d75\u8587\u7ec4\u597d\u59ec\uff0c\u5c0f\u56db\u7ec4\u597d\u57fa\uff0c\u4e24\u4f4d\u5bfc\u5e08\u4e92\u52a8\u4e5f\u597d\u597d\u7b11\uff0c\u76f8\u6bd4\u300a\u6211\u5c31\u662f\u6f14\u5458\u300b\u5bfc\u5e08\u5218\u70e8\u3001\u5f90\u5ce5\u7684\u8001\u597d\u4eba\u548c\u5212\u6c34\uff0c\u65e0\u8bba\u662f\u9648\u51ef\u6b4c\u8fd8\u662f\u90ed\u656c\u660e\uff0c\u6bcf\u4e2a\u5bfc\u6f14\u90fd\u662f\u4e00\u9488\u89c1\u8840\uff0c\u4e0d\u73a9\u865a\u7684\u3002\u6f14\u5458\u9009\u89d2\u90fd\u4e0d\u662f\u5927\u7ea2\u7684\u4f46\u597d\u591a\u90fd\u7ed9\u4eba\u7559\u4e0b\u6df1\u523b\u5370\u8c61\u3002\u6bcf\u6b21\u4e09\u4e2a\u949f\uff0c\u4e5f\u592a\u826f\u5fc3\u4e86\u5427\u3002\u8d75\u8587\uff0c\u6f02\u4eae\u3002\u90ed\u656c\u660e\uff0c\u4f18\u79c0\u3002\u9648\u51ef\u6b4c\uff0c\u4e13\u4e1a\u3002\u674e\u5c11\u7ea2\uff0c\u5728\u9002\u5e94\u8282\u76ee\u4e2d\uff0c\u54c8\u54c8\uff0c\u53ef\u7231\u3002 \u2014\u2014 Cycble\u7684\u77ed\u8bc4",
                "id": "33385536",
                "title": "\u6f14\u5458\u8bf7\u5c31\u4f4d",
                "label": null,
                "actors": ["\u6c99\u6ea2", "\u9648\u51ef\u6b4c", "\u674e\u5c11\u7ea2"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u5b59\u4eae\u4eae \/ \u6c99\u6ea2 \u9648\u51ef\u6b4c",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/33385536",
                "release_date": "10.11",
                "cover": {
                    "url": "https://img1.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2571224839.jpg",
                    "width": 2160,
                    "shape": "rectangle",
                    "height": 3840
                },
                "uri": "douban:\/\/douban.com\/tv\/33385536",
                "subtype": "",
                "directors": ["\u5b59\u4eae\u4eae"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 10018,
                    "max": 10,
                    "value": 8.9
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u5362\u5c0f\u6ce2 \u5de6\u5174 \/ \u6492\u8d1d\u5b81 \u5eb7\u8f89",
                "recommend_comment": "\u8282\u76ee\u5236\u4f5c\u5e72\u51c0\u5229\u7d22\uff0c\u9009\u624b\u7efc\u5408\u7d20\u8d28\u90fd\u5f88\u9ad8\u4f46\u786e\u5b9e\u7f3a\u4e4f\u7ecf\u9a8c\u3002\uff08\u8463\u537f\u8001\u5e08\u7b80\u76f4\u662f\u4e00\u4f4d\u5185\u5916\u517c\u4fee\u7684\u4ed9\u5973\uff01\uff09 \u2014\u2014 \u007f\u007f\u007f\u007f\u7684\u77ed\u8bc4",
                "id": "34879453",
                "title": "\u4e2d\u592e\u5e7f\u64ad\u7535\u89c6\u603b\u53f02019\u4e3b\u6301\u4eba\u5927\u8d5b",
                "label": null,
                "actors": ["\u6492\u8d1d\u5b81", "\u5eb7\u8f89", "\u8463\u537f"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u5362\u5c0f\u6ce2 \/ \u6492\u8d1d\u5b81 \u5eb7\u8f89",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/34879453",
                "release_date": "10.26",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2573352241.jpg",
                    "width": 690,
                    "shape": "rectangle",
                    "height": 1227
                },
                "uri": "douban:\/\/douban.com\/tv\/34879453",
                "subtype": "",
                "directors": ["\u5362\u5c0f\u6ce2"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 11627,
                    "max": 10,
                    "value": 7.6
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u9648\u5e73 \/ \u4f55\u7085 \u5468\u9707\u5357",
                "recommend_comment": "9012\u5e74\u4e86\uff0c\u8fd8\u6709\u4eba\u4e0d\u77e5\u9053\u56e0\u4e3a\u9650\u97e9\u4e70\u4e86\u7248\u6743\u4e5f\u4e0d\u80fd\u5927\u5f20\u65d7\u9f13\u5417\uff1f\u5728\u8fd9\u91cc\u6253\u4e00\u661f\u8bf4\u6284\u88ad\uff1f\u65e0\u77e5\u5f88\u6709\u4f18\u8d8a\u611f\u5417\uff1f\u6211\u6ca1\u6709\u53cd\u5bf9\u89c9\u5f97\u8282\u76ee\u4e0d\u597d\u770b\u6253\u4e00\u661f\uff0c\u6211\u53ea\u662f\u89c9\u5f97\u6ca1\u6709\u770b\u8fc7\u5c31\u79c0\u4f18\u8d8a\u5f88\u50bb\u903c\u3002\u5b8c\u6574\u8ffd\u8fc7\u97e9\u7248\uff0c\u4e00\u76f4\u5f88\u671f\u5f85\u80fd\u6709\u56fd\u5185\u6cd5\u7684\u7c7b\u4f3c\u8282\u76ee\uff0c\u77e5\u9053\u4e70\u4e86\u7248\u6743\u5c31\u5728\u7b49\u3002\u770b\u4e86\u4e00\u671f\u4e4b\u540e\u89c9\u5f97\u9664\u4e86\u8282\u594f\u8fd8\u662f\u6709\u56fd\u5185\u7efc\u827a\u666e\u904d\u62d6\u6c93\u7684\u95ee\u9898\u4e4b\u5916\uff0c\u6574\u4f53\u6c34\u51c6\u8fd8\u662f\u6bd4\u8f83\u9ad8\u7684\uff0c\u671f\u5f85\u540e\u9762\u51e0\u671f\u3002\uff082019.11.1\uff09\u770b\u4e86\u7b2c\u4e8c\u671f\uff0c\u6211\u76f2\u62bc\u6885\u6862\u674e\u6d69\u6e90\u3002\u53e6\u5916\uff0c\u8fd9\u4e2a\u8282\u76ee\u7684\u4f4e\u5206\u6fc0\u8fdb\u8bc4\u8bba\u533a\u771f\u662f\u6cd5\u5b66\u751f\u7237\u73b0\u773c\u5927\u8d4f\u3002\uff082019.11.7\uff09 \u2014\u2014 \u4e0d\u60f3\u88ab\u53d1\u73b0\u7684\u77ed\u8bc4",
                "id": "34855021",
                "title": "\u4ee4\u4eba\u5fc3\u52a8\u7684offer",
                "label": null,
                "actors": ["\u4f55\u7085", "\u5468\u9707\u5357", "\u90ed\u4eac\u98de"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u9648\u5e73 \/ \u4f55\u7085 \u5468\u9707\u5357",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/34855021",
                "release_date": "10.30",
                "cover": {
                    "url": "https://img9.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2572320724.jpg",
                    "width": 2250,
                    "shape": "rectangle",
                    "height": 4000
                },
                "uri": "douban:\/\/douban.com\/tv\/34855021",
                "subtype": "",
                "directors": ["\u9648\u5e73"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 15760,
                    "max": 10,
                    "value": 7.6
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u8d75\u7426 \/ \u963f\u96c5 \u5468\u8fc5",
                "recommend_comment": "\u7b2c\u4e00\u96c6\uff1a\u8dd1\u7537\u6765\u4f8b\u5047\uff0c\u5947\u9047\u4e5f\u6765\u4f8b\u5047\uff0c\u8fd9\u5f88AB\uff0c\u5979\u4e0d\u771f\u5b9e\u3002\u7b2c\u4e8c\u96c6\uff1a\u6211\u7231\u513f\u5b50\uff0c\u6211\u66f4\u7231\u6211\u7684\u8001\u5a46\uff0c\u8fd9\u5f88\u4e8c\u53d4\uff0c\u4ed6\u662f\u51af\u7ecd\u5cf0\u3002 \u2014\u2014 Jackson\u7684\u77ed\u8bc4",
                "id": "34431570",
                "title": "\u5947\u9047\u4eba\u751f \u7b2c\u4e8c\u5b63",
                "label": null,
                "actors": ["\u963f\u96c5", "\u5468\u8fc5", "\u5218\u96ef"],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u771f\u4eba\u79c0 \/ \u8d75\u7426 \/ \u963f\u96c5 \u5468\u8fc5",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/34431570",
                "release_date": "10.22",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2572347980.jpg",
                    "width": 1432,
                    "shape": "rectangle",
                    "height": 2048
                },
                "uri": "douban:\/\/douban.com\/tv\/34431570",
                "subtype": "",
                "directors": ["\u8d75\u7426"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }, {
                "original_price": null,
                "rating": {
                    "count": 5193,
                    "max": 10,
                    "value": 8.9
                },
                "actions": [],
                "is_new_tv": false,
                "year": "2019",
                "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u7eaa\u5f55\u7247 \/ \u738b\u5723\u5fd7",
                "recommend_comment": "\u4e3a\u4ec0\u4e48\u4eba\u5bb6\u7684\u65e9\u9910\u90a3\u4e48\u591a\u59ff\u591a\u5f69\uff01 \u2014\u2014 \u5b87\u5b99\u98db\u884c\u58eb.\u7684\u77ed\u8bc4",
                "id": "34854953",
                "title": "\u65e9\u9910\u4e2d\u56fd \u7b2c\u4e8c\u5b63",
                "label": null,
                "actors": [],
                "interest": null,
                "type": "tv",
                "description": "",
                "has_linewatch": true,
                "price": null,
                "date": null,
                "info": "\u4e2d\u56fd\u5927\u9646 \/ \u7eaa\u5f55\u7247 \/ \u738b\u5723\u5fd7 \/ ",
                "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/34854953",
                "release_date": "10.21",
                "cover": {
                    "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2571674092.jpg",
                    "width": 2160,
                    "shape": "rectangle",
                    "height": 3840
                },
                "uri": "douban:\/\/douban.com\/tv\/34854953",
                "subtype": "",
                "directors": ["\u738b\u5723\u5fd7"],
                "reviewer_name": "",
                "null_rating_reason": ""
            }],
            "total": 63,
            "subject_collection": {
                "subject_type": "",
                "subtitle": "",
                "background_color_scheme": {
                    "is_dark": true,
                    "primary_color_light": "72483b",
                    "secondary_color": "f9f6f4",
                    "primary_color_dark": "4c3027"
                },
                "updated_at": null,
                "id": "tv_variety_show",
                "display": {
                    "layout": "list"
                },
                "show_header_mask": false,
                "medium_name": "",
                "description": "",
                "short_name": "\u7efc\u5408",
                "n_followers": null,
                "cover_url": "",
                "show_rank": true,
                "sharing_url": "https:\/\/www.douban.com\/doubanapp\/dispatch?uri=\/subject_collection\/tv_variety_show\/",
                "subject_count": 63,
                "name": "\u8fd1\u671f\u70ed\u95e8\u7efc\u827a\u8282\u76ee",
                "url": "https:\/\/m.douban.com\/app_topic\/tv_variety_show",
                "uri": "douban:\/\/douban.com\/subject_collection\/tv_variety_show",
                "mini_program_page": "",
                "icon_fg_image": "",
                "more_description": "",
                "mini_program_name": "",
                "show_filter_playable": true
            }
        });
    })

    //API接口：近期值得看的综艺节目
    apiRouter.get("/tv_american", (req, res, next) => {
        res.send({ "count": 8, "start": 0, "subject_collection_items": [{ "original_price": null, "rating": { "count": 70146, "max": 10, "value": 9.2 }, "actions": [], "is_new_tv": false, "year": "2019", "card_subtitle": "2019 \/ \u82f1\u56fd \/ \u5267\u60c5 \u559c\u5267 \u7231\u60c5 \/ \u6234\u65af\u7279\u5c3c\u00b7\u57c3\u5361\u62c9\u52a0 \u9732\u897f\u00b7\u798f\u5e03\u65af \/ \u6770\u897f\u5361\u00b7\u5df4\u767b \u57c3\u91cc\u514b\u65af\u00b7\u52b3\u745f", "recommend_comment": "\u2014Let's get out of here.\n\u2014Okay. \u2014\u2014 MojoEl\u7684\u77ed\u8bc4", "id": "27625457", "title": "\u53bb\u4ed6*\u7684\u4e16\u754c \u7b2c\u4e8c\u5b63", "label": null, "actors": ["\u6770\u897f\u5361\u00b7\u5df4\u767b", "\u57c3\u91cc\u514b\u65af\u00b7\u52b3\u745f", "\u5a1c\u5965\u7c73\u00b7\u963f\u57fa"], "interest": null, "type": "tv", "description": "", "has_linewatch": false, "price": null, "date": null, "info": "\u82f1\u56fd \/ \u5267\u60c5 \u559c\u5267 \u7231\u60c5 \/ \u6234\u65af\u7279\u5c3c\u00b7\u57c3\u5361\u62c9\u52a0 \/ \u6770\u897f\u5361\u00b7\u5df4\u767b \u57c3\u91cc\u514b\u65af\u00b7\u52b3\u745f", "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/27625457", "release_date": "11.04", "cover": { "url": "https://img9.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2570938064.jpg", "width": 2025, "shape": "rectangle", "height": 3000 }, "uri": "douban:\/\/douban.com\/tv\/27625457", "subtype": "", "directors": ["\u6234\u65af\u7279\u5c3c\u00b7\u57c3\u5361\u62c9\u52a0"], "reviewer_name": "", "null_rating_reason": "" }, { "original_price": null, "rating": { "count": 58497, "max": 10, "value": 8.7 }, "actions": [], "is_new_tv": false, "year": "2019", "card_subtitle": "2019 \/ \u7f8e\u56fd \/ \u559c\u5267 \u7231\u60c5 \/ \u7ea6\u7ff0\u00b7\u5361\u5c3c \u57c3\u7c73\u00b7\u7f57\u68ee \u6c64\u59c6\u00b7\u8c6a\u5c14 \u838e\u6717\u00b7\u8c6a\u6839 \/ \u5b89\u59ae\u00b7\u6d77\u745f\u8587 \u5b89\u5fb7\u9c81\u00b7\u65af\u79d1\u7279", "recommend_comment": "\u7b2c\u4e00\u96c6\u597d\u6696\uff0c\u53e4\u65af\u654f\u592a\u8ff7\u4eba \u2014\u2014 emma\u7684\u77ed\u8bc4", "id": "30385409", "title": "\u6469\u767b\u60c5\u7231 \u7b2c\u4e00\u5b63", "label": null, "actors": ["\u5b89\u59ae\u00b7\u6d77\u745f\u8587", "\u5b89\u5fb7\u9c81\u00b7\u65af\u79d1\u7279", "\u8482\u5a1c\u00b7\u83f2"], "interest": null, "type": "tv", "description": "", "has_linewatch": false, "price": null, "date": null, "info": "\u7f8e\u56fd \/ \u559c\u5267 \u7231\u60c5 \/ \u7ea6\u7ff0\u00b7\u5361\u5c3c \/ \u5b89\u59ae\u00b7\u6d77\u745f\u8587 \u5b89\u5fb7\u9c81\u00b7\u65af\u79d1\u7279", "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30385409", "release_date": "10.18", "cover": { "url": "https://img9.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2564153546.jpg", "width": 8250, "shape": "rectangle", "height": 12150 }, "uri": "douban:\/\/douban.com\/tv\/30385409", "subtype": "", "directors": ["\u7ea6\u7ff0\u00b7\u5361\u5c3c"], "reviewer_name": "", "null_rating_reason": "" }, { "original_price": null, "rating": { "count": 2944, "max": 10, "value": 7.4 }, "actions": [], "is_new_tv": true, "year": "2019", "card_subtitle": "2019 \/ \u7f8e\u56fd \/ \u559c\u5267 \/ \u65af\u8482\u82ac\u59ae\u00b7\u83b1\u6069 \u963f\u52d2\u897f\u5a05\u00b7\u743c\u65af \/ \u51ef\u7279\u00b7\u6234\u7433\u65af \u5e03\u5170\u8fbe\u00b7\u5b8b", "recommend_comment": "\u9002\u5408girls\u4e00\u8d77\u770b\u7684\u5267\uff0cnot bad\uff0c\u6700\u540eJ\u90a3\u6bb5fuck u all, \u592a\u723d\u4e86\uff0c\u56db\u4e2a\u4eba\u98d9\u5a5a\u8f66\u771f\u5f00\u5fc3\uff0c\u5173\u952e\u65f6\u523b\u529b\u633a\u59d0\u59b9\u554a \u2014\u2014 Enrika\u7684\u77ed\u8bc4", "id": "27201143", "title": "\u5a03\u5a03\u8138", "label": null, "actors": ["\u51ef\u7279\u00b7\u6234\u7433\u65af", "\u5e03\u5170\u8fbe\u00b7\u5b8b", "\u859b\u00b7\u7c73\u5951\u5c14"], "interest": null, "type": "tv", "description": "", "has_linewatch": false, "price": null, "date": null, "info": "\u7f8e\u56fd \/ \u559c\u5267 \/ \u65af\u8482\u82ac\u59ae\u00b7\u83b1\u6069 \/ \u51ef\u7279\u00b7\u6234\u7433\u65af \u5e03\u5170\u8fbe\u00b7\u5b8b", "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/27201143", "release_date": "11.15", "cover": { "url": "https://img9.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2571951646.jpg", "width": 949, "shape": "rectangle", "height": 1440 }, "uri": "douban:\/\/douban.com\/tv\/27201143", "subtype": "", "directors": ["\u65af\u8482\u82ac\u59ae\u00b7\u83b1\u6069"], "reviewer_name": "", "null_rating_reason": "" }, { "original_price": null, "rating": { "count": 3490, "max": 10, "value": 9.3 }, "actions": [], "is_new_tv": true, "year": "2019", "card_subtitle": "2019 \/ \u7f8e\u56fd \u82f1\u56fd \/ \u5267\u60c5 \u5386\u53f2 \/ \u672c\u00b7\u5361\u9686 \u514b\u91cc\u65af\u8482\u5b89\u00b7\u65bd\u6c83\u970d\u592b \u6770\u897f\u5361\u00b7\u970d\u5e03\u65af \u585e\u7f2a\u5c14\u00b7\u591a\u8bfa\u4e07 \/ \u5965\u5229\u7ef4\u5a05\u00b7\u79d1\u5c14\u66fc \u6258\u6bd4\u4e9a\u65af\u00b7\u95e8\u57fa\u65af", "recommend_comment": "\u671f\u672b\u8003\u8bd5\u8981\u6765\u4e86\uff0c\u738b\u51a0\u5374\u56de\u5f52\u4e86\uff0c\u600e\u4e48\u529e\uff0c\u820d\u5f03\u5bc4\u751f\u866b\u8003\u8bd5\u5237\u5267\u5417\uff01\uff01\uff01\uff1f\uff1f\uff1f \u2014\u2014 weallove970927\u7684\u77ed\u8bc4", "id": "27182502", "title": "\u738b\u51a0 \u7b2c\u4e09\u5b63", "label": null, "actors": ["\u5965\u5229\u7ef4\u5a05\u00b7\u79d1\u5c14\u66fc", "\u6258\u6bd4\u4e9a\u65af\u00b7\u95e8\u57fa\u65af", "\u6d77\u4f26\u5a1c\u00b7\u4f2f\u7ff0\u00b7\u5361\u7279"], "interest": null, "type": "tv", "description": "", "has_linewatch": false, "price": null, "date": null, "info": "\u7f8e\u56fd \u82f1\u56fd \/ \u5267\u60c5 \u5386\u53f2 \/ \u672c\u00b7\u5361\u9686 \/ \u5965\u5229\u7ef4\u5a05\u00b7\u79d1\u5c14\u66fc \u6258\u6bd4\u4e9a\u65af\u00b7\u95e8\u57fa\u65af", "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/27182502", "release_date": "11.17", "cover": { "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2571547155.jpg", "width": 1080, "shape": "rectangle", "height": 1350 }, "uri": "douban:\/\/douban.com\/tv\/27182502", "subtype": "", "directors": ["\u672c\u00b7\u5361\u9686"], "reviewer_name": "", "null_rating_reason": "" }, { "original_price": null, "rating": { "count": 8665, "max": 10, "value": 9.4 }, "actions": [], "is_new_tv": false, "year": "2019", "card_subtitle": "2019 \/ \u7f8e\u56fd \/ \u79d1\u5e7b \u5947\u5e7b \/ \u9edb\u535a\u62c9\u00b7\u5468 \u745e\u514b\u00b7\u6cd5\u7a46\u6613\u74e6 \u6234\u592b\u00b7\u83f2\u6d1b\u5c3c \u5e03\u83b1\u4e1d\u00b7\u8fbe\u62c9\u65af\u00b7\u970d\u534e\u5fb7 \u5854\u4f0a\u52a0\u00b7\u7ef4\u8fea\u63d0 \/ \u4f69\u5fb7\u7f57\u00b7\u5e15\u65af\u5361 Kyle Pacek", "recommend_comment": "\u8d8a\u6765\u8d8a\u611f\u89c9\u661f\u6218\u7684\u5916\u4f20\u7cfb\u5217\u6bd4\u6b63\u4f20\u597d\u770b\u591a\u4e86\u3002 \u2014\u2014 \u56db\u9053\u98ce\u7684\u77ed\u8bc4", "id": "30344167", "title": "\u66fc\u8fbe\u6d1b\u4eba \u7b2c\u4e00\u5b63", "label": null, "actors": ["\u4f69\u5fb7\u7f57\u00b7\u5e15\u65af\u5361", "Kyle Pacek", "\u6cf0\u7279\u00b7\u5f17\u83b1\u5f7b"], "interest": null, "type": "tv", "description": "", "has_linewatch": false, "price": null, "date": null, "info": "\u7f8e\u56fd \/ \u79d1\u5e7b \u5947\u5e7b \/ \u9edb\u535a\u62c9\u00b7\u5468 \/ \u4f69\u5fb7\u7f57\u00b7\u5e15\u65af\u5361 Kyle Pacek", "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30344167", "release_date": "11.12", "cover": { "url": "https://img9.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2566627804.jpg", "width": 1688, "shape": "rectangle", "height": 2500 }, "uri": "douban:\/\/douban.com\/tv\/30344167", "subtype": "", "directors": ["\u9edb\u535a\u62c9\u00b7\u5468"], "reviewer_name": "", "null_rating_reason": "" }, { "original_price": null, "rating": { "count": 7078, "max": 10, "value": 9.8 }, "actions": [], "is_new_tv": false, "year": "2019", "card_subtitle": "2019 \/ \u82f1\u56fd \/ \u7eaa\u5f55\u7247 \/ \u5f17\u96f7\u8fea\u00b7\u5fb7\u74e6\u65af \u827e\u739b\u00b7\u7eb3\u73c0 \u67e5\u767b\u00b7\u4ea8\u7279 \/ \u6234\u7ef4\u00b7\u963f\u6ed5\u4f2f\u52d2", "recommend_comment": "\u300a\u4e03\u4e2a\u4e16\u754c\u300b\n\n\u8fd9\u5730\u7403\u771f\u7f8e\u3002\n\u8fd8\u597d\u8fd8\u6709\u548c\u4eba\u7c7b\u5b8c\u5168\u4e0d\u4e00\u6837\u7684\u5b83\u4eec\u5b58\u5728\u3002\n\u7b2c\u4e00\u96c6\u5357\u6781\u6d32\u5e26\u6765\u65e0\u6570\u7597\u6108\u611f\u52a8\u548c\u9707\u64bc\u3002\n\u5b83\u4eec\u5bf9\u4eba\u7c7b\u89c6\u82e5\u65e0\u7779\uff0c\u800c\u6211\u4eec\u5bf9\u5b83\u4eec\u864e\u89c6\u7708\u7708\u3002 \u2014\u2014 \u4f0a\u6614\u7684\u77ed\u8bc4", "id": "33387353", "title": "\u4e03\u4e2a\u4e16\u754c\uff0c\u4e00\u4e2a\u661f\u7403", "label": null, "actors": ["\u6234\u7ef4\u00b7\u963f\u6ed5\u4f2f\u52d2"], "interest": null, "type": "tv", "description": "", "has_linewatch": false, "price": null, "date": null, "info": "\u82f1\u56fd \/ \u7eaa\u5f55\u7247 \/ \u5f17\u96f7\u8fea\u00b7\u5fb7\u74e6\u65af \/ \u6234\u7ef4\u00b7\u963f\u6ed5\u4f2f\u52d2", "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/33387353", "release_date": "10.28", "cover": { "url": "https://img1.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2572676219.jpg", "width": 1080, "shape": "rectangle", "height": 1920 }, "uri": "douban:\/\/douban.com\/tv\/33387353", "subtype": "", "directors": ["\u5f17\u96f7\u8fea\u00b7\u5fb7\u74e6\u65af"], "reviewer_name": "", "null_rating_reason": "" }, { "original_price": null, "rating": { "count": 5390, "max": 10, "value": 8.4 }, "actions": [], "is_new_tv": false, "year": "2019", "card_subtitle": "2019 \/ \u7f8e\u56fd \/ \u5267\u60c5 \/ \u7c73\u5bc6\u00b7\u83b1\u5fb7 \u5927\u536b\u00b7\u5f17\u5170\u79d1\u5c14 \u7433\u00b7\u8c22\u5c14\u987f \u7f57\u514b\u73ca\u00b7\u9053\u68ee \u5854\u514b\u00b7\u76d6\u8328 \/ \u8a79\u59ae\u5f17\u00b7\u5b89\u59ae\u65af\u987f \u745e\u831c\u00b7\u5a01\u745f\u65af\u5f6d", "recommend_comment": "\u5b89\u59ae\u65af\u987f\u771f\u7684\u662f\u6f14\u4ec0\u4e48\u90fd\u50cf\u745e\u79cb\u2026\u2026 \u6f14\u6280\u5f88\u5957\u8def\u5316\u554a\u3002 \u2014\u2014 \u5510\u7384\ud83d\udc8bTina\ud83c\udf38\u7684\u77ed\u8bc4", "id": "27099158", "title": "\u65e9\u95f4\u65b0\u95fb \u7b2c\u4e00\u5b63", "label": null, "actors": ["\u8a79\u59ae\u5f17\u00b7\u5b89\u59ae\u65af\u987f", "\u745e\u831c\u00b7\u5a01\u745f\u65af\u5f6d", "\u53f2\u8482\u592b\u00b7\u5361\u745e\u5c14"], "interest": null, "type": "tv", "description": "", "has_linewatch": false, "price": null, "date": null, "info": "\u7f8e\u56fd \/ \u5267\u60c5 \/ \u7c73\u5bc6\u00b7\u83b1\u5fb7 \/ \u8a79\u59ae\u5f17\u00b7\u5b89\u59ae\u65af\u987f \u745e\u831c\u00b7\u5a01\u745f\u65af\u5f6d", "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/27099158", "release_date": "11.01", "cover": { "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2571489221.jpg", "width": 2000, "shape": "rectangle", "height": 3000 }, "uri": "douban:\/\/douban.com\/tv\/27099158", "subtype": "", "directors": ["\u7c73\u5bc6\u00b7\u83b1\u5fb7"], "reviewer_name": "", "null_rating_reason": "" }, { "original_price": null, "rating": { "count": 5595, "max": 10, "value": 8.3 }, "actions": [], "is_new_tv": false, "year": "2019", "card_subtitle": "2019 \/ \u82f1\u56fd \/ \u5947\u5e7b \/ \u6c64\u59c6\u00b7\u970d\u73c0 \u6770\u7c73\u00b7\u5947\u5c14\u5179 \u5965\u56fe\u00b7\u5df4\u745f\u8d6b\u65af\u7279 \u5b89\u4e1c\u5c3c\u00b7\u62dc\u6069 \u5c24\u6d1b\u65af\u00b7\u6797 \u5a01\u5ec9\u00b7\u9ea6\u683c\u96f7\u6208 \/ \u8a79\u59c6\u65af\u00b7\u9ea6\u5361\u6c83\u4f0a \u8fbe\u8299\u59ae\u00b7\u57fa\u6069", "recommend_comment": "\u56db\u661f\u89c2\u671b\u3002\u8bf4\u4e07\u78c1\u738b\u7684\u90a3\u4f4d\u4f60\u8ba4\u771f\u7684\u4e48\uff1f\u8fd9\u660e\u660e\u662fX\u6559\u6388\u597d\u4f10\u3002 \u2014\u2014 \u8bf8\u845b\u6751\u592b\u7684\u77ed\u8bc4", "id": "26657521", "title": "\u9ed1\u6697\u7269\u8d28\u4e09\u90e8\u66f2 \u7b2c\u4e00\u5b63", "label": null, "actors": ["\u8a79\u59c6\u65af\u00b7\u9ea6\u5361\u6c83\u4f0a", "\u8fbe\u8299\u59ae\u00b7\u57fa\u6069", "\u9732\u4e1d\u00b7\u5a01\u5c14\u68ee"], "interest": null, "type": "tv", "description": "", "has_linewatch": false, "price": null, "date": null, "info": "\u82f1\u56fd \/ \u5947\u5e7b \/ \u6c64\u59c6\u00b7\u970d\u73c0 \/ \u8a79\u59c6\u65af\u00b7\u9ea6\u5361\u6c83\u4f0a \u8fbe\u8299\u59ae\u00b7\u57fa\u6069", "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/26657521", "release_date": "11.03", "cover": { "url": "https://img3.doubanio.com\/view\/photo\/m_ratio_poster\/public\/p2571781762.jpg", "width": 600, "shape": "rectangle", "height": 889 }, "uri": "douban:\/\/douban.com\/tv\/26657521", "subtype": "", "directors": ["\u6c64\u59c6\u00b7\u970d\u73c0"], "reviewer_name": "", "null_rating_reason": "" }], "total": 50, "subject_collection": { "subject_type": "", "subtitle": "", "background_color_scheme": { "is_dark": true, "primary_color_light": "726668", "secondary_color": "f9f4f5", "primary_color_dark": "4c4445" }, "updated_at": null, "id": "tv_american", "display": { "layout": "list" }, "show_header_mask": false, "medium_name": "", "description": "", "short_name": "\u82f1\u7f8e\u5267", "n_followers": null, "cover_url": "", "show_rank": true, "sharing_url": "https:\/\/www.douban.com\/doubanapp\/dispatch?uri=\/subject_collection\/tv_american\/", "subject_count": 50, "name": "\u8fd1\u671f\u70ed\u95e8\u7f8e\u5267", "url": "https:\/\/m.douban.com\/app_topic\/tv_american", "uri": "douban:\/\/douban.com\/subject_collection\/tv_american", "mini_program_page": "", "icon_fg_image": "", "more_description": "", "mini_program_name": "", "show_filter_playable": true } });
    });

    //API接口：发现好电影
    apiRouter.get("/tv_searchGoods", (req, res, next) => {
        res.send({
            title: "发现好电视剧",
            list: [
                {
                    url: "https://m.douban.com/doulist/37957022/",
                    title: "国产历史剧"
                },
                {
                    url: "https://m.douban.com/doulist/37957022/",
                    title: "豆瓣7.5分以上泰劇"
                },
                {
                    url: "https://m.douban.com/doulist/37957022/",
                    title: "超级热门日剧（评价人数≥10000）"
                },
                {
                    url: "https://m.douban.com/doulist/37957022/",
                    title: "无聊的话就刷刷剧吧~"
                },
                {
                    url: "https://m.douban.com/doulist/37957022/",
                    title: "每个故事都有特定的意义【日剧篇】"
                },
                {
                    url: "https://m.douban.com/doulist/37957022/",
                    title: "【AMC】美国经典电影有线电视台"
                },
                {
                    url: "https://m.douban.com/doulist/37957022/",
                    title: "有些剧让我觉得比有些电影牛逼"
                }
            ]
        });
    });

}
