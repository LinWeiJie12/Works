//API接口：图书书店
//接口如下：
// -最关注图书|虚构类
// -最受关注图书|非虚构类
// -


module.exports = (apiRouter) => {

 //API接口：最关注图书|虚构类
 apiRouter.get("/book", (req, res, next) => {
    res.send({
        "count": 8,
        "start": 0,
        "subject_collection_items": [{
            "original_price": null,
            "rating": {
                "count": 45513,
                "max": 10,
                "value": 9.3
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u53e4\u88c5 \/ \u5b59\u7693 \/ \u5f20\u82e5\u6600 \u674e\u6c81",
            "recommend_comment": "\u8fd9\u5267\u771f\u662f\u8d85\u8c6a\u534e\u9635\u5bb9\u5440\uff0c\u60f3\u770b\u9648\u9053\u660e\u548c\u5f20\u82e5\u6600\u7684\u7236\u5b50\u5927\u620f\uff0c\u5f88\u559c\u6b22\u8fbe\u5eb7\u4e66\u8bb0\u6f14\u7684\u9648\u840d\u840d\u3002 \u2014\u2014 \u9ed1\u8272\u661f\u671f\u4e94\u7684\u77ed\u8bc4",
            "id": "25853071",
            "title": "大象席地而坐",
            "label": null,
            "actors": ["\u5f20\u82e5\u6600", "\u674e\u6c81", "\u9648\u9053\u660e"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u53e4\u88c5 \/ \u5b59\u7693 \/ \u5f20\u82e5\u6600 \u674e\u6c81",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/25853071",
            "release_date": "11.26",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33516881.jpg",
                "booktitle":"最受关注图书|虚构类",
                "width": 5675,
                "shape": "rectangle",
                "height": 8000
            },
            "uri": "douban:\/\/douban.com\/tv\/25853071",
            "subtype": "",
            "directors": ["\u5b59\u7693"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 21089,
                "max": 10,
                "value": 8.9
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u7231\u60c5 \u53e4\u88c5 \/ \u6768\u6587\u519b \/ \u7f57\u664b \u674e\u4e00\u6850",
            "recommend_comment": "\u5f53\u7687\u5e1d\u4e0d\u5bb9\u6613\uff0c\u5f53\u7687\u5e1d\u513f\u5b50\u66f4\u4e0d\u5bb9\u6613\u3002\u8fd8\u597d\u8427\u5b9a\u6743\u6709\u8001\u5e08\u8205\u8205\u548c\u5c0f\u8868\u54e5\uff0c\u4e0d\u7136\u65e9\u665a\u88ab\u674e\u67cf\u821f\u4e00\u5bb6\u6b3a\u8d1f\u6b7b\u3002 \u2014\u2014 Jay Chou\u7684\u77ed\u8bc4",
            "id": "27114834",
            "title": "萨拉戈萨手稿",
            "label": null,
            "actors": ["\u7f57\u664b", "\u674e\u4e00\u6850", "\u9ec4\u5fd7\u5fe0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u7231\u60c5 \u53e4\u88c5 \/ \u6768\u6587\u519b \/ \u7f57\u664b \u674e\u4e00\u6850",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/27114834",
            "release_date": "11.12",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33492042.jpg",
                "width": 1080,
                "shape": "rectangle",
                "height": 1919
            },
            "uri": "douban:\/\/douban.com\/tv\/27114834",
            "subtype": "",
            "directors": ["\u6768\u6587\u519b"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 21472,
                "max": 10,
                "value": 9.1
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u52a8\u4f5c \u6b66\u4fa0 \/ \u4e8e\u4e2d\u4e2d \/ \u8bb8\u51ef \u5f20\u6995\u5bb9",
            "recommend_comment": "\u8fd9\u662f\u4ec0\u4e48\u667a\u969c\u5267\u60c5\uff0c\u662f\u7ed9\u5c0f\u5b66\u751f\u770b\u7684\u5417\uff0c\u6beb\u65e0\u903b\u8f91\uff0c\u611f\u89c9\u667a\u5546\u53d7\u5230\u4e86\u4fae\u8fb1 \u2014\u2014 \u732b\u6bd4\u72d7\u53ef\u7231\u7684\u77ed\u8bc4",
            "id": "26877434",
            "title": "西北雨",
            "label": null,
            "actors": ["\u8bb8\u51ef", "\u5f20\u6995\u5bb9", "\u6731\u5143\u51b0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u52a8\u4f5c \u6b66\u4fa0 \/ \u4e8e\u4e2d\u4e2d \/ \u8bb8\u51ef \u5f20\u6995\u5bb9",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/26877434",
            "release_date": "11.12",
            "cover": {
                "url": "https://img1.doubanio.com/view/subject/l/public/s33486117.jpg",
                "width": 1080,
                "shape": "rectangle",
                "height": 1520
            },
            "uri": "douban:\/\/douban.com\/tv\/26877434",
            "subtype": "",
            "directors": ["\u4e8e\u4e2d\u4e2d"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 5584,
                "max": 10,
                "value": 9.4
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u9648\u94ed\u7ae0 \/ \u738b\u5b50\u6587 \u5f20\u9c81\u4e00",
            "recommend_comment": "\u9ebb\u96c0\u7684\u65f6\u5019\u5c31\u5f88\u559c\u6b22\u5f20\u9c81\u4e00\uff0c\u8fd9\u90e8\u5267\u4e2d\u7684\u8bb8\u6717\u4e0d\u4e00\u6837\u7684\u98ce\u683c\u5c55\u73b0\uff0c\u4e5f\u5f88\u6709\u770b\u5934 \u2014\u2014 \u9b3c\u9b3c\u7684\u77ed\u8bc4",
            "id": "30299385",
            "title": "呼吸",
            "label": null,
            "actors": ["\u738b\u5b50\u6587", "\u5f20\u9c81\u4e00", "\u4e8e\u660e\u52a0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u9648\u94ed\u7ae0 \/ \u738b\u5b50\u6587 \u5f20\u9c81\u4e00",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30299385",
            "release_date": "11.20",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33516832.jpg",
                "width": 1800,
                "shape": "rectangle",
                "height": 2700
            },
            "uri": "douban:\/\/douban.com\/tv\/30299385",
            "subtype": "",
            "directors": ["\u9648\u94ed\u7ae0"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 2494,
                "max": 10,
                "value": 8.5
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u6797\u598d \/ \u5f20\u5929\u7231 \u9648\u67cf\u9716",
            "recommend_comment": "\u6211\u5f88\u4e50\u610f\u6253\u4e94\u661f\u7684\u5076\u50cf\u5267\uff0c\u8fd1\u671f\u56fd\u4ea7\u5076\u50cf\u5267\u4e2d\u7684\u8bda\u610f\u4e4b\u4f5c\u4e86\u3002\u5b9e\u666f\u62cd\u6444\u3001\u4e3b\u6f14\u5168\u90e8\u7eaf\u6b63\u6cd5\u8bed\u53d1\u97f3\u8fd9\u4e9b\u5c0f\u7ec6\u8282\u4e0d\u8bf4\uff0c\u5267\u96c6\u8282\u594f\u4e24\u4f4d\u4e3b\u6f14\u4e5f\u662f\u62ff\u634f\u5f97\u5f20\u5f1b\u6709\u5ea6\uff0c\u8f7b\u677e\u6d3b\u6cfc\u3002\u5468\u5c14\u6587\u7684\u6bd2\u820c\u51b7\u6f20\u548c\u674e\u5357\u6069\u7684\u6d3b\u6cfc\u4e50\u89c2\u90fd\u5145\u5206\u5c55\u73b0\uff0c\u4e24\u4e2a\u4eba\u7684\u503c\u5f97\u80af\u5b9a\u7684\u6f14\u6280\u4e00\u4e0b\u5c31\u51b3\u5b9a\u4e86\u6574\u90e8\u5267\u5267\u60c5\u4e3b\u7ebf\u7684\u8d28\u91cf\uff0c\u5b8c\u5168\u4e0d\u5c34\u5c2c \u2014\u2014 \u98ce\u5341\u4e94\u6b4c\u7684\u77ed\u8bc4",
            "id": "30206447",
            "title": "群星",
            "label": null,
            "actors": ["\u5f20\u5929\u7231", "\u9648\u67cf\u9716", "\u5434\u660a\u5bb8"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u6797\u598d \/ \u5f20\u5929\u7231 \u9648\u67cf\u9716",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30206447",
            "release_date": "11.18",
            "cover": {
                "url": "https://img1.doubanio.com/view/subject/l/public/s33490619.jpg",
                "width": 4205,
                "shape": "rectangle",
                "height": 6000
            },
            "uri": "douban:\/\/douban.com\/tv\/30206447",
            "subtype": "",
            "directors": ["\u6797\u598d"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 8620,
                "max": 10,
                "value": 8.7
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u60ac\u7591 \/ \u9f9a\u671d\u6656 \/ \u8042\u8fdc \u5b8b\u8f76",
            "recommend_comment": "\u51b2\u7740\u8fd9\u6ca1\u5815\u80ce\u4e8b\u60c5\u5c31\u4e0d\u4f1a\u53d1\u751f  \u6211\u7684\u5988\u5988\u662f\u8d85\u4eba\u4e0d\u7528\u5403\u996d\u4e0d\u7528\u7761\u89c9\u8fd9\u79cd\u8bcd\u513f\u4e24\u661f\u6ca1\u6cd5\u66f4\u591a \u2014\u2014 \u6a31\u6843\u5c0f\u88ab\u7a9d\u7684\u77ed\u8bc4",
            "id": "30329153",
            "title": "醉步男",
            "label": null,
            "actors": ["\u8042\u8fdc", "\u5b8b\u8f76", "\u82a6\u82b3\u751f"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u60ac\u7591 \/ \u9f9a\u671d\u6656 \/ \u8042\u8fdc \u5b8b\u8f76",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30329153",
            "release_date": "11.18",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33499480.jpg",
                "width": 3576,
                "shape": "rectangle",
                "height": 6355
            },
            "uri": "douban:\/\/douban.com\/tv\/30329153",
            "subtype": "",
            "directors": ["\u9f9a\u671d\u6656"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 1305,
                "max": 10,
                "value": 7.7
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u53f0\u6e7e \/ \u7231\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u9ec4\u5929\u4ec1 \/ \u67ef\u4f73\u5b3f \u8bb8\u5149\u6c49",
            "recommend_comment": "\u8fd8\u662f\u6709\u79c1\u5fc3\uff0c\u5fc3\u88ab\u8bb8\u5149\u6c49\u638f\u7a7a \u2014\u2014 \u54ea\u554a\u54ea\u554a\u7684\u77ed\u8bc4",
            "id": "30468961",
            "title": "热带",
            "label": null,
            "actors": ["\u67ef\u4f73\u5b3f", "\u8bb8\u5149\u6c49", "\u65bd\u67cf\u5b87"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": false,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u53f0\u6e7e \/ \u7231\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u9ec4\u5929\u4ec1 \/ \u67ef\u4f73\u5b3f \u8bb8\u5149\u6c49",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30468961",
            "release_date": "11.17",
            "cover": {
                "url": "https://img1.doubanio.com/view/subject/l/public/s33499829.jpg",
                "width": 1000,
                "shape": "rectangle",
                "height": 1334
            },
            "uri": "douban:\/\/douban.com\/tv\/30468961",
            "subtype": "",
            "directors": ["\u9ec4\u5929\u4ec1"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 29380,
                "max": 10,
                "value": 8.1
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u9999\u6e2f \/ \u5267\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u53f6\u9547\u8f89 \/ \u9648\u5c71\u806a \u674e\u65bd\u5b05",
            "recommend_comment": "2019\u6bd4\u8f83\u770b\u5f97\u5165\u773c\u7684\u6e2f\u5267\uff0c\u4e0d\u8fc7\u53c8\u65e5\u5e38\u9ed1\u5927\u9646\u4eba\uff08\u4e0d\u662f\u4f4e\u7d20\u8d28\u7684\u6e38\u5ba2\u5c31\u662f\u5403\u5927\u8336\u996d\u7684\u52ab\u532a\uff09\uff0c\u60f3\u5f53\u5e74\u5185\u5730\u5c0f\u5b69\u5f53\u8857\u4fbf\u6eba\u88ab\u5168\u6e2f\u8ba8\u4f10\uff0c\u518d\u770b\u770b\u8fd1\u51e0\u4e2a\u6708\u5168\u6e2f\u9a9a\u4e71\uff0c\u5374\u79f0\u4e3a\u516c\u6c11\u6297\u547d\uff0c\u4e0d\u514d\u6709\u4e9b\u611f\u53f9\u550f\u5618\u3002\u5e0c\u671b\u4ee5\u540e\u8fd8\u6709\u673a\u4f1a\u770b\u5230\u66f4\u597d\u7684\u6e2f\u5267\u3002 \u2014\u2014 \u591c\u6b87\u5fae\u6059\u7684\u77ed\u8bc4",
            "id": "30156074",
            "title": "鹅",
            "label": null,
            "actors": ["\u9648\u5c71\u806a", "\u674e\u65bd\u5b05", "\u5f20\u66e6\u96ef"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": false,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u9999\u6e2f \/ \u5267\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u53f6\u9547\u8f89 \/ \u9648\u5c71\u806a \u674e\u65bd\u5b05",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30156074",
            "release_date": "09.16",
            "cover": {
                "url": "https://img9.doubanio.com/view/subject/l/public/s33489514.jpg",
                "width": 540,
                "shape": "rectangle",
                "height": 811
            },
            "uri": "douban:\/\/douban.com\/tv\/30156074",
            "subtype": "",
            "directors": ["\u53f6\u9547\u8f89"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }],
        "total": 50,
        "subject_collection": {
            "subject_type": "",
            "subtitle": "",
            "background_color_scheme": {
                "is_dark": true,
                "primary_color_light": "72261b",
                "secondary_color": "f9f5f4",
                "primary_color_dark": "4c1912"
            },
            "updated_at": null,
            "id": "tv_domestic",
            "display": {
                "layout": "list"
            },
            "show_header_mask": false,
            "medium_name": "",
            "description": "",
            "short_name": "\u56fd\u4ea7\u5267",
            "n_followers": null,
            "cover_url": "",
            "show_rank": true,
            "sharing_url": "https:\/\/www.douban.com\/doubanapp\/dispatch?uri=\/subject_collection\/tv_domestic\/",
            "subject_count": 50,
            "name": "\u8fd1\u671f\u70ed\u95e8\u56fd\u4ea7\u5267",
            "url": "https:\/\/m.douban.com\/app_topic\/tv_domestic",
            "uri": "douban:\/\/douban.com\/subject_collection\/tv_domestic",
            "mini_program_page": "",
            "icon_fg_image": "",
            "more_description": "",
            "mini_program_name": "",
            "show_filter_playable": true
        }
    });
});

 //API接口：最关注图书|非虚构类
 apiRouter.get("/book1", (req, res, next) => {
    res.send({
        "count": 8,
        "start": 0,
        "subject_collection_items": [{
            "original_price": null,
            "rating": {
                "count": 45513,
                "max": 10,
                "value": 9.1
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u53e4\u88c5 \/ \u5b59\u7693 \/ \u5f20\u82e5\u6600 \u674e\u6c81",
            "recommend_comment": "\u8fd9\u5267\u771f\u662f\u8d85\u8c6a\u534e\u9635\u5bb9\u5440\uff0c\u60f3\u770b\u9648\u9053\u660e\u548c\u5f20\u82e5\u6600\u7684\u7236\u5b50\u5927\u620f\uff0c\u5f88\u559c\u6b22\u8fbe\u5eb7\u4e66\u8bb0\u6f14\u7684\u9648\u840d\u840d\u3002 \u2014\u2014 \u9ed1\u8272\u661f\u671f\u4e94\u7684\u77ed\u8bc4",
            "id": "25853071",
            "title": "你当像鸟飞往你的山",
            "label": null,
            "actors": ["\u5f20\u82e5\u6600", "\u674e\u6c81", "\u9648\u9053\u660e"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u53e4\u88c5 \/ \u5b59\u7693 \/ \u5f20\u82e5\u6600 \u674e\u6c81",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/25853071",
            "release_date": "11.26",
            "cover": {
                "url": "https://img9.doubanio.com/view/subject/l/public/s33492346.jpg",
                "booktitle":"最受关注图书|非虚构类",
                "width": 5675,
                "shape": "rectangle",
                "height": 8000
            },
            "uri": "douban:\/\/douban.com\/tv\/25853071",
            "subtype": "",
            "directors": ["\u5b59\u7693"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 21089,
                "max": 10,
                "value": 8.6
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u7231\u60c5 \u53e4\u88c5 \/ \u6768\u6587\u519b \/ \u7f57\u664b \u674e\u4e00\u6850",
            "recommend_comment": "\u5f53\u7687\u5e1d\u4e0d\u5bb9\u6613\uff0c\u5f53\u7687\u5e1d\u513f\u5b50\u66f4\u4e0d\u5bb9\u6613\u3002\u8fd8\u597d\u8427\u5b9a\u6743\u6709\u8001\u5e08\u8205\u8205\u548c\u5c0f\u8868\u54e5\uff0c\u4e0d\u7136\u65e9\u665a\u88ab\u674e\u67cf\u821f\u4e00\u5bb6\u6b3a\u8d1f\u6b7b\u3002 \u2014\u2014 Jay Chou\u7684\u77ed\u8bc4",
            "id": "27114834",
            "title": "伊斯坦布尔三城记",
            "label": null,
            "actors": ["\u7f57\u664b", "\u674e\u4e00\u6850", "\u9ec4\u5fd7\u5fe0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u7231\u60c5 \u53e4\u88c5 \/ \u6768\u6587\u519b \/ \u7f57\u664b \u674e\u4e00\u6850",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/27114834",
            "release_date": "11.12",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33499803.jpg",
                "width": 1080,
                "shape": "rectangle",
                "height": 1919
            },
            "uri": "douban:\/\/douban.com\/tv\/27114834",
            "subtype": "",
            "directors": ["\u6768\u6587\u519b"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 21472,
                "max": 10,
                "value": 9.4
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u52a8\u4f5c \u6b66\u4fa0 \/ \u4e8e\u4e2d\u4e2d \/ \u8bb8\u51ef \u5f20\u6995\u5bb9",
            "recommend_comment": "\u8fd9\u662f\u4ec0\u4e48\u667a\u969c\u5267\u60c5\uff0c\u662f\u7ed9\u5c0f\u5b66\u751f\u770b\u7684\u5417\uff0c\u6beb\u65e0\u903b\u8f91\uff0c\u611f\u89c9\u667a\u5546\u53d7\u5230\u4e86\u4fae\u8fb1 \u2014\u2014 \u732b\u6bd4\u72d7\u53ef\u7231\u7684\u77ed\u8bc4",
            "id": "26877434",
            "title": "鸟瞰古文明",
            "label": null,
            "actors": ["\u8bb8\u51ef", "\u5f20\u6995\u5bb9", "\u6731\u5143\u51b0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u52a8\u4f5c \u6b66\u4fa0 \/ \u4e8e\u4e2d\u4e2d \/ \u8bb8\u51ef \u5f20\u6995\u5bb9",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/26877434",
            "release_date": "11.12",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33475751.jpg",
                "width": 1080,
                "shape": "rectangle",
                "height": 1520
            },
            "uri": "douban:\/\/douban.com\/tv\/26877434",
            "subtype": "",
            "directors": ["\u4e8e\u4e2d\u4e2d"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 5584,
                "max": 10,
                "value": 8.6
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u9648\u94ed\u7ae0 \/ \u738b\u5b50\u6587 \u5f20\u9c81\u4e00",
            "recommend_comment": "\u9ebb\u96c0\u7684\u65f6\u5019\u5c31\u5f88\u559c\u6b22\u5f20\u9c81\u4e00\uff0c\u8fd9\u90e8\u5267\u4e2d\u7684\u8bb8\u6717\u4e0d\u4e00\u6837\u7684\u98ce\u683c\u5c55\u73b0\uff0c\u4e5f\u5f88\u6709\u770b\u5934 \u2014\u2014 \u9b3c\u9b3c\u7684\u77ed\u8bc4",
            "id": "30299385",
            "title": "日本色气",
            "label": null,
            "actors": ["\u738b\u5b50\u6587", "\u5f20\u9c81\u4e00", "\u4e8e\u660e\u52a0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u9648\u94ed\u7ae0 \/ \u738b\u5b50\u6587 \u5f20\u9c81\u4e00",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30299385",
            "release_date": "11.20",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33446460.jpg",
                "width": 1800,
                "shape": "rectangle",
                "height": 2700
            },
            "uri": "douban:\/\/douban.com\/tv\/30299385",
            "subtype": "",
            "directors": ["\u9648\u94ed\u7ae0"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 2494,
                "max": 10,
                "value": 8.7
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u6797\u598d \/ \u5f20\u5929\u7231 \u9648\u67cf\u9716",
            "recommend_comment": "\u6211\u5f88\u4e50\u610f\u6253\u4e94\u661f\u7684\u5076\u50cf\u5267\uff0c\u8fd1\u671f\u56fd\u4ea7\u5076\u50cf\u5267\u4e2d\u7684\u8bda\u610f\u4e4b\u4f5c\u4e86\u3002\u5b9e\u666f\u62cd\u6444\u3001\u4e3b\u6f14\u5168\u90e8\u7eaf\u6b63\u6cd5\u8bed\u53d1\u97f3\u8fd9\u4e9b\u5c0f\u7ec6\u8282\u4e0d\u8bf4\uff0c\u5267\u96c6\u8282\u594f\u4e24\u4f4d\u4e3b\u6f14\u4e5f\u662f\u62ff\u634f\u5f97\u5f20\u5f1b\u6709\u5ea6\uff0c\u8f7b\u677e\u6d3b\u6cfc\u3002\u5468\u5c14\u6587\u7684\u6bd2\u820c\u51b7\u6f20\u548c\u674e\u5357\u6069\u7684\u6d3b\u6cfc\u4e50\u89c2\u90fd\u5145\u5206\u5c55\u73b0\uff0c\u4e24\u4e2a\u4eba\u7684\u503c\u5f97\u80af\u5b9a\u7684\u6f14\u6280\u4e00\u4e0b\u5c31\u51b3\u5b9a\u4e86\u6574\u90e8\u5267\u5267\u60c5\u4e3b\u7ebf\u7684\u8d28\u91cf\uff0c\u5b8c\u5168\u4e0d\u5c34\u5c2c \u2014\u2014 \u98ce\u5341\u4e94\u6b4c\u7684\u77ed\u8bc4",
            "id": "30206447",
            "title": "伦敦人",
            "label": null,
            "actors": ["\u5f20\u5929\u7231", "\u9648\u67cf\u9716", "\u5434\u660a\u5bb8"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u6797\u598d \/ \u5f20\u5929\u7231 \u9648\u67cf\u9716",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30206447",
            "release_date": "11.18",
            "cover": {
                "url": "https://img1.doubanio.com/view/subject/l/public/s33496317.jpg",
                "width": 4205,
                "shape": "rectangle",
                "height": 6000
            },
            "uri": "douban:\/\/douban.com\/tv\/30206447",
            "subtype": "",
            "directors": ["\u6797\u598d"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 8620,
                "max": 10,
                "value": 9.3
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u60ac\u7591 \/ \u9f9a\u671d\u6656 \/ \u8042\u8fdc \u5b8b\u8f76",
            "recommend_comment": "\u51b2\u7740\u8fd9\u6ca1\u5815\u80ce\u4e8b\u60c5\u5c31\u4e0d\u4f1a\u53d1\u751f  \u6211\u7684\u5988\u5988\u662f\u8d85\u4eba\u4e0d\u7528\u5403\u996d\u4e0d\u7528\u7761\u89c9\u8fd9\u79cd\u8bcd\u513f\u4e24\u661f\u6ca1\u6cd5\u66f4\u591a \u2014\u2014 \u6a31\u6843\u5c0f\u88ab\u7a9d\u7684\u77ed\u8bc4",
            "id": "30329153",
            "title": "了不起的我",
            "label": null,
            "actors": ["\u8042\u8fdc", "\u5b8b\u8f76", "\u82a6\u82b3\u751f"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u60ac\u7591 \/ \u9f9a\u671d\u6656 \/ \u8042\u8fdc \u5b8b\u8f76",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30329153",
            "release_date": "11.18",
            "cover": {
                "url": "https://img1.doubanio.com/view/subject/l/public/s33505898.jpg",
                "width": 3576,
                "shape": "rectangle",
                "height": 6355
            },
            "uri": "douban:\/\/douban.com\/tv\/30329153",
            "subtype": "",
            "directors": ["\u9f9a\u671d\u6656"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 1305,
                "max": 10,
                "value": 8.7
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u53f0\u6e7e \/ \u7231\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u9ec4\u5929\u4ec1 \/ \u67ef\u4f73\u5b3f \u8bb8\u5149\u6c49",
            "recommend_comment": "\u8fd8\u662f\u6709\u79c1\u5fc3\uff0c\u5fc3\u88ab\u8bb8\u5149\u6c49\u638f\u7a7a \u2014\u2014 \u54ea\u554a\u54ea\u554a\u7684\u77ed\u8bc4",
            "id": "30468961",
            "title": "巨浪下的小学",
            "label": null,
            "actors": ["\u67ef\u4f73\u5b3f", "\u8bb8\u5149\u6c49", "\u65bd\u67cf\u5b87"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": false,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u53f0\u6e7e \/ \u7231\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u9ec4\u5929\u4ec1 \/ \u67ef\u4f73\u5b3f \u8bb8\u5149\u6c49",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30468961",
            "release_date": "11.17",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33496763.jpg",
                "width": 1000,
                "shape": "rectangle",
                "height": 1334
            },
            "uri": "douban:\/\/douban.com\/tv\/30468961",
            "subtype": "",
            "directors": ["\u9ec4\u5929\u4ec1"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 29380,
                "max": 10,
                "value": 9.6
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u9999\u6e2f \/ \u5267\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u53f6\u9547\u8f89 \/ \u9648\u5c71\u806a \u674e\u65bd\u5b05",
            "recommend_comment": "2019\u6bd4\u8f83\u770b\u5f97\u5165\u773c\u7684\u6e2f\u5267\uff0c\u4e0d\u8fc7\u53c8\u65e5\u5e38\u9ed1\u5927\u9646\u4eba\uff08\u4e0d\u662f\u4f4e\u7d20\u8d28\u7684\u6e38\u5ba2\u5c31\u662f\u5403\u5927\u8336\u996d\u7684\u52ab\u532a\uff09\uff0c\u60f3\u5f53\u5e74\u5185\u5730\u5c0f\u5b69\u5f53\u8857\u4fbf\u6eba\u88ab\u5168\u6e2f\u8ba8\u4f10\uff0c\u518d\u770b\u770b\u8fd1\u51e0\u4e2a\u6708\u5168\u6e2f\u9a9a\u4e71\uff0c\u5374\u79f0\u4e3a\u516c\u6c11\u6297\u547d\uff0c\u4e0d\u514d\u6709\u4e9b\u611f\u53f9\u550f\u5618\u3002\u5e0c\u671b\u4ee5\u540e\u8fd8\u6709\u673a\u4f1a\u770b\u5230\u66f4\u597d\u7684\u6e2f\u5267\u3002 \u2014\u2014 \u591c\u6b87\u5fae\u6059\u7684\u77ed\u8bc4",
            "id": "30156074",
            "title": "二十世纪思想史",
            "label": null,
            "actors": ["\u9648\u5c71\u806a", "\u674e\u65bd\u5b05", "\u5f20\u66e6\u96ef"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": false,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u9999\u6e2f \/ \u5267\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u53f6\u9547\u8f89 \/ \u9648\u5c71\u806a \u674e\u65bd\u5b05",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30156074",
            "release_date": "09.16",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33489470.jpg",
                "width": 540,
                "shape": "rectangle",
                "height": 811
            },
            "uri": "douban:\/\/douban.com\/tv\/30156074",
            "subtype": "",
            "directors": ["\u53f6\u9547\u8f89"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }],
        "total": 50,
        "subject_collection": {
            "subject_type": "",
            "subtitle": "",
            "background_color_scheme": {
                "is_dark": true,
                "primary_color_light": "72261b",
                "secondary_color": "f9f5f4",
                "primary_color_dark": "4c1912"
            },
            "updated_at": null,
            "id": "tv_domestic",
            "display": {
                "layout": "list"
            },
            "show_header_mask": false,
            "medium_name": "",
            "description": "",
            "short_name": "\u56fd\u4ea7\u5267",
            "n_followers": null,
            "cover_url": "",
            "show_rank": true,
            "sharing_url": "https:\/\/www.douban.com\/doubanapp\/dispatch?uri=\/subject_collection\/tv_domestic\/",
            "subject_count": 50,
            "name": "\u8fd1\u671f\u70ed\u95e8\u56fd\u4ea7\u5267",
            "url": "https:\/\/m.douban.com\/app_topic\/tv_domestic",
            "uri": "douban:\/\/douban.com\/subject_collection\/tv_domestic",
            "mini_program_page": "",
            "icon_fg_image": "",
            "more_description": "",
            "mini_program_name": "",
            "show_filter_playable": true
        }
    });
});

 //API接口：豆瓣书店
 apiRouter.get("/book2", (req, res, next) => {
    res.send({
        "count": 8,
        "start": 0,
        "subject_collection_items": [{
            "original_price": null,
            "rating": {
                "count": 45513,
                "max": 10,
                "value": 89
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u53e4\u88c5 \/ \u5b59\u7693 \/ \u5f20\u82e5\u6600 \u674e\u6c81",
            "recommend_comment": "\u8fd9\u5267\u771f\u662f\u8d85\u8c6a\u534e\u9635\u5bb9\u5440\uff0c\u60f3\u770b\u9648\u9053\u660e\u548c\u5f20\u82e5\u6600\u7684\u7236\u5b50\u5927\u620f\uff0c\u5f88\u559c\u6b22\u8fbe\u5eb7\u4e66\u8bb0\u6f14\u7684\u9648\u840d\u840d\u3002 \u2014\u2014 \u9ed1\u8272\u661f\u671f\u4e94\u7684\u77ed\u8bc4",
            "id": "25853071",
            "title": "萨拉戈萨手稿",
            "label": null,
            "actors": ["\u5f20\u82e5\u6600", "\u674e\u6c81", "\u9648\u9053\u660e"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u53e4\u88c5 \/ \u5b59\u7693 \/ \u5f20\u82e5\u6600 \u674e\u6c81",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/25853071",
            "release_date": "11.26",
            "cover": {
                "url": "https://qnmob3.doubanio.com/view/freyr_page_photo/raw/public/4993.jpg?imageView2/0/q/80/w/9999/h/400/format/jpg",
                "booktitle":"豆瓣书店",
                "width": 5675,
                "shape": "rectangle",
                "height": 8000
            },
            "uri": "douban:\/\/douban.com\/tv\/25853071",
            "subtype": "",
            "directors": ["\u5b59\u7693"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 21089,
                "max": 10,
                "value": 64
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u7231\u60c5 \u53e4\u88c5 \/ \u6768\u6587\u519b \/ \u7f57\u664b \u674e\u4e00\u6850",
            "recommend_comment": "\u5f53\u7687\u5e1d\u4e0d\u5bb9\u6613\uff0c\u5f53\u7687\u5e1d\u513f\u5b50\u66f4\u4e0d\u5bb9\u6613\u3002\u8fd8\u597d\u8427\u5b9a\u6743\u6709\u8001\u5e08\u8205\u8205\u548c\u5c0f\u8868\u54e5\uff0c\u4e0d\u7136\u65e9\u665a\u88ab\u674e\u67cf\u821f\u4e00\u5bb6\u6b3a\u8d1f\u6b7b\u3002 \u2014\u2014 Jay Chou\u7684\u77ed\u8bc4",
            "id": "27114834",
            "title": "《你一生的故事》《呼吸》",
            "label": null,
            "actors": ["\u7f57\u664b", "\u674e\u4e00\u6850", "\u9ec4\u5fd7\u5fe0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u7231\u60c5 \u53e4\u88c5 \/ \u6768\u6587\u519b \/ \u7f57\u664b \u674e\u4e00\u6850",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/27114834",
            "release_date": "11.12",
            "cover": {
                "url": "https://qnmob3.doubanio.com/view/freyr_page_photo/raw/public/4969.jpg?imageView2/0/q/80/w/9999/h/400/format/jpg",
                "width": 1080,
                "shape": "rectangle",
                "height": 1919
            },
            "uri": "douban:\/\/douban.com\/tv\/27114834",
            "subtype": "",
            "directors": ["\u6768\u6587\u519b"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 21472,
                "max": 10,
                "value": 102.5
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u52a8\u4f5c \u6b66\u4fa0 \/ \u4e8e\u4e2d\u4e2d \/ \u8bb8\u51ef \u5f20\u6995\u5bb9",
            "recommend_comment": "\u8fd9\u662f\u4ec0\u4e48\u667a\u969c\u5267\u60c5\uff0c\u662f\u7ed9\u5c0f\u5b66\u751f\u770b\u7684\u5417\uff0c\u6beb\u65e0\u903b\u8f91\uff0c\u611f\u89c9\u667a\u5546\u53d7\u5230\u4e86\u4fae\u8fb1 \u2014\u2014 \u732b\u6bd4\u72d7\u53ef\u7231\u7684\u77ed\u8bc4",
            "id": "26877434",
            "title": "毛扎扎艺术史",
            "label": null,
            "actors": ["\u8bb8\u51ef", "\u5f20\u6995\u5bb9", "\u6731\u5143\u51b0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u52a8\u4f5c \u6b66\u4fa0 \/ \u4e8e\u4e2d\u4e2d \/ \u8bb8\u51ef \u5f20\u6995\u5bb9",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/26877434",
            "release_date": "11.12",
            "cover": {
                "url": "https://qnmob3.doubanio.com/view/freyr_page_photo/raw/public/5108.jpg?imageView2/0/q/80/w/9999/h/400/format/jpg",
                "width": 1080,
                "shape": "rectangle",
                "height": 1520
            },
            "uri": "douban:\/\/douban.com\/tv\/26877434",
            "subtype": "",
            "directors": ["\u4e8e\u4e2d\u4e2d"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 5584,
                "max": 10,
                "value": 899
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u9648\u94ed\u7ae0 \/ \u738b\u5b50\u6587 \u5f20\u9c81\u4e00",
            "recommend_comment": "\u9ebb\u96c0\u7684\u65f6\u5019\u5c31\u5f88\u559c\u6b22\u5f20\u9c81\u4e00\uff0c\u8fd9\u90e8\u5267\u4e2d\u7684\u8bb8\u6717\u4e0d\u4e00\u6837\u7684\u98ce\u683c\u5c55\u73b0\uff0c\u4e5f\u5f88\u6709\u770b\u5934 \u2014\u2014 \u9b3c\u9b3c\u7684\u77ed\u8bc4",
            "id": "30299385",
            "title": "伟大的思想（全六辑）",
            "label": null,
            "actors": ["\u738b\u5b50\u6587", "\u5f20\u9c81\u4e00", "\u4e8e\u660e\u52a0"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u9648\u94ed\u7ae0 \/ \u738b\u5b50\u6587 \u5f20\u9c81\u4e00",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30299385",
            "release_date": "11.20",
            "cover": {
                "url": "https://qnmob3.doubanio.com/view/freyr_page_photo/raw/public/5041.jpg?imageView2/0/q/80/w/9999/h/400/format/jpg",
                "width": 1800,
                "shape": "rectangle",
                "height": 2700
            },
            "uri": "douban:\/\/douban.com\/tv\/30299385",
            "subtype": "",
            "directors": ["\u9648\u94ed\u7ae0"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 2494,
                "max": 10,
                "value": 58
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u6797\u598d \/ \u5f20\u5929\u7231 \u9648\u67cf\u9716",
            "recommend_comment": "\u6211\u5f88\u4e50\u610f\u6253\u4e94\u661f\u7684\u5076\u50cf\u5267\uff0c\u8fd1\u671f\u56fd\u4ea7\u5076\u50cf\u5267\u4e2d\u7684\u8bda\u610f\u4e4b\u4f5c\u4e86\u3002\u5b9e\u666f\u62cd\u6444\u3001\u4e3b\u6f14\u5168\u90e8\u7eaf\u6b63\u6cd5\u8bed\u53d1\u97f3\u8fd9\u4e9b\u5c0f\u7ec6\u8282\u4e0d\u8bf4\uff0c\u5267\u96c6\u8282\u594f\u4e24\u4f4d\u4e3b\u6f14\u4e5f\u662f\u62ff\u634f\u5f97\u5f20\u5f1b\u6709\u5ea6\uff0c\u8f7b\u677e\u6d3b\u6cfc\u3002\u5468\u5c14\u6587\u7684\u6bd2\u820c\u51b7\u6f20\u548c\u674e\u5357\u6069\u7684\u6d3b\u6cfc\u4e50\u89c2\u90fd\u5145\u5206\u5c55\u73b0\uff0c\u4e24\u4e2a\u4eba\u7684\u503c\u5f97\u80af\u5b9a\u7684\u6f14\u6280\u4e00\u4e0b\u5c31\u51b3\u5b9a\u4e86\u6574\u90e8\u5267\u5267\u60c5\u4e3b\u7ebf\u7684\u8d28\u91cf\uff0c\u5b8c\u5168\u4e0d\u5c34\u5c2c \u2014\u2014 \u98ce\u5341\u4e94\u6b4c\u7684\u77ed\u8bc4",
            "id": "30206447",
            "title": "告别的仪式",
            "label": null,
            "actors": ["\u5f20\u5929\u7231", "\u9648\u67cf\u9716", "\u5434\u660a\u5bb8"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u7231\u60c5 \/ \u6797\u598d \/ \u5f20\u5929\u7231 \u9648\u67cf\u9716",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30206447",
            "release_date": "11.18",
            "cover": {
                "url": "https://qnmob3.doubanio.com/view/freyr_page_photo/raw/public/4680.jpg?imageView2/0/q/80/w/9999/h/400/format/jpg",
                "width": 4205,
                "shape": "rectangle",
                "height": 6000
            },
            "uri": "douban:\/\/douban.com\/tv\/30206447",
            "subtype": "",
            "directors": ["\u6797\u598d"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 8620,
                "max": 10,
                "value": 279
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u60ac\u7591 \/ \u9f9a\u671d\u6656 \/ \u8042\u8fdc \u5b8b\u8f76",
            "recommend_comment": "\u51b2\u7740\u8fd9\u6ca1\u5815\u80ce\u4e8b\u60c5\u5c31\u4e0d\u4f1a\u53d1\u751f  \u6211\u7684\u5988\u5988\u662f\u8d85\u4eba\u4e0d\u7528\u5403\u996d\u4e0d\u7528\u7761\u89c9\u8fd9\u79cd\u8bcd\u513f\u4e24\u661f\u6ca1\u6cd5\u66f4\u591a \u2014\u2014 \u6a31\u6843\u5c0f\u88ab\u7a9d\u7684\u77ed\u8bc4",
            "id": "30329153",
            "title": "宫本武藏全传",
            "label": null,
            "actors": ["\u8042\u8fdc", "\u5b8b\u8f76", "\u82a6\u82b3\u751f"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": true,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u5927\u9646 \/ \u5267\u60c5 \u60ac\u7591 \/ \u9f9a\u671d\u6656 \/ \u8042\u8fdc \u5b8b\u8f76",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30329153",
            "release_date": "11.18",
            "cover": {
                "url": "https://qnmob3.doubanio.com/view/freyr_page_photo/raw/public/4939.jpg?imageView2/0/q/80/w/9999/h/400/format/jpg",
                "width": 3576,
                "shape": "rectangle",
                "height": 6355
            },
            "uri": "douban:\/\/douban.com\/tv\/30329153",
            "subtype": "",
            "directors": ["\u9f9a\u671d\u6656"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 1305,
                "max": 10,
                "value": 8.7
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u53f0\u6e7e \/ \u7231\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u9ec4\u5929\u4ec1 \/ \u67ef\u4f73\u5b3f \u8bb8\u5149\u6c49",
            "recommend_comment": "\u8fd8\u662f\u6709\u79c1\u5fc3\uff0c\u5fc3\u88ab\u8bb8\u5149\u6c49\u638f\u7a7a \u2014\u2014 \u54ea\u554a\u54ea\u554a\u7684\u77ed\u8bc4",
            "id": "30468961",
            "title": "巨浪下的小学",
            "label": null,
            "actors": ["\u67ef\u4f73\u5b3f", "\u8bb8\u5149\u6c49", "\u65bd\u67cf\u5b87"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": false,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u53f0\u6e7e \/ \u7231\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u9ec4\u5929\u4ec1 \/ \u67ef\u4f73\u5b3f \u8bb8\u5149\u6c49",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30468961",
            "release_date": "11.17",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33496763.jpg",
                "width": 1000,
                "shape": "rectangle",
                "height": 1334
            },
            "uri": "douban:\/\/douban.com\/tv\/30468961",
            "subtype": "",
            "directors": ["\u9ec4\u5929\u4ec1"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }, {
            "original_price": null,
            "rating": {
                "count": 29380,
                "max": 10,
                "value": 9.6
            },
            "actions": [],
            "is_new_tv": false,
            "year": "2019",
            "card_subtitle": "2019 \/ \u4e2d\u56fd\u9999\u6e2f \/ \u5267\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u53f6\u9547\u8f89 \/ \u9648\u5c71\u806a \u674e\u65bd\u5b05",
            "recommend_comment": "2019\u6bd4\u8f83\u770b\u5f97\u5165\u773c\u7684\u6e2f\u5267\uff0c\u4e0d\u8fc7\u53c8\u65e5\u5e38\u9ed1\u5927\u9646\u4eba\uff08\u4e0d\u662f\u4f4e\u7d20\u8d28\u7684\u6e38\u5ba2\u5c31\u662f\u5403\u5927\u8336\u996d\u7684\u52ab\u532a\uff09\uff0c\u60f3\u5f53\u5e74\u5185\u5730\u5c0f\u5b69\u5f53\u8857\u4fbf\u6eba\u88ab\u5168\u6e2f\u8ba8\u4f10\uff0c\u518d\u770b\u770b\u8fd1\u51e0\u4e2a\u6708\u5168\u6e2f\u9a9a\u4e71\uff0c\u5374\u79f0\u4e3a\u516c\u6c11\u6297\u547d\uff0c\u4e0d\u514d\u6709\u4e9b\u611f\u53f9\u550f\u5618\u3002\u5e0c\u671b\u4ee5\u540e\u8fd8\u6709\u673a\u4f1a\u770b\u5230\u66f4\u597d\u7684\u6e2f\u5267\u3002 \u2014\u2014 \u591c\u6b87\u5fae\u6059\u7684\u77ed\u8bc4",
            "id": "30156074",
            "title": "二十世纪思想史",
            "label": null,
            "actors": ["\u9648\u5c71\u806a", "\u674e\u65bd\u5b05", "\u5f20\u66e6\u96ef"],
            "interest": null,
            "type": "tv",
            "description": "",
            "has_linewatch": false,
            "price": null,
            "date": null,
            "info": "\u4e2d\u56fd\u9999\u6e2f \/ \u5267\u60c5 \u60ac\u7591 \u5947\u5e7b \/ \u53f6\u9547\u8f89 \/ \u9648\u5c71\u806a \u674e\u65bd\u5b05",
            "url": "https:\/\/www.douban.com\/doubanapp\/dispatch\/movie\/30156074",
            "release_date": "09.16",
            "cover": {
                "url": "https://img3.doubanio.com/view/subject/l/public/s33489470.jpg",
                "width": 540,
                "shape": "rectangle",
                "height": 811
            },
            "uri": "douban:\/\/douban.com\/tv\/30156074",
            "subtype": "",
            "directors": ["\u53f6\u9547\u8f89"],
            "reviewer_name": "",
            "null_rating_reason": ""
        }],
        "total": 50,
        "subject_collection": {
            "subject_type": "",
            "subtitle": "",
            "background_color_scheme": {
                "is_dark": true,
                "primary_color_light": "72261b",
                "secondary_color": "f9f5f4",
                "primary_color_dark": "4c1912"
            },
            "updated_at": null,
            "id": "tv_domestic",
            "display": {
                "layout": "list"
            },
            "show_header_mask": false,
            "medium_name": "",
            "description": "",
            "short_name": "\u56fd\u4ea7\u5267",
            "n_followers": null,
            "cover_url": "",
            "show_rank": true,
            "sharing_url": "https:\/\/www.douban.com\/doubanapp\/dispatch?uri=\/subject_collection\/tv_domestic\/",
            "subject_count": 50,
            "name": "\u8fd1\u671f\u70ed\u95e8\u56fd\u4ea7\u5267",
            "url": "https:\/\/m.douban.com\/app_topic\/tv_domestic",
            "uri": "douban:\/\/douban.com\/subject_collection\/tv_domestic",
            "mini_program_page": "",
            "icon_fg_image": "",
            "more_description": "",
            "mini_program_name": "",
            "show_filter_playable": true
        }
    });
});

 //API接口：发现好图书
 apiRouter.get("/book3", (req, res, next) => {
    res.send({
        title: "发现好图书",
        list: [
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "小波看书"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "村上春树周边"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "我凭名字认定了你"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "不可饶恕的女人们"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "爱欲书"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "他们还写侦探小说"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "人生识字始忧患"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "诗歌书店"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "村上春树周边"
            },
            {
                url: "https://m.douban.com/doulist/37957022/",
                title: "我凭名字认定了你"
            }
        ]
    });
});








}