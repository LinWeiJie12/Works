import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import login from '@pages/login'
import home from '@pages/home'
import homeindex from '@pages/homeindex'
import selectAddress from '@pages/selectAddress'
import sellerDetails from '@pages/sellerDetails'
import goods from '@pages/goods'
import ratings from '@pages/ratings'
import sellers from '@pages/sellers'
import search from '@pages/search'
import orderform from '@pages/orderform'
import searchaddress from '@pages/searchaddress'
import myCenter from '@pages/myCenter'
import myContent from '@pages/myContent'
import discovery from '@pages/discovery'



Vue.use(Router)

export default new Router({
  routes: [
  
    {
      path: '/',
      name: 'login',
      component: login
    },
    {
      path: '/home',
      name: 'home',
      component: home,
      children:[{
        path: '/home/homeindex',
        name: 'homeindex',
        component: homeindex,
      },
      {
        path: '/home/orderform',
        name: 'orderform',
        component: orderform
      },
      {
        path: '/home/myCenter',
        name: 'myCenter',
        component: myCenter
      },
      {
        path: '/home/discovery',
        name: 'discovery',
        component: discovery
      },
      ]
    },
    {
      path: '/myContent',
      name: 'myContent',
      component: myContent,
    },
    {
      path: '/selectAddress',
      name: 'selectAddress',
      component: selectAddress,
    },
    {
      path: '/searchaddress',
      name: 'searchaddress',
      component: searchaddress,
    }, 


    {
      path: '/search',
      name: 'search',
      component: search,
      
    }, 
    {
      path: '/sellerDetails',
      name: 'sellerDetails',
      component: sellerDetails,
      children:[ {
        path: '/sellerDetails/goods',
        name: 'goods',
        component: goods
      },
      {
        path: '/sellerDetails/ratings',
        name: 'ratings',
        component: ratings
      },
      {
        path: '/sellerDetails/sellers',
        name: 'sellers',
        component: sellers
      }
     ]
    },
  ]
})
