<template>
  <div class="hello">
  <div>未达到哇无多</div>
  <input type="button" value="点击事件" @click="abc">

  <i class="iconfont icon-iconset0187"></i>


<van-image
  round
  width="10rem"
  height="10rem"
  src="https://img.yzcdn.cn/vant/cat.jpeg"
/>



  </div>
</template>

<script>
import {Toast} from 'vant';
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    };
  },
  methods:{
    abc(){
      console.log("wadawawdawda");
        // 调用函数组件，弹出一个 Toast
       Toast.loading({
       duration: 0, // 持续展示 toast
       forbidClick: true,
      message: '倒计时 3 秒'
      });
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
