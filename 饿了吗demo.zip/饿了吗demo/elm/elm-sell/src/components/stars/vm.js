// import { mapActions } from "vuex";
// import { tool } from "commonJs/tool";
// import { Toast } from "vant";
// import axios from "axios";

//导入模拟数据
// require("mock/login.js");

export default {
    name: ''
    , props: ['starsWidth']

    , data() {
        return {

        }
    }
    , components: {}
    , watch: {}
    , computed: {}
    , mounted() { }
    , methods: {}

}
