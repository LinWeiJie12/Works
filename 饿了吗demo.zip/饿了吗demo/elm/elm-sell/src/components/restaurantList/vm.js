export default {
    name: '',
    props: {
       list:{
           default(){
               return[];
           }
       }

    },
    data() {
        return {
            isshuX: false
        };
    },
    components: {},
    created() { },
    //监听器
    watch: {
         list(){
             console.log(this.list);
         }
    },
    //计算属性
    computed: {

    },
    mounted() {
         console.log(this.list);
    },
    methods: {
        go(item) {
            this.$router.push({
                name: `goods`,
                query: {
                    id: item.restaurant.id
                }
            });

        }
    }
};