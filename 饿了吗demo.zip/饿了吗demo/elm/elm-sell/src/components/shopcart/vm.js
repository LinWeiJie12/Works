import { mapGetters, mapState, mapMutations, mapActions } from "vuex";
//上拉加载更多组件
import scrollY from "components/scrollY";
import { Dialog } from 'vant'; 
export default {
    name: '',
    props: {},
    data() {
        return {
             //控制购物车列表的显示和隐藏
             isShowShopCartList: false,
               //定时器
               timer: null
            };
    },
    components: {
        scrollY
    },
    created() { },
    //监听器
    watch: {
        shopCart() {
            clearTimeout(this.timer);
            this.$nextTick(() => {
                this.timer = setTimeout(() => {
                    this.$refs.scrolly1.setMin();
                }, 2000);
            });

        }
    },
    //计算属性
    computed: {
        ...mapState(['seller','shopCart']),
        ...mapGetters(['hasGoods','payShopCartPrice','shopGoodsSize',]),
       //支付状态
       isPayEnough(){
       //最低配送费
       let minPrice = this.seller.minPrice;
       let resultPrice = minPrice - this.payShopCartPrice;
       let resultStr = ``;
       if (resultPrice > 0) {
           resultStr = `还差${resultPrice}元起送`;
       } else {
           resultStr = `去结算`;
       }
        
       return resultStr;
       }
        
    },
    mounted() {
        this.$refs.scrolly1.fire();
    },
    methods: {
        ...mapActions(['addGoodsToShopCat','delShopCartGoodsByIdAction','clearShopcatAction']),
       //清空购物车
       clearShopCart() {
        Dialog.confirm({
            title: '清空购物车',
            message: '确定清空购物车数据吗？'
        }).then(() => {
            this.clearShopcatAction().then(() => {
                this.isShowShopCartList = false;
            });
        }).catch(() => {
            // on cancel
        });

    },
        //显示购物车
        showShopList(){
            this.isShowShopCartList=true
        },
        //隐藏购物车
        hideList() {
            this.isShowShopCartList = false;
        },
         //删除购物车中商品方法
         delShopFn(item) {
            this.delShopCartGoodsByIdAction(item);
        },
        //添加购物车中商品方法
        addShopFn(item) {
            this.addGoodsToShopCat(item);
        }
    }
};