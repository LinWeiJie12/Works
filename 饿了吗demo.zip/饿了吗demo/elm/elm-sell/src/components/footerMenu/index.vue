<style scoped lang="less" src="./vs.less"></style>
<template>

  <footer
    class="footer-ctn"
    id="footer-container"
    ref="footerMenu"
  >
    <section class="ui-row-flex">
      <section class="ui-col ui-col fm-cell">
        <router-link to="/home/homeIndex">
          <span class="iconfont">&#xe61f;</span>
          <span class="fm-tip">首页</span>
        </router-link>
      </section>
      <section class="ui-col ui-col fm-cell">
        <router-link to="/home/discovery">
          <span class="iconfont">&#xe620;</span>
          <span class="fm-tip">发现</span>
        </router-link>
      </section>
      <section class="ui-col ui-col fm-cell">
        <router-link to="/home/orderform">
          <span class="iconfont">&#xe68e;</span>
          <span class="fm-tip">订单</span>
        </router-link>
      </section>
      <section class="ui-col ui-col fm-cell">
        <router-link to="/home/myCenter">
          <span class="iconfont">&#xe6a3;</span>
          <span class="fm-tip">我的</span>
        </router-link>
      </section>
    </section>
  </footer>

</template>
<script src = "./vm.js"></script>