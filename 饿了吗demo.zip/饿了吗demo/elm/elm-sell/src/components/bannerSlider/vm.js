// 无缝轮播图插件------------
import vSlider from "assetsPlugin/vSlider/vSlider.js";
import "assetsPlugin/vSlider/vSlider.less";
// 无缝轮播图插件__end------------


export default {
    name: '',
    props: {
        bannerList:{
            default(){
                return[];
            }
        }
    },
    data() {
        return {
            //轮播图容器的ID，必须保证唯一性
           sliderId:""
        };
    },
    components: {},
    created() { },
    //监听器
    watch: {
     bannerList(){
         
         this.initSlider();
     }
    },
    //计算属性
    computed: {

    },
    mounted() {
        this.sliderId = "vSliderId_" + parseInt((Math.random() * 10000));
       
      

        this.initSlider();


    },




    methods: {
    initSlider(){
        if(this.bannerList.length==0){
            return;
        }

        this.$nextTick(()=>{
            vSlider({
                id:this.sliderId
                   });
        });
    }
    }
};