<style scoped lang="less" src="./vs.less"></style>
<template>

  <div class="bannermenu">
 <van-swipe >
        <van-swipe-item>
          <ul class="menu">
            <li class="menu1">
              <img src="./img/烤鸡.jpg" alt />
              <p>美食</p>
            </li>
            <li class="menu2">
              <img src="./img/大牌惠吃.jpg" alt />
              <p>大牌惠吃</p>
            </li>
            <li class="menu3">
              <img src="./img/超市便利.jpg" alt />
              <p>超市便利</p>
            </li>
            <li class="menu4">
              <img src="./img/水果.jpg" alt />
              <p>水果</p>
            </li>
            <li class="menu5">
              <img src="./img/医药.jpg" alt />
              <p>医药健康</p>
            </li>
            <li class="menu6">
              <img src="./img/浪漫鲜花.jpg" alt />
              <p>浪漫鲜花</p>
            </li>
             <li class="menu7">
              <img src="./img/跑腿代购.jpg" alt />
              <p>跑腿代购</p>
            </li>
            <li class="menu8">
              <img src="./img/汉堡披萨.jpg" alt />
              <p>汉堡披萨</p>
            </li>
             <li class="menu9">
              <img src="./img/厨房生鲜.jpg" alt />
              <p>厨房生鲜</p>
            </li>
             <li class="menu10">
              <img src="./img/甜品饮品.jpg" alt />
              <p>甜品饮品</p>
            </li>
          </ul>
        </van-swipe-item>
        <van-swipe-item>
           <ul class="menu">
           <li class="menu1">
              <img src="./img/烤鸡.jpg" alt />
              <p>美食</p>
            </li>
            <li class="menu2">
              <img src="./img/大牌惠吃.jpg" alt />
              <p>大牌惠吃</p>
            </li>
            <li class="menu3">
              <img src="./img/超市便利.jpg" alt />
              <p>超市便利</p>
            </li>
            <li class="menu4">
              <img src="./img/水果.jpg" alt />
              <p>水果</p>
            </li>
           </ul>
        </van-swipe-item>
      </van-swipe>
  </div>

</template>
<script src = "./vm.js"></script>



