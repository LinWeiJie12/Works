const mixins = {
    data() {
        return {
            title: '哈哈'
        }
    },
    methods: {
        goto() {
            console.log('abc');
        }
    }
};

export default mixins;