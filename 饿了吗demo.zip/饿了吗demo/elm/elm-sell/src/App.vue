<template>
  <div id="app">
  
    <transition name="go">
    <router-view />
    </transition>



  </div>
</template>

<script>


export default {
  name: 'App'
}
</script>

<style lang="less"  scoped>
#app {
touch-action: none;


//  .go-leave{
//     opacity: 0;
//   }

//   .go-leave-to{
//     opacity: 0;
//   }

//  .go-enter{
//     opacity: 0;
//   }

//  .go-enter-active{
//     animation: bounce-in 0.3s;
//   }

//   .go-enter-to{
//     opacity: 1;
//   }

//   @keyframes bounce-in {
//     0%{
//       transform: scale(0.96);
//     }
//    100%{
//       transform: scale(1);
//     }
//   }

// -------------------------------------淡入淡出
    // .go-enter-active,  .go-leave-active {
    //     transition: opacity .5s;
    // }
    // .go-enter,  .go-leave-to /* .fade-leave-active below version 2.1.8 */ {
    //     opacity: 0;
    // }
// ---------------------------------------------



    .go-item {
        display: inline-block;
        margin-right: 10px;
    }
    .go-enter-active, .go-leave-active {
        transition: all 0.5s;
    }
    .go-enter, .go-leave-to
       {
        opacity: 0;
        transform: translateX(30px);
        }
// ----------------------------------------------------------------------
// .go-enter-active,
//     .go-leave-active {
//         transition: all 0.5s;
//     }

//     .go-enter,
//   .go-leave-to {
//         opacity: 0;
//         transform: translateX(15%);
//     }
}
</style>
