//根级别的actions

import * as types from './mutation-types'
import axios from "axios";
import { Toast } from "vant";


const actions = {
    // --------------------------------------------------------
    //用户登录
    async loginAction({ dispatch, commit }, obj) {
        console.log(obj);
        return new Promise((resolve, reject) => {
        

            Toast({
                type:"loading",
                message:"登录中...",
                mask:true,
                duration:0
            })

            setTimeout(() => {
               
                axios.post('/login',{
                    phone:obj.phone,
                    yzm: obj.yzm
                  
                  }).then(res => {
                   Toast.clear()
                    console.log(res);
                    console.log(`服务返回的数据:${res.data.msg}`);
                    commit(types.SET_USERINFO,res.data.data);
                    resolve(res.data.data);
                })
                  .catch(error => {
                      console.log(error);
                      console.log("服务异常，请联系管理员!");
            });

        }, 1000);
    });    
    },
    // --------------------------------------------------------

     /**
     * 添加购物车数据
     * @param {*} param0 
     * @param {*} obj 
     */
    async addGoodsToShopCat({ dispatch, commit, state }, goods) {

      Toast.loading({
          duration: 0, // 持续展示 toast
          forbidClick: false,
          mask: true,
          message: '添加中...'
      });

      return new Promise((resolve, reject) => {

          setTimeout(() => {

              //添加购物车数据
              axios.post('/addShopCartfn', {
                  goods: goods
              }).then(res => {
                  Toast.clear();
                  //使用mutation，修改购物车数据
                  commit(types.SET_SHOPCART, goods);
                  resolve();
              }).catch(error => {
                  console.log(error);
                  reject();
              });

          }, 300);

      });

  },
  /**
   * 删除购物车数据
   */
  async delShopCartGoodsByIdAction({ commit, state }, goods) {
      Toast.loading({
          duration: 0, // 持续展示 toast
          forbidClick: false,
          mask: true,
          message: '删除中...'
      });

      return new Promise((resolve, reject) => {

          setTimeout(() => {
              //添加购物车数据
              axios.post('/delShopCartById', {
                  goods: goods
              }).then(res => {
                  Toast.clear();
                  //使用mutation，删除方法
                  commit(types.DEL_SHOPCARTGOODSBYID, goods);
                  resolve();
              }).catch(error => {
                  console.log(error);
                  reject();
              });

          }, 300);
      });
  },
     /**
     * 清空购物车
     */
    async clearShopcatAction({ commit, state }) {
        Toast.loading({
            duration: 0, // 持续展示 toast
            forbidClick: false,
            mask: true,
            message: '清空中...'
        });

        return new Promise((resolve, reject) => {

            setTimeout(() => {
                //添加购物车数据
                axios.post('/clearShopCartByUserId', {
                    userid: state.userInfo.user_id
                }).then(res => {
                    Toast.clear();
                    //使用mutation，清空方法
                    commit(types.CLEAR_SHOPCARTBYID);
                    resolve();
                }).catch(error => {
                    console.log(error);
                    reject();
                });

            }, 800);
        });

    }


};
export default actions;