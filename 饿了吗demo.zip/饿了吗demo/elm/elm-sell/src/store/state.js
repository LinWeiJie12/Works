//根级别的state
const state = {
    //用户信息
    userInfo: {
        avatar: "",
        balance: 0,
        brand_member_new: 0,
        columns: [],
        delivery_card_expire_days: 0,
        email: "",
        gift_amount: 0,
        is_email_valid: false,
        is_mobile_valid: true,
        mobile: "--",
        point: 0,
        real_point: 0,
        supervip_status: 3,
        user_id: 0,
        username: ""
    },
    //商家信息
    seller: {
        id: "",
        name: "",
        description: "",
        deliveryTime: 0,
        score: 0,
        serviceScore: 0,
        foodScore: 0,
        rankRate: 0,
        minPrice: 0,
        deliveryPrice: 0,
        ratingCount: 0,
        sellCount: 0,
        bulletin: "",
        supports: [],
        avatar: "/static/images/sellerHeader/seller_avatar_256px.jpg",
        pics: [],
        infos: [],
    },
    //商家评论数据
    sellerRatings: [],
    //购物车
    shopCart: [],
    //购物车临时数据
    //作用：保存的是每次添加进来的商品信息
    tempShopCart: [],
};

export default state;