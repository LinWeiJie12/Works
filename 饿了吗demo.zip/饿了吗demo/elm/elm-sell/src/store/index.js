import Vue from 'vue'
import Vuex from 'vuex'
import createLogger from 'vuex/dist/logger'
import actions from './actions'
import mutations from './mutations'
import getters from './getters'
import state from './state'

Vue.use(Vuex);//

const debug = process.env.NODE_ENV !== 'production'; //如果不是生产环境，那么就开启仓库的debug功能，也就是可以在控制台看到输出信息

export default new Vuex.Store({
    //数据源
    state,
    getters,
    //修改数据源状态行为
    mutations,
    actions,
    strict: debug,
    plugins: debug ? [createLogger()] : []
})