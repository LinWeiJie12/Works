// export const INCREMENT = 'INCREMENT'
// export const INCREMENTV2 = 'INCREMENTV2'
//设置用户信息
export const SET_USERINFO = 'SET_USERINFO'
//设置商家数据
export const SET_SELLERINFO = 'SET_SELLERINFO'
//添加购物车数据
export const SET_SHOPCART = 'SET_SHOPCART'
//删除购物车数据
export const DEL_SHOPCARTGOODSBYID = 'DEL_SHOPCARTGOODSBYID'
//清空购物车方法
export const CLEAR_SHOPCARTBYID = 'CLEAR_SHOPCARTBYID'