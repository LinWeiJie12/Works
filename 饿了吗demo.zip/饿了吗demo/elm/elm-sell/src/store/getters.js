//根级别的getters
const getters = {
    //购物车派生出新的状态
    hasGoods(state) {
        return state.tempShopCart.length > 0;
    },
    //购物车需要支付的总金额
    payShopCartPrice(state) {
        let totalPrice = 0;
        state.tempShopCart.forEach(item => {
            totalPrice += item.price;
        });
        return totalPrice;
    },
    //购物车中的商品数量
    shopGoodsSize(state) {
        return state.tempShopCart.length;
    }
};

export default getters;