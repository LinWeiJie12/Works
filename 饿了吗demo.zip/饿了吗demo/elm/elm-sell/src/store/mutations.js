//根级别的mutations
//import { INCREMENT, INCREMENTV2 } from './mutation-types'
import * as types from './mutation-types.js'
import { tool } from 'commonJs/tool.js'


const mutations = {
    /**
     * 设置用户信息
     * @param {*} state 
     * @param {*} obj 
     */
    [types.SET_USERINFO](state, userinfo) {
        state.userinfo = userinfo;
    },
    
    /**
     * 设置商家信息
     * @param {*} state 
     * @param {*} sellerInfo 
     */
    [types.SET_SELLERINFO](state, sellerInfo) {
       
        state.seller = sellerInfo;
    },



    /**
     * 添加购物车数据
     * @param {*} state 
     * @param {*} goodsInfo
     */
    [types.SET_SHOPCART](state, goodsInfo) {
        //整合重复数据
        //将新数据中的每个元素，添加一个count属性
        state.tempShopCart.push(goodsInfo);
        let arr = tool.extendv2([], state.tempShopCart);
        //state.shopCart.push(goodsInfo);
        let newArr = [];
        dd(arr, newArr);
        state.shopCart = newArr;

    },
     /**
     * 删除购物车中的指定的数据
     */
    [types.DEL_SHOPCARTGOODSBYID](state, food) {
        for (let j = state.tempShopCart.length - 1; j >= 0; j--) {
            let element = state.tempShopCart[j];
            if (element.name == food.name) {
                state.tempShopCart.splice(j, 1);
                break;
            }
        }
        //删除正式的购物车数据
        //原理：通过商品名称，找到要删除的商品，然后先将其count--,如果count=1,直接将商品从购物车中删除掉！
        for (let i = 0; i < state.shopCart.length; i++) {
            let ele = state.shopCart[i];
            if (ele.name == food.name) {
                if (ele.count == 1) {
                    state.shopCart.splice(i, 1);
                } else {
                    state.shopCart[i].count--;
                    console.log("调用递减方法");
                }
                break;
            }
        }

          //强制触发vue数据更新！
          state.shopCart = [...state.shopCart];

    },
      /**
     * 清空购物车
     */
    [types.CLEAR_SHOPCARTBYID](state) {
        state.tempShopCart = [];
        state.shopCart = [];
    }
};



/**
 * 递归迭代数据
 * 将count属性添加到每个元素中
 *
 * @param {*} list
 * @param {*} newList
 */
function dd(list, newList) {
    let first = list.shift();

    if (newList.length > 0) {
        let flag = false;
        newList.forEach(ele => {
            if (ele.name == first.name) {
                ele.count++;
                flag = true;
            }
        });
        if (!flag) {
            newList.push(first);
            newList[newList.length - 1].count = 1;
        }
    } else {
        newList.push(first);
        newList[newList.length - 1].count = 1;
    }
    if (list.length > 0) {
        dd(list, newList);
    }
}

export default mutations;