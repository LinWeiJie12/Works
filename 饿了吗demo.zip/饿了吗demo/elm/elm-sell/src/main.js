import Vue from 'vue'
import App from './App'
import router from './router'
//导入fastclick模块
import fastclick from "fastclick";
//导入全局数据仓库
import store from 'vuexStore'
//导入全局样式文件
import "baseStyle/index.less";
Vue.config.productionTip = false

//应用安装vant框架
import Vant from 'vant';
import 'vant/lib/index.css';
Vue.use(Vant);




let appFn = {
  /**
   * 注册fastclick
  */
  initFastClick() {
    //安装fastclick
    fastclick.attach(document.body);
  },
  initFontFn() {
    !(function () {
      var e = window.document,
        t = e.documentElement,
        o = "orientationchange" in window ? "orientationchange" : "resize",
        baseVal = 62.5, //基础值
        a = function () {
          //屏幕的宽度
          //clientWidth / offsetWidth 的区别
          var winWidth = t.clientWidth,
            resultFontSize = 62.5;
          //屏幕的最小阈值：320
          //屏幕的最大阈值：960
          if (winWidth <= 320) {
            resultFontSize = baseVal;
          } else if (winWidth <= 960) {
            resultFontSize = baseVal + ((winWidth - 320) /
              1020) * 100;
          } else {
            //如果超过960，页面始终以126%
            resultFontSize = 126;
          }
          //根元素字体设置
          t.style.fontSize = resultFontSize + "%";
        };
      e.addEventListener &&
        (window.addEventListener(o, a, !1), e.addEventListener("DOMContentLoaded", a, !1))
    })();
  },
  /**
   * 设置全局路由守卫
   */
  setRouteFn() {

    //添加全局路由守卫
    router.beforeEach((to, from, next) => {
 
      // console.log("全局路由守卫......")
      // console.log(to)
      // console.log(from)
      // console.log("全局路由守卫......————end")
      next();
    });
  },
  fire() {
    appFn.initFastClick();
    appFn.initFontFn();
    appFn.setRouteFn();
  }
};

appFn.fire();







/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
