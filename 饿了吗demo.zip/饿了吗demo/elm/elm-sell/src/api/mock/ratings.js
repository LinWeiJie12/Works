
var Mock = require("mockjs");

/**
 * 用户评论接口
 */
Mock.mock("/comments", {
    //统一返回数据
    data:
        [{
            "avatar": "56943042b908fcdd8097119e8d98872ejpeg",
            "food_ratings": [{
                "food_id": 1532989380,
                "rate_name": "益禾烤奶-",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000340969436218,
                "sku_id_str": "200000340969436218"
            }, {
                "food_id": 1532984903,
                "rate_name": "冰激凌红茶-",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000340977546298,
                "sku_id_str": "200000340977546298"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532989380, 1532984903],
                "food_names": ["益禾烤奶-", "冰激凌红茶-"],
                "image_hash": "fb65e92d18643ff08130dcfb4e158435jpeg"
            }],
            "rated_at": "2019-10-17",
            "rating": 5,
            "rating_text": "奈何本人没文化，一句不错走天下（随便推广下福师大抖音小葵公众号）(｢･ω･)｢嘿",
            "img": "/static/images/user/1.png",
            "img1": "/static/images/userfoos/2.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-10-17 14:51:57"
            },
            "tags": [""],
            "time_spent_desc": "30分钟送达",
            "username": "我***水"
        }, {
            "avatar": "4acde4c039d2e6e56b926bc5ab899b39jpeg",
            "food_ratings": [{
                "food_id": 1532981133,
                "rate_name": "禾风奶绿-",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000340972609594,
                "sku_id_str": "200000340972609594"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532981133],
                "food_names": ["禾风奶绿-"],
                "image_hash": "9f118d87858835a66e947112aadcdcf3jpeg"
            }, {
                "food_ids": [1532981133],
                "food_names": ["禾风奶绿-"],
                "image_hash": "741e53da23d35d1c6de50f4101b76f48jpeg"
            }],
            "rated_at": "2019-10-08",
            "rating": 5,
            "rating_text": "关注公众号:小猫外卖，可每天领取饿了么5-15元无门槛红包券",
            "img": "/static/images/user/5.png",
            "img1": "/static/images/userfoos/7.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-10-08 21:44:59"
            },
            "tags": [""],
            "time_spent_desc": "30分钟送达",
            "username": "I***迅"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 1532984903,
                "rate_name": "冰激凌红茶-",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000340977546298,
                "sku_id_str": "200000340977546298"
            }, {
                "food_id": 1485965278,
                "rate_name": "珍珠",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000292828469306,
                "sku_id_str": "200000292828469306"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532984903, 1485965278],
                "food_names": ["冰激凌红茶-", "珍珠"],
                "image_hash": "1ac26e3e242aee878961e251739e1d42jpeg"
            }],
            "rated_at": "2019-10-08",
            "rating": 5,
            "rating_text": "爱了，超好喝",
            "img": "/static/images/user/2.png",
            "img1": "/static/images/userfoos/2.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-10-08 21:44:59"
            },
            "tags": [""],
            "time_spent_desc": "",
            "username": "匿名用户"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200017220278,
                "rate_name": "蜜桃乌龙-",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000410868702266,
                "sku_id_str": "200000410868702266"
            }, {
                "food_id": 200061157926,
                "rate_name": "冰激凌",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000455887228986,
                "sku_id_str": "200000455887228986"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": true,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200017220278],
                "food_names": ["蜜桃乌龙-"],
                "image_hash": "581b0a6a74e0f70d0423fccbe0875db3jpeg"
            }],
            "rated_at": "2019-10-07",
            "rating": 5,
            "rating_text": "加了冰激凌之后，瞬间从非常好吃变成一般好吃",
            "img": "/static/images/user/3.png",
            "img1": "/static/images/userfoos/3.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-10-07 14:47:06"
            },
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "b*********5"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200015677110,
                "rate_name": "蜜桃乌龙",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000409283653690,
                "sku_id_str": "200000409283653690"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": true,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200015677110],
                "food_names": ["蜜桃乌龙"],
                "image_hash": "5428e8bb3818f7495f3f3b7155c90b84jpeg"
            }],
            "rated_at": "2019-10-03",
            "rating": 5,
            "rating_text": "好喝",
            "img": "/static/images/user/4.png",
            "img1": "/static/images/userfoos/3.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-10-03 21:44:48"
            },
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "b*********5"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 1532981145,
                "rate_name": "冻柠绿-",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000340977557562,
                "sku_id_str": "200000340977557562"
            }, {
                "food_id": 200017220278,
                "rate_name": "蜜桃乌龙-",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000410868702266,
                "sku_id_str": "200000410868702266"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532981145],
                "food_names": ["冻柠绿-"],
                "image_hash": "57a25c670329a8095f2e9c8501c72ebfjpeg"
            }],
            "rated_at": "2019-09-29",
            "rating": 5,
            "rating_text": "不错",
            "img": "/static/images/user/1.png",
            "img1": "/static/images/userfoos/5.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-29 14:52:26"
            },
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "5*********c"
        }, {
            "avatar": "4acde4c039d2e6e56b926bc5ab899b39jpeg",
            "food_ratings": [{
                "food_id": 1532981133,
                "rate_name": "禾风奶绿-",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000340972609594,
                "sku_id_str": "200000340972609594"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532981133],
                "food_names": ["禾风奶绿-"],
                "image_hash": "9f118d87858835a66e947112aadcdcf3jpeg"
            }, {
                "food_ids": [1532981133],
                "food_names": ["禾风奶绿-"],
                "image_hash": "741e53da23d35d1c6de50f4101b76f48jpeg"
            }],
            "rated_at": "2019-09-28",
            "rating": 5,
            "rating_text": "关注公众号:小猫外卖，可每天领取饿了么5-15元无门槛红包券",
            "img": "/static/images/user/1.png",
            "img1": "/static/images/userfoos/6.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-29 00:45:05"
            },
            "tags": [""],
            "time_spent_desc": "30分钟送达",
            "username": "I***迅"
        }, {
            "avatar": "56943042b908fcdd8097119e8d98872ejpeg",
            "food_ratings": [{
                "food_id": 1532984903,
                "rate_name": "冰激凌红茶-",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000340977546298,
                "sku_id_str": "200000340977546298"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532984903],
                "food_names": ["冰激凌红茶-"],
                "image_hash": "2db7654aebdaf62bd1063a27b9335bd9jpeg"
            }, {
                "food_ids": [1532984903],
                "food_names": ["冰激凌红茶-"],
                "image_hash": "a1c0263be4a04ab46116ecd5f721797bjpeg"
            }],
            "rated_at": "2019-09-27",
            "rating": 5,
            "rating_text": "关注微信公众号：猪侠外卖助手 ，可每天领取饿了么5-15元红包券\n\n点完餐还未评价的盆友，可以联系公众号客服，赚点餐红包奖励",
            "img": "/static/images/user/3.png",
            "img1": "/static/images/userfoos/2.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-27 14:50:49"
            },
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "我***水"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 1485965278,
                "rate_name": "珍珠",
                "rating": 5,
                "rating_text": "珍珠 禾风奶绿- 真的好好喝！！强推",
                "sku_id": 200000292828469306,
                "sku_id_str": "200000292828469306"
            }, {
                "food_id": 1532981133,
                "rate_name": "禾风奶绿-",
                "rating": 5,
                "rating_text": "珍珠 禾风奶绿- 真的好好喝！！强推",
                "sku_id": 200000340972609594,
                "sku_id_str": "200000340972609594"
            }],
            "highlights_v2": {
                "珍珠": 200000292828469306,
                "禾风奶绿-": 200000340972609594
            },
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1485965278, 1532981133],
                "food_names": ["珍珠", "禾风奶绿-"],
                "image_hash": "f7b4c28dd4659ea41a1941a91ecf56a9jpeg"
            }],
            "rated_at": "2019-09-24",
            "rating": 5,
            "rating_text": "珍珠 禾风奶绿- 真的好好喝！！强推",
            "img": "/static/images/user/2.png",
            "img1": "/static/images/userfoos/6.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-24 22:09:05"
            },
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "匿名用户"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 1532989380,
                "rate_name": "益禾烤奶-",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000340969436218,
                "sku_id_str": "200000340969436218"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532989380],
                "food_names": ["益禾烤奶-"],
                "image_hash": "5eb4decb985e742a76207bd2511a4099jpeg"
            }],
            "rated_at": "2019-09-24",
            "rating": 5,
            "rating_text": "还可以",
            "img": "/static/images/user/1.png",
            "img1": "/static/images/userfoos/7.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-24 22:09:05"
            },
            "tags": [""],
            "time_spent_desc": "30分钟送达",
            "username": "4*******c"
        }, {
            "avatar": "56943042b908fcdd8097119e8d98872ejpeg",
            "food_ratings": [{
                "food_id": 1532984912,
                "rate_name": "泷珠奶绿",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000340969438266,
                "sku_id_str": "200000340969438266"
            }, {
                "food_id": 1532984924,
                "rate_name": "宇治抹茶-",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000340972621882,
                "sku_id_str": "200000340972621882"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532984912],
                "food_names": ["泷珠奶绿"],
                "image_hash": "304985dc750d681de99bd3af580ed9e3jpeg"
            }, {
                "food_ids": [1532984912],
                "food_names": ["泷珠奶绿"],
                "image_hash": "28307f5863dfcb833825b0c4cd0e24dbjpeg"
            }],
            "rated_at": "2019-09-24",
            "rating": 5,
            "rating_text": "关注微信公众号：最大外卖包 ，可每天领取饿了么5-15元红包券。\n\n点完餐还未评价的盆友，可以联系公众号客服，赚点餐红包奖励p",
            "img": "/static/images/user/5.png",
            "img1": "/static/images/userfoos/7.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-24 22:09:06"
            },
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "我***水"
        }, {
            "avatar": "56943042b908fcdd8097119e8d98872ejpeg",
            "food_ratings": [{
                "food_id": 1532978107,
                "rate_name": "冰激凌红茶",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000340977551418,
                "sku_id_str": "200000340977551418"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532978107],
                "food_names": ["冰激凌红茶"],
                "image_hash": "304985dc750d681de99bd3af580ed9e3jpeg"
            }, {
                "food_ids": [1532978107],
                "food_names": ["冰激凌红茶"],
                "image_hash": "28307f5863dfcb833825b0c4cd0e24dbjpeg"
            }],
            "rated_at": "2019-09-24",
            "rating": 5,
            "rating_text": "关注微信公众号：最大外卖包 ，可每天领取饿了么5-15元红包券。\n\n点完餐还未评价的盆友，可以联系公众号客服，赚点餐红包奖励",
            "img": "/static/images/user/1.png",
            "img1": "/static/images/userfoos/2.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-24 22:09:06"
            },
            "tags": [""],
            "time_spent_desc": "30分钟送达",
            "username": "我***水"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 1532984912,
                "rate_name": "泷珠奶绿",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000340969438266,
                "sku_id_str": "200000340969438266"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532984912],
                "food_names": ["泷珠奶绿"],
                "image_hash": "51b428d6bd855746cc0e11430b5d5bb0jpeg"
            }],
            "rated_at": "2019-09-23",
            "rating": 5,
            "rating_text": "关注微信公众号：最大外卖包 ，可每天领取饿了么5-15元红包券。\n\n点完餐还未评价的盆友，可以联系公众号客服，赚点餐红包奖励",
            "img": "/static/images/user/1.png",
            "img1": "/static/images/userfoos/2.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-23 21:52:18"
            },
            "tags": [""],
            "time_spent_desc": "按时送达",
            "username": "D******S"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200017220278,
                "rate_name": "蜜桃乌龙-",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000410868702266,
                "sku_id_str": "200000410868702266"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200017220278],
                "food_names": ["蜜桃乌龙-"],
                "image_hash": "51b428d6bd855746cc0e11430b5d5bb0jpeg"
            }],
            "rated_at": "2019-09-23",
            "rating": 5,
            "rating_text": "关注微信公众号：最大外卖包 ，可每天领取饿了么5-15元红包券。\n\n点完餐还未评价的盆友，可以联系公众号客服，赚点餐红包奖励",
            "img": "/static/images/user/2.png",
            "img1": "/static/images/userfoos/2.jpg", 
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-23 21:52:18"
            },
            "tags": [""],
            "time_spent_desc": "按时送达",
            "username": "D******S"
        }, {
            "avatar": "d157fc1b7a2453c30c967712b3507a23jpeg",
            "food_ratings": [{
                "food_id": 200017169348,
                "rate_name": "西瓜汁-",
                "rating": 5,
                "rating_text": "西瓜汁- 西瓜汁- 好喝好喝 夏天必点",
                "sku_id": 200000410820517946,
                "sku_id_str": "200000410820517946"
            }, {
                "food_id": 200017169348,
                "rate_name": "西瓜汁-",
                "rating": 5,
                "rating_text": "西瓜汁- 西瓜汁- 好喝好喝 夏天必点",
                "sku_id": 200000410820517946,
                "sku_id_str": "200000410820517946"
            }],
            "highlights_v2": {
                "西瓜汁-": 200000410820517946
            },
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200017169348],
                "food_names": ["西瓜汁-"],
                "image_hash": "3e6dcbee39c0bebf2a551241bba7b2c0jpeg"
            }],
            "rated_at": "2019-09-23",
            "rating": 5,
            "rating_text": "西瓜汁- 西瓜汁- 好喝好喝 夏天必点",
            "img": "/static/images/user/3.png",
            "img1": "/static/images/userfoos/2.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-23 14:54:15"
            },
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "f**********r"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 1532984913,
                "rate_name": "牛奶烧仙草-",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000340972611642,
                "sku_id_str": "200000340972611642"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532984913],
                "food_names": ["牛奶烧仙草-"],
                "image_hash": "d7c60438177783e7abac3fd6ff9069dbjpeg"
            }, {
                "food_ids": [1532984913],
                "food_names": ["牛奶烧仙草-"],
                "image_hash": "ecef0ca8d0913773329ee4565ecb605ejpeg"
            }],
            "rated_at": "2019-09-21",
            "rating": 5,
            "rating_text": "关注公众号:饿小包，可每天领取饿了么5-15元无门榄红包劵",
            "img": "/static/images/user/1.png",
            "img1": "/static/images/userfoos/3.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-21 22:02:33"
            },
            "tags": [""],
            "time_spent_desc": "30分钟送达",
            "username": "2*********1"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200017220278,
                "rate_name": "蜜桃乌龙-",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000410868702266,
                "sku_id_str": "200000410868702266"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200017220278],
                "food_names": ["蜜桃乌龙-"],
                "image_hash": "74d15a7be54f6f23fd406fedac5c67f7jpeg"
            }],
            "rated_at": "2019-09-20",
            "rating": 5,
            "rating_text": "",
            "img": "/static/images/user/5.png",
            "img1": "/static/images/userfoos/3.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-20 21:54:25"
            },
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "b*********e"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 1532978107,
                "rate_name": "冰激凌红茶",
                "rating": 5,
                "rating_text": "很好喝的冰激凌红茶 ",
                "sku_id": 200000340977551418,
                "sku_id_str": "200000340977551418"
            }],
            "highlights_v2": {
                "冰激凌红茶": 200000340977551418
            },
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532978107],
                "food_names": ["冰激凌红茶"],
                "image_hash": "2ee5c2349bb476151c191aaed7d79c9ajpeg"
            }],
            "rated_at": "2019-09-19",
            "rating": 5,
            "rating_text": "很好喝的冰激凌红茶 ",
            "img": "/static/images/user/1.png",
            "img1": "/static/images/userfoos/4.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-19 21:54:42"
            },
            "tags": [""],
            "time_spent_desc": "30分钟送达",
            "username": "匿名用户"
        }, {
            "avatar": "ca1ddc8aa8dcf721154989cdacd957a4jpeg",
            "food_ratings": [{
                "food_id": 1532984902,
                "rate_name": "冰淇凌四季春-",
                "rating": 5,
                "rating_text": "珍珠 冰淇凌四季春- 真的好好喝！！",
                "sku_id": 200000340972601402,
                "sku_id_str": "200000340972601402"
            }, {
                "food_id": 1485965278,
                "rate_name": "珍珠",
                "rating": 5,
                "rating_text": "珍珠 冰淇凌四季春- 真的好好喝！！",
                "sku_id": 200000292828469306,
                "sku_id_str": "200000292828469306"
            }],
            "highlights_v2": {
                "冰淇凌四季春-": 200000340972601402,
                "珍珠": 200000292828469306
            },
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532984902, 1485965278],
                "food_names": ["冰淇凌四季春-", "珍珠"],
                "image_hash": "55728f325bd0226cf5a24dda811f50fcjpeg"
            }],
            "rated_at": "2019-09-19",
            "rating": 5,
            "rating_text": "珍珠 冰淇凌四季春- 真的好好喝！！",
            "img": "/static/images/user/4.png",
            "img1": "/static/images/userfoos/6.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-19 14:55:07"
            },
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "賢*****怪"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 1532984903,
                "rate_name": "冰激凌红茶-",
                "rating": 4,
                "rating_text": "很快冰激凌红茶- 好好好",
                "sku_id": 200000340977546298,
                "sku_id_str": "200000340977546298"
            }],
            "highlights_v2": {
                "冰激凌红茶-": 200000340977546298
            },
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1532984903],
                "food_names": ["冰激凌红茶-"],
                "image_hash": "9b889bfde66b838388fdec0e7b339597jpeg"
            }],
            "rated_at": "2019-09-19",
            "rating": 5,
            "rating_text": "很快冰激凌红茶- 好好好",
            "img": "/static/images/user/3.png",
            "img1": "/static/images/userfoos/2.jpg",
            "reply": {
                "content": "亲爱的顾客，感谢您选择文化街益禾堂，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝学习愉快哈！",
                "created_at": "2019-09-19 14:55:07"
            },
            "tags": [""],
            "time_spent_desc": "按时送达",
            "username": "卡******a"

        }]
    ,
    //0:正常返回值；非0都是算数据异常。例如1：类型错误，2：服务器延迟，3.....
    code: 0,
    //返回信息
    msg: "success"
});
/**
 * 商家评分接口
 */Mock.mock("/sellerRa", {
    data: {
        "comments": [{
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }, {
                "food_id": 200010039090,
                "rate_name": "凑满减用（无商品）",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000403531258600,
                "sku_id_str": "200000403531258600"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "13f45553cc8597738bd6cd9d36c245e5jpeg"
            }],
            "rated_at": "2019-11-24",
            "rating": 5,
            "rating_text": "还行的",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "匿名用户"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200066399924,
                "rate_name": "瓦香鸡米饭",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000461268660968,
                "sku_id_str": "200000461268660968"
            }, {
                "food_id": 1795733042,
                "rate_name": "点我99下赠送烤肠一根.少点不配送",
                "rating": 4,
                "rating_text": "",
                "sku_id": 100000125485850344,
                "sku_id_str": "100000125485850344"
            }, {
                "food_id": 200010039090,
                "rate_name": "凑满减用（无商品）",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000403531258600,
                "sku_id_str": "200000403531258600"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200066399924],
                "food_names": ["瓦香鸡米饭"],
                "image_hash": "88e325ebe997fa443242b5c60d11a66fjpeg"
            }],
            "rated_at": "2019-11-22",
            "rating": 5,
            "rating_text": "味道不错",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "匿名用户"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "c98f0b88bc5465127a10ee44787cec08jpeg"
            }, {
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "892f10063666b1afc2536a9ded73c266jpeg"
            }, {
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "6dc43a60b75f2242fd9d9fe64869e0e0jpeg"
            }],
            "rated_at": "2019-11-22",
            "rating": 5,
            "rating_text": "店家不错，菜特别好吃，搭配红包也便宜\r\n\r\n关注公众号：「外卖鸭」，每次点外卖前都可以领5~15元券，推荐去试试",
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "匿名用户"
        }, {
            "avatar": "6d0c335e5a202effa2d8fb7060c0b4d0jpeg",
            "food_ratings": [{
                "food_id": 200065842376,
                "rate_name": "瓦香土豆+米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000460684067560,
                "sku_id_str": "200000460684067560"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200065842376],
                "food_names": ["瓦香土豆+米饭"],
                "image_hash": "3ccfee7e5ca0215636eedc938262ccb1jpeg"
            }],
            "rated_at": "2019-11-22",
            "rating": 5,
            "rating_text": "土豆特别好吃！",
            "tags": [""],
            "time_spent_desc": "按时送达",
            "username": "一***器"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }, {
                "food_id": 200061428467,
                "rate_name": "烤肠",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000456173254376,
                "sku_id_str": "200000456173254376"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991, 200061428467],
                "food_names": ["瓦香鸡腿肉＋米饭", "烤肠"],
                "image_hash": "121e24f72e188ae8944b7fb2f411d558jpeg"
            }],
            "rated_at": "2019-11-18",
            "rating": 5,
            "rating_text": "好",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "2*********4"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }, {
                "food_id": 200010039090,
                "rate_name": "凑满减用（无商品）",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000403531258600,
                "sku_id_str": "200000403531258600"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "c3dafd1ffcec1a5b2a7463a0c9a5359ejpeg"
            }],
            "rated_at": "2019-11-18",
            "rating": 5,
            "rating_text": "好吃",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "5*********f"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "3b0f88d9ef5ccc714468144309015d92jpeg"
            }],
            "rated_at": "2019-11-17",
            "rating": 5,
            "rating_text": "很好吃",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "2*****."
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 5,
                "rating_text": "好吃哭了 瓦香鸡腿肉＋米饭 土豆特别多 肉还好香香的",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }],
            "highlights_v2": {
                "瓦香鸡腿肉＋米饭": 200000422471043816
            },
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "314f3febc879c92ba414718a9a60fd08jpeg"
            }],
            "rated_at": "2019-11-14",
            "rating": 5,
            "rating_text": "好吃哭了 瓦香鸡腿肉＋米饭 土豆特别多 肉还好香香的",
            "tags": [""],
            "time_spent_desc": "按时送达",
            "username": "t*********1"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200066399924,
                "rate_name": "瓦香鸡米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000461268660968,
                "sku_id_str": "200000461268660968"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200066399924],
                "food_names": ["瓦香鸡米饭"],
                "image_hash": "25357595ca81c3ee6b3441f454cb9a8cjpeg"
            }],
            "rated_at": "2019-11-14",
            "rating": 4,
            "rating_text": "菜品味道很好，量也很足，就是饭不好吃，太硬了",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "3*********a"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200066399924,
                "rate_name": "瓦香鸡米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000461268660968,
                "sku_id_str": "200000461268660968"
            }, {
                "food_id": 200028319468,
                "rate_name": "凑满减随机软饮",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422247673576,
                "sku_id_str": "200000422247673576"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200066399924],
                "food_names": ["瓦香鸡米饭"],
                "image_hash": "ea892a995d60c905c8618cd76cbb1535jpeg"
            }],
            "rated_at": "2019-11-11",
            "rating": 4,
            "rating_text": "好吃，点了好几次了，就是今天中午忘记给我饮料了",
            "reply": {
                "content": "下次联系商家，电话，短信，饿了么留言都可以，指定让你满意",
                "created_at": "2019-11-14 23:39:24"
            },
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "不***啦"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "7bd3108c3ad327d914a9128f9e1395fbjpeg"
            }],
            "rated_at": "2019-11-10",
            "rating": 5,
            "rating_text": "东西挺好的，就是只有一根筷子哈哈哈哈哈？",
            "reply": {
                "content": "这种事情真不好意思，下次联系商家，让骑手给你送过去",
                "created_at": "2019-11-14 23:41:11"
            },
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "a*********0"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200066399924,
                "rate_name": "瓦香鸡米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000461268660968,
                "sku_id_str": "200000461268660968"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200066399924],
                "food_names": ["瓦香鸡米饭"],
                "image_hash": "1d64ff09a949868f324e559d2f3ff8afjpeg"
            }, {
                "food_ids": [200066399924],
                "food_names": ["瓦香鸡米饭"],
                "image_hash": "c178476ae0255725dcbbf74e287856acjpeg"
            }, {
                "food_ids": [200066399924],
                "food_names": ["瓦香鸡米饭"],
                "image_hash": "328310ff6dbe6e13910226b4b00e3d23jpeg"
            }],
            "rated_at": "2019-11-09",
            "rating": 5,
            "rating_text": "店家不错，菜特别好吃，搭配红包也便宜\r\r关注公众号：「外卖小熊」，每次点外卖前都可以领5~15元券，推荐去试试",
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "匿名用户"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200066399924,
                "rate_name": "瓦香鸡米饭",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000461268660968,
                "sku_id_str": "200000461268660968"
            }, {
                "food_id": 200010039090,
                "rate_name": "凑满减用（无商品）",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000403531258600,
                "sku_id_str": "200000403531258600"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": true,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200066399924],
                "food_names": ["瓦香鸡米饭"],
                "image_hash": "ab77ee301c2ba93a7d4a7a2152dd8e95jpeg"
            }],
            "rated_at": "2019-11-07",
            "rating": 5,
            "rating_text": "店家人很好也很好吃  东西多",
            "reply": {
                "content": "爱你，爱你，爱你呦~",
                "created_at": "2019-11-14 23:43:40"
            },
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "3*******9"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "b81e1c972fb32330017816d150477411jpeg"
            }],
            "rated_at": "2019-11-06",
            "rating": 5,
            "rating_text": "吃的还行，就是配送偶尔会出现素质极差态度极差骑手！点单的注意不要被骑手影响心情了！吃饭没心情还吃什么，我们作为消费者，只需要尊重尽职尽责的骑手！对自己工作的性质都不知道的骑手不需要忍着！商家也要注意不要让骑手影响店内生意！专送比某些平台好多了！",
            "reply": {
                "content": "实在不好意思给你添麻烦了，送餐是整体外包给团队的，不好意思。团队不止送我自己家，所以餐很多很多一起送，时间可能紧一些都是不送上楼的，专送配送费高昂目前没办法实现，不过我会尽量去沟通减少此类事情发生",
                "created_at": "2019-11-14 23:05:17"
            },
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "9*********2"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }, {
                "food_id": 200010039090,
                "rate_name": "凑满减用（无商品）",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000403531258600,
                "sku_id_str": "200000403531258600"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "42e19ea9ebb9f8ef0aa243b1e34171fcjpeg"
            }],
            "rated_at": "2019-11-04",
            "rating": 5,
            "rating_text": "老板真的贼好  被人偷了又补发一份给我 良心 饭也特别好吃",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "b*********4"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200066399924,
                "rate_name": "瓦香鸡米饭",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000461268660968,
                "sku_id_str": "200000461268660968"
            }, {
                "food_id": 200010039090,
                "rate_name": "凑满减用（无商品）",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000403531258600,
                "sku_id_str": "200000403531258600"
            }, {
                "food_id": 1795733042,
                "rate_name": "点我99下赠送烤肠一根.少点不配送",
                "rating": 5,
                "rating_text": "",
                "sku_id": 100000125485850344,
                "sku_id_str": "100000125485850344"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200066399924, 200010039090, 1795733042],
                "food_names": ["瓦香鸡米饭", "凑满减用（无商品）", "点我99下赠送烤肠一根.少点不配送"],
                "image_hash": "ce8a2714738636315e91e2bafd82fb98jpeg"
            }],
            "rated_at": "2019-10-30",
            "rating": 5,
            "rating_text": "好吃，料足，本来懒得评论，看到评价有个脑瘫给👴🏻整笑了，这都能差评你马怎么不死呢",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "f*********c"
        }, {
            "avatar": "84f082f9394dab9ae95c14ddee6932fdjpeg",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "c06e219dc33ab990b61b52a7ec35076ajpeg"
            }, {
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "363e4ab427d5ee3b4dffa0b820fbdaf9jpeg"
            }, {
                "food_ids": [200028527991],
                "food_names": ["瓦香鸡腿肉＋米饭"],
                "image_hash": "a1c0263be4a04ab46116ecd5f721797bjpeg"
            }],
            "rated_at": "2019-10-19",
            "rating": 5,
            "rating_text": "店家不错，搭配红包使用更便宜！\n搜索微信公众号【外卖最大社】，每次点外卖前都可直接领5-15元红包，又省钱又方便，推荐去免费试试",
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "奥***a"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200010039090,
                "rate_name": "凑满减用（无商品）",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000403531258600,
                "sku_id_str": "200000403531258600"
            }, {
                "food_id": 200028323083,
                "rate_name": "瓦香鱼豆腐+米饭",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000422247041768,
                "sku_id_str": "200000422247041768"
            }, {
                "food_id": 1795733042,
                "rate_name": "点我99下赠送烤肠一根.少点配送",
                "rating": 2,
                "rating_text": "",
                "sku_id": 100000125485850344,
                "sku_id_str": "100000125485850344"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [1795733042],
                "food_names": ["点我99下赠送烤肠一根.少点配送"],
                "image_hash": "c3c8ebb77ce3e306cba79fd6076ef1a8jpeg"
            }],
            "rated_at": "2019-10-17",
            "rating": 5,
            "rating_text": "老板，我想问问这一分钱赠送肠没给我是什么原因？",
            "reply": {
                "content": "那个得点击99下才能赠送，画圈就是重点部分，写字很麻烦的呀我都换成彩笔了就怕看不见",
                "created_at": "2019-10-18 02:30:29"
            },
            "tags": [""],
            "time_spent_desc": "按时送达",
            "username": "匿名用户"
        }, {
            "avatar": "80985992ee53f49d58aed232f7172b31jpeg",
            "food_ratings": [{
                "food_id": 200066399924,
                "rate_name": "瓦香鸡米饭",
                "rating": 5,
                "rating_text": "",
                "sku_id": 200000461268660968,
                "sku_id_str": "200000461268660968"
            }, {
                "food_id": 1795733042,
                "rate_name": "点我99下赠送烤肠一根.少点配送",
                "rating": 5,
                "rating_text": "",
                "sku_id": 100000125485850344,
                "sku_id_str": "100000125485850344"
            }, {
                "food_id": 200028319468,
                "rate_name": "凑满减随机软饮",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422247673576,
                "sku_id_str": "200000422247673576"
            }],
            "highlights_v2": {},
            "is_super_vip": true,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200066399924, 1795733042, 200066399924, 1795733042],
                "food_names": ["瓦香鸡米饭", "点我99下赠送烤肠一根.少点配送", "瓦香鸡米饭", "点我99下赠送烤肠一根.少点配送"],
                "image_hash": "b544ab587171a4843829b01e3d832561jpeg"
            }],
            "rated_at": "2019-10-15",
            "rating": 5,
            "rating_text": "好吃",
            "tags": [""],
            "time_spent_desc": "50分钟送达",
            "username": "C*****W"
        }, {
            "avatar": "",
            "food_ratings": [{
                "food_id": 200028527991,
                "rate_name": "瓦香鸡腿肉＋米饭",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000422471043816,
                "sku_id_str": "200000422471043816"
            }, {
                "food_id": 200010039090,
                "rate_name": "凑满减用（无商品）",
                "rating": 4,
                "rating_text": "",
                "sku_id": 200000403531258600,
                "sku_id_str": "200000403531258600"
            }, {
                "food_id": 1795733042,
                "rate_name": "点我99下赠送烤肠一根.少点配送",
                "rating": 4,
                "rating_text": "",
                "sku_id": 100000125485850344,
                "sku_id_str": "100000125485850344"
            }],
            "highlights_v2": {},
            "is_super_vip": false,
            "is_taobao_vip": false,
            "order_id": 0,
            "order_images": [{
                "food_ids": [200028527991, 200010039090, 1795733042],
                "food_names": ["瓦香鸡腿肉＋米饭", "凑满减用（无商品）", "点我99下赠送烤肠一根.少点配送"],
                "image_hash": "81443c704c5b322be1ea6f0b8cb47691jpeg"
            }],
            "rated_at": "2019-10-15",
            "rating": 5,
            "rating_text": "好吃",
            "tags": [""],
            "time_spent_desc": "40分钟送达",
            "username": "1*********0"
        }],
        "rating": {
            "compare_rating": 0.3947457056247895,
            "deliver_time": 47,
            "food_score": 4.8,
            "item_good_score": 0.968641,
            "order_rating_amount": 719,
            "overall_score": 4.8,
            "package_score": 4.7,
            "rider_score": 4.5,
            "service_score": 4.5,
            "shop_score": 4.5,
            "taste_score": 4.5
        },
        "tags": [{
            "count": 719,
            "name": "全部",
            "unsatisfied": false
        }, {
            "count": -1,
            "name": "最新",
            "unsatisfied": false
        }, {
            "count": 637,
            "name": "好评",
            "unsatisfied": false
        }, {
            "count": 33,
            "name": "差评",
            "unsatisfied": true
        }, {
            "count": 128,
            "name": "有图",
            "unsatisfied": false
        }, {
            "count": 55,
            "name": "味道好",
            "unsatisfied": false
        }, {
            "count": 12,
            "name": "不好吃",
            "unsatisfied": true
        }]
    }
    ,
    code: 0
    , msg: "success"
})