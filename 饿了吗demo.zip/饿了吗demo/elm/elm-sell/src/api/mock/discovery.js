/**
 * 首页数据接口：
 * 定位接口数据；
 * banner广告数据；
 * 商家列表接口数据；
 */

var Mock = require("mockjs");



Mock.mock("/getDiscoveryInfoById", {
  data: [{
    "id":1,
    "corner_marker": "限时优惠",
    "image_hash": "static/images/纸巾.jpg",
    "original_price": 3,
    "points_required": 90,
    "title": "温莎手口湿巾10包",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1900411%26dbnewopen"
  },
  {
    "id":2,
    "corner_marker": "特价换购",
    "image_hash": "static/images/小猪.jpg",
    "original_price": 239,
    "points_required": 9,
    "title": "可爱小猪美妆镜",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D2087844%26dbnewopen"
  },
  {
    "id":3,
    "corner_marker": "特价换购",
    "image_hash": "static/images/袜子.jpg",
    "original_price": 130,
    "points_required": 9,
    "title": "春夏5双船袜礼盒",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1954182%26dbnewopen"
  },
  {
    "id":4,
    "corner_marker": "特价换购",
    "image_hash": "static/images/充电宝.jpg",
    "original_price": 128,
    "points_required": 9,
    "title": "卡通趴趴熊充电宝",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D2157305%26dbnewopen"
  },
  {
    "id":5,
    "corner_marker": "特价换购",
    "image_hash": "static/images/抱枕.jpg",
    "original_price": 249,
    "points_required": 9,
    "title": "四季多功能抱枕被",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1990037%26dbnewopen"
  },
  {
    "id":6,
    "corner_marker": "特价换购",
    "image_hash": "static/images/毛巾.jpg",
    "original_price": 139,
    "points_required": 9,
    "title": "超强吸水浴巾",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1894301%26dbnewopen"
  },
  {
    "id":7,
    "corner_marker": "特价换购",
    "image_hash": "static/images/毛巾.jpg",
    "original_price": 139,
    "points_required": 9,
    "title": "超强吸水浴巾",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1894301%26dbnewopen"
  },
  {
    "id":8,
    "corner_marker": "特价换购",
    "image_hash": "static/images/毛巾.jpg",
    "original_price": 139,
    "points_required": 9,
    "title": "超强吸水浴巾",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1894301%26dbnewopen"
  },
  {
    "id":9,
    "corner_marker": "特价换购",
    "image_hash": "static/images/萌宠智能充电宝.jpg",
    "original_price": 139,
    "points_required": 9,
    "title": "萌宠智能充电宝",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1894301%26dbnewopen"
  },
  {
    "id":10,
    "corner_marker": "特价换购",
    "image_hash": "static/images/离子恒温吹风机.jpg",
    "original_price": 139,
    "points_required": 9,
    "title": "离子恒温吹风机",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1894301%26dbnewopen"
  },
  {
    "id":11,
    "corner_marker": "特价换购",
    "image_hash": "static/images/S925银项链.jpg",
    "original_price": 139,
    "points_required": 9,
    "title": "S925银项链",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1894301%26dbnewopen"
  }
  ,{
    "id":12,
    "corner_marker": "特价换购",
    "image_hash": "static/images/小恶魔雨伞.jpg",
    "original_price": 139,
    "points_required": 9,
    "title": "小恶魔雨伞",
    "url": "https://h5.ele.me/exchange/?dbredirect=https%3A%2F%2Factivity.m.duiba.com.cn%2Fmobile%2FappItemDetail%3FappItemId%3D1894301%26dbnewopen"
  },


  ],
  code: 0,
  msg: "success"
})
