/**
 * 历史搜索数据
 */

var Mock = require("mockjs");


/**
 * 获取4张广告banner图片地址
 *
 */
Mock.mock("/searchLs", {
  data: {
    searchLs: [{
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "张亮麻辣烫"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "三米粥铺"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "佳香桂林米粉"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "天九王炝肉"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "凉皮"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "紫菜包饭"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "奶茶"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "汉堡王"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "酸辣粉"
    }, {
      "isHighlight": 0,
      "link": null,
      "searchWord": null,
      "source": null,
      "type": null,
      "url": null,
      "word": "一点点"
    }]
  },
  code: 0,
  msg: "success"
});
