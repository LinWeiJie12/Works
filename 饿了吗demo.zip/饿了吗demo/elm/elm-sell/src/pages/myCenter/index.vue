<style scoped lang="less" src="./vs.less"></style>
<template> 
<scrollY ref="scrollY">
  <div class="userCenter" id="userCenter">
   
      <!-- 头部 -->
      <div class="header" >
        <div class="headimg">
          <img src="./img/头像.jpg" alt />
        </div>
        <div class="headermsg">
          <p>喵喵喵喵</p>
          <img class="img" src="./img/手机.jpg" alt />
          <i>186*****620</i>
        </div>

        <router-link to="/myContent" replace class="address-link">
          <div class="jt">
            <img src="./img/下箭头.png" alt />
          </div>
        </router-link>
      </div>
      <!-- 头部 -->

      <!-- 红包 -->
      <div class="msg">
        <div class="msgleft">
          <p>5</p>
          <span>个</span>
          <i>红包</i>
        </div>
        <div class="msgright">
          <p>10</p>
          <span>个</span>
          <i>金币</i>
        </div>
      </div>
      <!-- 红包 -->

      <!-- 我的地址 -->
      <div class="myaddress">
        <img src="./img/定位.png" alt />
        <span>我的地址</span>
        <div class="addressimg"
        @click="myInfomation()">
          <img src="./img/左箭头.png" alt />
        </div>
      </div>

      <div class="myaddress">
        <img src="./img/金币商城.png" alt />
        <span>金币商城</span>
        <div class="addressimg">
          <img src="./img/左箭头.png" alt />
        </div>
      </div>

      <div class="myaddress1">
        <img src="./img/分享现金.png" alt />
        <span>分享拿20元现金</span>
        <div class="addressimg">
          <img src="./img/左箭头.png" alt />
        </div>
      </div>

      <div class="myaddress">
        <img src="./img/我的客服.png" alt />
        <span>我的客服</span>
        <div class="addressimg">
          <img src="./img/左箭头.png" alt />
        </div>
      </div>
      <div class="myaddress1">
        <img src="./img/下载饿了么.png" alt />
        <span>下载饿了么</span>
        <div class="addressimg">
          <img src="./img/左箭头.png" alt />
        </div>
      </div>
      <div class="myaddress1">
        <img src="./img/规则中心.png" alt />
        <span>规则中心</span>
        <div class="addressimg">
          <img src="./img/左箭头.png" alt />
        </div>
      </div>
      <!-- 我的地址 -->

      <div class="yinsi">隐私政策</div>
    
  </div>
 </scrollY>
</template>
<script src = "./vm.js"></script>