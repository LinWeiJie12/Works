//上拉加载更多组件
import scrollY from "components/scrollY";
export default {
    name: '',
    props: {},
    data() {
        return {

        };
    },
    components: {
        scrollY
    },
    created() { },
    //监听器
    watch: {

    },
    //计算属性
    computed: {

    },
    mounted() {
        setTimeout(() => {
            this.$nextTick(() => {
              //调用组件中公开的方法
              this.$refs.scrollY.fire();
            });
    
    
          }, 500);

    },
    methods: {
        //点击商品名称跳转到商品页面
        myInfomation() {
          this.$router.push({
              name: `myInfomation`,
          });
      },
    }
};