import axios from "axios";

//导入模拟数据
require("mock/discovery.js")
//上拉加载更多
import scrollY from "components/scrollY";

export default {
  name: '',
  props: {},
  data() {
    return {
      list: [],
      pullDown: false
    }
  },
  components: {
    scrollY
  },
  watch: {
    list() {
      // console.log(this.list);

    }
  },
  computed: {},
  async mounted() {
    await this.discoveryList();
    //调用组件中公开的方法
    this.$refs.scrollY.fire();
  },
  methods: {
    fchange(value) {
      if (this.isLoading) {
        return;
      }

      if (value > 50) {
        this.pullDown = true;
        setTimeout(() => {
          this.pullDown = false;
          this.$router.go(0);
        }, 1000);
      }







    },
    /**
     * 获取限时好礼列表数据is
     */
    async discoveryList() {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          //请求验证码接口
          axios.post('/getDiscoveryInfoById', {}).then(res => {

            this.list = res.data.data;
            resolve();
          }).catch(error => {
            console.log(error);
            reject();
          });
        }, 1000);
      });

    }
  }
}
