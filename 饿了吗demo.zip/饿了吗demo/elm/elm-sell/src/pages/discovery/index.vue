<style scoped lang="less" src="./vs.less"></style>
<template>
  <div class="discovery" id="discovery">
    <scrollY ref="scrollY" @change="fchange">
      <div class="lmc-loading-tip" v-show="pullDown">
        <van-loading type="spinner" color="#1989fa" />
      </div>
      <!-- 顶部推荐商城模块 -->
      <section class="parts">
        <div class="entry clear">
          <a href="#" class="left topentry" style="border-right: 1px solid #ededed;">
            <div class="content-wrapper">
              <p class="title">金币商城</p>
              <p class="tips">0元好物在这里</p>
            </div>
            <img src="/static/images/userfoos/金币商城.jpg" alt />
          </a>
          <div class="nextentry right">
            <a href="#" class="nextentryOne">
              <div class="left one">
                <p class="title">推荐有礼</p>
                <p class="tips">20元现金拿不停</p>
              </div>
              <img src="/static/images/userfoos/推荐有奖.jpg" alt />
            </a>
            <a href="#" class="nextentryTwo">
              <div class="left two">
                <p class="title">周边优惠</p>
                <p class="tips">领取口碑好券</p>
              </div>
              <img src="/static/images/userfoos/周边优惠.jpg" alt />
            </a>
          </div>
        </div>
      </section>
      <!-- 顶部推荐商城模块---end -->
      <section class="goodPresent">
        <div class="activity-header clear">
          <span class="line one">
            <span class="iconfont" style="color: rgb(207, 26, 26);">&#58921;</span>
            <i>限时好礼</i>
          </span>
        </div>
        <p class="haoli">金币换豪礼</p>
        <van-row>
          <van-col span="8" class="activity-body" v-for="item in list" :key="item.id">
            <a href="#" class="activityA">
              <img :src="item.image_hash" alt />
              <div>
                <p>{{item.title}}</p>
                <div class="activityB">
                  <span>{{item.points_required}}金币</span>
                  <del>￥{{item.original_price}}</del>
                </div>
              </div>
              <span class="discount">{{item.corner_marker}}</span>
            </a>
          </van-col>
        </van-row>
        <a href="#">
          <p class="activity-more">
            查看更多
            <span class="iconfont">&#58895;</span>
          </p>
        </a>
      </section>
    </scrollY>
  </div>
</template>
<script src = "./vm.js"></script>