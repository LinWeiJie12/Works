import { mapGetters, mapState, mapMutations, mapActions } from "vuex";
import * as types from 'vuexStore/mutation-types.js'
import axios from "axios";
import { tool } from "commonJs/tool.js";
//上拉加载更多组件
import scrollY from "components/scrollY";
// 购物车小球特效
import shopbar from "assetsPlugin/shopbar/shopbar.js";
import "assetsPlugin/shopbar/shopbar.less";
// 购物车小球特效

//导入模拟数据
require("mock/sellersDetails.js");
import { Toast } from 'vant';

export default {
    name: '',
    props: {},
    data() {
        return {
            //商品类别数组
            mentList: [],
             //商品类别ID
             typeId: "",
             goodslistTitle: "",
            goodsTypeCssList:[
            "decrease",
            "special",
            "discount",
            "guarantee",
            "invoice"
          ],
          //商品列表
          goodsList: [],
        };
    },
    components: {
        scrollY
    },
    created() { },
    //监听器
    watch: {
     
    },
    //计算属性
    computed: {
        ...mapState(['seller'])
    },
    
     async  mounted() {
        // if (this.seller.id == "") {
        //     return;
        // }
      await  this.getGoodsCategory();
       await this.getGoodsListByCid();
    },
    methods: {
      ...mapActions(['addGoodsToShopCat']),
        //获取商品类别
      async  getGoodsCategory(){
          return new Promise ((resolve,reject)=>{
           setTimeout(()=>{
            //请求验证码接口
            axios.post('/gettGoodsTypeById', {
                id: this.seller.id
            }).then(res => {
               
              this.mentList=res.data.list;
            //商品类别ID
            this.typeId = this.mentList[0].id;
            this.goodslistTitle=this.mentList[0].name;

              this.$nextTick(() => {
                //调用组件中公开的方法
                this.$refs.scrollY1.fire();
            });

                resolve();
            }).catch(error => {
                console.log(error);
                reject();
            });


           },1000);

          });

        },
// -------------------------------------------------------------------
        //根据类别id，获取商品列表数据
        getGoodsListByCid(){
          return new Promise((resolve,reject)=>{
        // //请求验证码接口
        axios.post('/getGoodsListByTypeId', {
          typeId:this.typeId
        }).then(res => {
            
           this.goodsList = res.data.foods;
           this.$nextTick(() => {
            //调用组件中公开的方法
            this.$refs.scrollY2.fire();
        });

            resolve();
        }).catch(error => {
            console.log(error);
            reject();
        });
          });
        },
         
// -------------------------------------------------------------------

         /**
         * 选着类型，重新加载其他goods的数据
         */
        selectMenu(item) {
          console.log(item);
          //活动元素的类选择器为：current
          //删除掉current样式
          tool.removeAllClass(
            document.getElementsByClassName("menu-item"),
            "current"
        );
            //添加样式
            tool.addClass(event.currentTarget, "current");

          Toast.loading({
            duration: 0, // 持续展示 toast
            forbidClick: true,
            message: '数据加载中....'
          });

         setTimeout(()=>{
          return new Promise((resolve,reject)=>{ 
              //请求码接口
          axios.post('/getGoodsListByTypeId', {
            typeId:item.id
          }).then(res => {
               //手动清除 Toast
               Toast.clear();
             res.data.foods.splice(0,4);
            this.goodsList = res.data.foods;
             //手动清除 Toast
              Toast.clear();
             this.$nextTick(() => {
              //重置滚动容器的高度
              this.$refs.scrollY2.fire();
          });
              resolve();
          }).catch(error => {
              console.log(error);
              reject();
          });
           });
         },1000);
        },
// -------------------------------------------------------------------
         /**
         * 添加购物车
         */
        addShopCart(item) {

          //购物车小球飞入效果
          shopbar.go({
              pageX: event.pageX - 10,
              pageY: event.pageY - 10,
              endX: -(event.pageX - 20),
              endY: (window.screen.height - event.pageY - 30)
          });

          this.addGoodsToShopCat(item);
  



      }
    }

       
};