<style scoped lang="less" src="./vs.less"></style>

<template>

  <!-- 商家商品列表页面 -->
  <div class="goods-ctn">

    <!-- <div class="mask-ctn"></div> -->

    <div class="goods">
      <!-- 商品类型列表 -->
      <div class="menu-wrapper">
    <scrollY ref="scrollY1">
          <ul>
            <li
              class="menu-item "
              :class="{current:item.name==mentList[0].name}"
              v-for="item in mentList"
              @click="selectMenu(item)"
            >
              <span class="text border-1px">
                <span
                  v-if="item.type>-1"
                  class="icon"
                  :class="goodsTypeCssList[item.type]"
                ></span>
                {{item.name}}
              </span>
            </li>
          </ul>
       
       </scrollY>
      </div>
      <!-- 商品类型列表__end -->

      <!-- 商品列表 -->
      <div class="foods-wrapper">
        <scrollY ref="scrollY2">
         <ul>
            <li class="food-list">
              <h1 class="title">{{goodslistTitle}}</h1>
              <ul>
                <li
                  class="food-item border-1px"
                  v-for="item in goodsList"
                >
                  <div class="icon">
                    <img
                      width="57"
                      height="57"
                      :src="item.image"
                    />
                  </div>
                  <div class="content">
                    <h2 class="name">{{item.name}}</h2>
                    <p class="desc">{{item.description}}</p>
                    <div class="extra">
                      <span class="count">月售{{item.sellCount}}份</span><span>好评率{{item.rating}}%</span>
                    </div>
                    <div class="price">
                      <span class="now">￥{{item.price}}</span>
                      <!-- 旧价格 -->
                      <span
                        class="old"
                        v-if="parseInt(item.oldPrice)>0"
                      >￥{{item.oldPrice}}</span>
                      <!-- 旧价格__end -->
                    </div>

                  </div>
                  <!-- 购物车按钮 -->
                  <div
                    class="shop-btn-dv"
                    @click="addShopCart(item)"
                  >
                    <i class="iconfont icon-Shoppingcart"></i>
                  </div>
                  <!-- 购物车按钮__end -->
                </li>
              </ul>
            </li>
          </ul>
        </scrollY>

      </div>
      <!-- 商品列表__end -->
    </div>
  </div>

</template>

<script src = "./vm.js"></script>
