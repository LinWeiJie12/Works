import {
  Toast
} from 'vant';
import axios from "axios";
//导入模拟数据
require("mock/searchLs.js");


export default {
  name: '',
  props: {},
  data() {
    return {
      value: '输入商家，商品名称',
      searchLs: []

    };
  },
  components: {},
  created() {},
  //监听器
  watch: {

  },
  //计算属性
  computed: {

  },
  async mounted() {
    await this.yuuyu();

  },
  methods: {
    onSearch() {
      Toast('搜索中..');
    },
    onclick() {
      this.$router.push({
        name: `homeindex`
      })
    },

    async yuuyu() {

      return new Promise((resolve, reject) => {
        //请求验证码接口
        setTimeout(() => {
          axios.post('/searchLs', {}).then(res => {
              console.log(res);
              this.searchLs = res.data.data.searchLs
              resolve();
            })
            .catch(error => {
              console.log(error);
              reject(error);
            });
        }, 1000);

      });

    },

  }
};
