<style scoped lang="less" src="./vs.less"></style>
<template>
  <div class="search" id="search">
    <div class="end" @click="onclick">
      <img src="./img/返回.png" alt />
    </div>

    <!-- 搜索模块 -->
    <van-search v-model="value" placeholder="请输入搜索关键词" show-action shape="round" @search="onSearch">
      <div slot="action" @click="onSearch">搜索</div>
    </van-search>
    <!-- 搜索模块 -->

    <div class="searchmenu">热门搜索</div>
    <div v-for="item in searchLs">
      <div class="searchmenu1">
        <p>{{item.word}}</p>
      </div>
      <!-- <div class="searchmenu2">
        <p>益禾堂</p>
      </div>
      <div class="searchmenu3">
        <p>手抓饼布袋馍炸串</p>
      </div>
      <div class="searchmenu4">
        <p>烧烤</p>
      </div>
      <div class="searchmenu5">
        <p>奶茶</p>
      </div>
      <div class="searchmenu6">
        <p>章鱼小丸子</p>
      </div>
      <div class="searchmenu7">
        <p>若可</p>
      </div>
      <div class="searchmenu8">
        <p>一点点</p>
      </div>
      <div class="searchmenu9">
        <p>鸡蛋灌饼</p>
      </div>
      <div class="searchmenu10">
        <p>紫菜包饭</p>
      </div>-->
    </div>
    <div></div>
  </div>
</template>
<script src = "./vm.js"></script>