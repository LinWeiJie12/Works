import { mapActions } from "vuex";
import { tool } from "commonJs/tool";
import { Toast } from "vant";
import axios from "axios";
//导入模拟数据
require("mock/login.js");

export default {
    name: '',
    props: {},
    data() {
        return {
            //验证码是否发送的标识符
        isYzmSend:false,
        ysmTips:"获得验证码",
         form:{
             phone:"18650743620",
             yzm:""
         }
        };
    },
    components: {},
    created() { },
    //监听器
    watch:{

    },
    //计算属性
    computed: {


    // 翻转字符串
    reserveMsg(){
    
    }


    },
    mounted() {
       
    },
    methods: {
     ...mapActions(['loginAction']),

        //获取验证码
        getYzm(){
            //验证码如果发送了，就不能继续点击了，只能在30秒之后
            if(this.isYzmSend){
                return;
            }
            let limitTime=30;//限定时间30miao
            this.ysmTips=`已发送(${limitTime})s`;
            let timer=setInterval(() => {
            if(limitTime == 0 ){
             this.ysmTips=`获得验证码`;
              this.isYzmSend=false;
              clearInterval(timer);
              return;
          }
           console.log('时间'+limitTime);
           limitTime--;
            this.ysmTips=`已发送(${limitTime})s`;
            }, 1000);
           
           
            this.isYzmSend=true;
           //验证手机号码输入是否正确！
           let rules = [];

           rules.push({
               name: "手机号码",
               value: this.form.phone,
               phone: true
           });
           let result = tool.checkForm({
            rules: rules
        });
           if(!result){
               return;
           }
        
           Toast({
             type:"success",
             message:"发送成功",
           })
          
          //请求验证码接口
          setTimeout(() => {
          axios.post('/sendVerificationCode',{
            code:this.form.yzm    
          }).then(res => {
         
          
            console.log(res);
            console.log(`服务返回的数据:${res.data.msg}`);
          })
          .catch(error => {
              console.log(error);
              console.log("服务异常，请联系管理员!");
              reject(error);
          });
         },3000);


        },
     loginfn(){
         console.log("执行表单验证");

          //验证手机号码输入是否正确！
          let rules = [];

          rules.push({
              name: "手机号码",
              value: this.form.phone,
              phone: true
              
          });

          rules.push({
            name: "验证码",
            value: this.form.yzm,
            required:true
        });

          let result = tool.checkForm({
              rules: rules
          });
          
          //如果都验证成功则调用登入接口
          if(!result){
           return;
          }
          
          this.loginAction({
            phone:this.form.phone,
            yzm: this.form.yzm
          }).then((res)=>{

       console.log("跳转到首页")
             this.$router.push({name:`homeindex`})
          })

       

         
        
     }
    }
}; 