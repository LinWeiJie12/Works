<style scoped lang="less" src="./vs.less"></style>
<template>
  <div
    class="login-ctn"
    id="login-container"
  >
    <div class="logo"></div>
    <div class="tabc-container">
      <div class="ui-row tabc-title">
        <div class="ui-col ui-col-100">
         
        </div>
      </div>
      <div class="tab-content">
        <div class="note-ctn">
          <section class="form-ipt ">
            <input
              type="text"
              class="iphon-num"
              placeholder="手机号"
              v-model="form.phone"
            >

            <!-- 发送验证码模块 -->
            <span
              class="validate-code-dv" @click="getYzm"
            >
              <span
                class="btn-validate-code"   
                :class="{'get-vcstatus':!isYzmSend} "
              >
              {{ ysmTips}}
              </span>
            </span>
            <!-- 发送验证码模块__end -->

          </section>
          <section class="form-ipt">
            <input
              type="text"
              class="check-num"
              maxlength="6"
              placeholder="验证码"
              v-model="form.yzm"
            >
          </section>
        </div>
      </div>
    </div>
    <div class="warn-tip">温馨提示:未注册饿了么账号的手机号，登录时将自动注册，且代表您已同意！
      <a href="">用户服务协议</a>
    </div>
    <div class="btn-login">
      <van-button color="#4cd96f"
        type="info"
        size="large"
        style="border-radius:5px"
        @click="loginfn"
      >登录</van-button>
    </div>

    <div class="about-us">
     关于我们
    </div>

  </div> 
</template>
<script src = "./vm.js"></script>