<style scoped lang="less" src="./vs.less"></style>

<template>
  <div class="homeIndex-ctn" id="homeIndex-container">
    <scrollY ref="scrollY" @change="fchange">
      <!-- 刷新 -->
      <div v-show="isshuX">
        <van-loading size="24px" type="spinner" color="#1989fa">下拉刷新...</van-loading>
      </div>
      <!-- 地址 -->
      <section class="address-stn" ref="addressStn">
        <router-link to="/selectAddress" replace class="address-link">
          <span class="iconfont address-icon1">&#xe62e;</span>
          <span class="address-txt">{{"万福中心"}}</span>
          <span class="iconfont address-icon2">&#xe623;</span>
        </router-link>
      </section>
      <!-- 地址__end -->

      <!-- 搜索模块 -->

      <section class="search-stn">
        <section class="search-inner-fixed" ref="searchctn">
          <div class="search-inner">
             <router-link to="/search" >
            <span class="iconfont">&#xe620;</span>
            <span class="search-tips">搜索饿了么商家、商品名称</span>
            </router-link>
          </div>
        </section>
        <section class="clone-search-inner"></section>
      </section>
      <!-- 搜索模块_end -->

      <!-- 幻灯片模块_start -->
      <bannerSlider ref="banner" :bannerList="bannerlist"></bannerSlider>
      <!-- 幻灯片模块__end -->

      <!-- 手势菜单模块———start -->
      <bannermenu>   </bannermenu>
      <!-- 手势菜单模块———end -->

      <!-- 套餐模块 -->
      <section class="set-meal-stn">
        <a href class="set-meal-link clear">
          <div class="sm-content">
            <div class="sm-tip1">品质套餐</div>
            <div class="sm-tip2">搭配齐全配得好</div>
            <div class="sm-tip3">立即抢购 >></div>
          </div>

          <section class="sm-img">
            <img src="/static/images/setMeal.png" />
          </section>
        </a>
      </section>
      <!-- 套餐模块_end -->

      <!-- 商家列表模块 -->
      <restaurantList :list="restaurantdataList"></restaurantList>

      <!-- 商家列表模块__end -->
    </scrollY>
  </div>
</template>
<script src = "./vm.js"></script>