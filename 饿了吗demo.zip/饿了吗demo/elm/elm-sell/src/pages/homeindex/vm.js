import restaurantList from "components/restaurantList";
import bannerSlider from "components/bannerSlider";
import bannermenu from "components/bannermenu";
import axios from "axios";

//导入模拟数据
require("mock/homeindex.js");
//上拉加载更多组件
import scrollY from "components/scrollY";


export default {
    name: '',
    props: {},
    data() {
        return {
         //是否在加载数据
         
         isLoading: false,
         bannerlist:[],
         restaurantdataList:[],
          isshuX: false
        };
    },
    components: {
      bannermenu,
      bannerSlider,
      restaurantList,
      scrollY,
     
    },
    created() { },
    //监听器
    watch:{

    },
    //计算属性
    computed: {

    // 翻转字符串
    reserveMsg(){
    
    }


    },
   async mounted() {
     await this.getBannerS();
     await  this.getSellerList();
       //调用组件中公开的方法
       this.$refs.scrollY.fire();
    },
    methods: {
    
     fchange(value){
         
    
// ---------------------------------------------------------
      //下拉刷新
      if (value > 30) {
        this.isshuX = true;
        setTimeout(() => {
            this.isshuX = false;
            this.$router.go(0);
        }, 1000);
    }
// ---------------------------------------------------------------

    //  ----------------------------------------------------------------
     //获取容器的高度
     if(this.isLoading){
         return;
     }
     
     //滚动的距离
     let targetHeight = this.$refs.scrollY.getMinHeight();
      // console.log(targetHeight);
            //差值的范围：100
      let cha = Math.abs(targetHeight) - Math.abs(value);
     if(cha>100){
         return;
     }
     console.log("开始加载数据...")


            this.isLoading=true;
            setTimeout(()=>{
            this.getSellerList().then(()=>{
            this.isLoading=false;
            console.log("数据加载完毕！");
            this.$nextTick(()=>{
                this.$refs.scrollY.setMin();
            })
          });
          },500);
     },   
    //  -----------------------------------------------------------------------
   async  getBannerS(){

    return new Promise((resolve,reject)=>{
       //请求验证码接口
       setTimeout(() => {
        axios.post('/getBannerimgs',{
        }).then(res => {
         this.bannerlist= res.data.data.banner
        resolve();
        })
        .catch(error => {
            console.log(error);
            reject(error);
        });
       },1000);
          
    });
       
     },
      /**
         * 获取商家列表数据
         */
      async getSellerList() {
        return new Promise((resolve,reject)=>{
          setTimeout(() => {
              //请求验证码接口
              axios.post('/getSellers', {}).then(res => {
                  this.restaurantdataList.push(...res.data.data.items);
                  resolve(); 
              }).catch(error => {
                  console.log(error);
                  reject();
              });
          },500);
        });
      }
    }
}; 