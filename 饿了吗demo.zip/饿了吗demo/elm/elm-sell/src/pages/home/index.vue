<style scoped lang="less" src="./vs.less"></style>
<template>
  <div
    class="app-entry-ctn"
    id="app-entry-container"
    ref="apEntry"
  >

    <div class="app-entry-rv-ctn">
      <router-view></router-view>
    </div>

    <footerMenu></footerMenu>

  </div>

</template>
<script src = "./vm.js"></script>