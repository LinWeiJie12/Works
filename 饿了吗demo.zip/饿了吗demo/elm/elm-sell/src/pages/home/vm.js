import footerMenu from "components/footerMenu";

export default {
    name: '',
    props: {},
    data() {
        return {

        };
    },
    components: {
        footerMenu
    },
    created() { },
    //监听器
    watch: {

    },
    //计算属性
    computed: {

    },
    mounted() {

    },
    methods: {

    }
};