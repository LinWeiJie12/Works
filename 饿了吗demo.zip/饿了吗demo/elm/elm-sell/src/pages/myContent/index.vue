<style scoped lang="less" src="./vs.less"></style>
<template>
  <div
    class="selectAddress"
    id="selectAddress"
  >
   
   <div class="toux">
      <span>头像</span>

      <img src="./头像.jpg" alt="">

      <div class="jt">
      <img src="./左箭头.png" alt="">
      </div>
   </div>
  

    <div class="yonhm">
      <span>用户名</span>
        <p>林伟杰</p>
      <div class="jt">
      <img src="./左箭头.png" alt="">
      </div>
   </div>
    

    <div class="zhbd">
    <span>账号绑定</span>
    </div>
    
    <div class="phone">
      <span>手机</span>
        <p>186*****620</p>
      <div class="jt">
      <img src="./左箭头.png" alt="">
      </div>
   </div>

    <div class="setup">
    <span>安全设置</span>
    </div>

     <div class="safety">
      <span>登录密码</span>
        <p>修改</p>
      <div class="jt">
      <img src="./左箭头.png" alt="">
      </div>
   </div>
     
      <div class="tuichu">
        <span @click=" onclick">退出登录</span>
      </div>

  </div>
</template>
<script src = "./vm.js"></script>