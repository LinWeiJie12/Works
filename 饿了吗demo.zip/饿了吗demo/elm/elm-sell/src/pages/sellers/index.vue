<style scoped lang="less" src="./vs.less"></style>
<template>
  <div class="sellers" id="sellers">
    <scrollY ref="scrollY3">
      <div class="msg">
        <p>配送信息</p>
        <p>由商家配送提供配送，约40分钟送达，距离1.9km</p>
        <p>配送费￥0</p>
      </div>
      <div class="services">
        <p>商家服务</p>
        <p>
          <span>保</span>该商户食品安全已由国泰产险承担，食品安全有保障
        </p>
      </div>
      <div class="img">
        <p>商家实景</p>
        <div class="box">
          <img src="/static/images/userfoos/3.jpg" alt />
          <span>大堂</span>
        </div>
        <div class="box">
          <img src="/static/images/userfoos/4.jpg" alt />
          <span>门面</span>
        </div>
        <div class="box">
          <img src="/static/images/userfoos/6.jpg" alt />
          <span>客厅</span>
        </div>
        <div class="x"></div>
      </div>
      <div class="sellermsg">
        <p>商家信息</p>
        <p>暂无简介</p>
        <p>
          品类
          <span>奶茶果汁，甜品</span>
        </p>
        <p>
          商家电话
          <i></i>
          <span>联系商家</span>
        </p>
        <p>
          地址
          <span>闽侯县上街镇大学城科技路1号福建师范大学旗山校区校内文化街133B号店铺</span>
        </p>
        <p>
          营业时间
          <span>10:50-22:00</span>
        </p>
      </div>
      <div class="foot">
        <p>营业资质</p>
      </div>
    </scrollY>
  </div>
</template>
<script src = "./vm.js"></script>