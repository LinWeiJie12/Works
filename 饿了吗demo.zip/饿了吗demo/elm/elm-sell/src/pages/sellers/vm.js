// import { mapActions } from "vuex";
// import { tool } from "commonJs/tool";
// import { Toast } from "vant";
// import axios from "axios";

//导入模拟数据
// require("mock/login.js");
//上拉加载更多组件
import scrollY from "components/scrollY";

export default {
    name: ''
    , props: {}
    , data() {
        return {


        }
    }
    , components: {
        scrollY
    }
    , watch: {}
    , computed: {}
    , mounted() {
        setTimeout(() => {
            this.$nextTick(() => {
                //当数据加载完，初始化scollY
                this.$refs.scrollY3.fire();
            })
        }, 1000);

    }
    , methods: {}

}
