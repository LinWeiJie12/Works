export default {
    name: '',
    props: {},
    data() {
        return {
          
        };
    },
    components: {},
    created() { },
    //监听器
    watch: {

    },
    //计算属性
    computed: {

    },
    mounted() {

    },
    methods: {

    }
};