<style scoped lang="less" src="./vs.less"></style>
<template>
  <div
    class="searchaddress"
    id="searchaddress"
  >
定位失败！！！！！！！！！
  



  </div>

</template>
<script src = "./vm.js"></script>