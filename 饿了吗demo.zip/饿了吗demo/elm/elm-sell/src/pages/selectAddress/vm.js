import footerMenu from "components/footerMenu";

export default {
  name: '',
  props: {},
  data() {
    return {
      // active: 0,
      value: '请输入地址',
      chosenAddressId: '1',
      // list: [
      //   {
      //     id: '1',
      //     name: '林伟杰',
      //     tel: '13015151515',
      //     address: '福建省福州市闽侯县高新区万福中心'
      //   },
      //   {
      //     id: '2',
      //     name: '吴菲菲',
      //     tel: '18156131555',
      //     address: '福建省福州市闽侯县高新区高新苑'
      //   }
      // ],
      // disabledList: [
      //   {
      //     id: '3',
      //     name: '王五',
      //     tel: '1320000000',
      //     address: '浙江省杭州市滨江区江南大道 15 号'
      //   }
      // ]
     
      chosenContactId: null,
      editingContact: {},
      showList: false,
      showEdit: false,
      isEdit: false,
      list: [{
        name: '林伟杰',
        tel: '18650743620',
        id: 0,
      }]

    };
  },
  components: {
    footerMenu
  },
  created() { },
  //监听器
  watch: {

  },
  //计算属性
  computed: {
    cardType() {
      return this.chosenContactId !== null ? 'edit' : 'add';
    },
    currentContact() {
      const id = this.chosenContactId;
      return id !== null ? this.list.filter(item => item.id === id)[0] : {};
    }
  
  },
  mounted() {

  },
  methods: {
    //返回首页
    onClickLeft() {
      this.$router.push({ name: `homeindex` })
    },
    onClickRight() {
      Toast('按钮');
    },
    onSearch() {
      Toast('按钮');

    },
    
    // -----------------------------
     // 添加联系人
     onAdd() {
      this.editingContact = { id: this.list.length };
      this.isEdit = false;
      this.showEdit = true;
    },

    // 编辑联系人
    onEdit(item) {
      this.isEdit = true;      
      this.showEdit = true;
      this.editingContact = item;
    },

    // 选中联系人
    onSelect() {
      this.showList = false;
    },

    // 保存联系人
    onSave(info) {
      this.showEdit = false;
      this.showList = false;
      
      if (this.isEdit) {
        this.list = this.list.map(item => item.id === info.id ? info : item);
      } else {
        this.list.push(info);
      }
      this.chosenContactId = info.id;
    },
    


    // 删除联系人
    onDelete(info) {
      this.showEdit = false;
      this.list = this.list.filter(item => item.id !== info.id);
      if (this.chosenContactId === info.id) {
        this.chosenContactId = null;
      }
    }
  


  }
};