<style scoped lang="less" src="./vs.less"></style>
<template>
  <div
    class="selectAddress"
    id="selectAddress"
  >
    <!-- 顶部导航栏 -->
    <van-nav-bar
      title="选择收货地址"
      left-text="返回"
      right-text="新增地址"
      left-arrow
      @click-left="onClickLeft"
      @click-right="onClickRight"
    />
   <!-- 顶部导航栏 -->

     <!-- 地址搜索 -->
     
    <van-search
       label="福州"
      v-model="value"
      placeholder="请输入搜索关键词"
      show-action
      shape="round"
      @search="onSearch"
    >
   
      <div slot="action" @click="onSearch">搜索</div>
    </van-search>
    <!-- 地址搜索 -->

    <div class="newaddress">当前地址</div>

    <div class="address"><p>万福中心</p>
    <img src="/static/images/img/定位.png" alt="">
     <router-link to="/searchaddress" replace class="address-link">
   <div class="location">重新定位</div>
   </router-link>
    </div>
  

    <div class="newaddress">收货地址</div>


    
    <!-- 选择收货地址 -->
     <!-- 联系人卡片 -->
<van-contact-card
  :type="cardType"
  :name="currentContact.name"
  :tel="currentContact.tel"
  @click="showList = true"
/>

<!-- 联系人列表 -->
<van-popup v-model="showList" position="bottom">
  <van-contact-list
  
    v-model="chosenContactId"
    :list="list"
    @add="onAdd"
    @edit="onEdit"
    @select="onSelect"
  />
</van-popup>

<!-- 联系人编辑 -->
<van-popup v-model="showEdit" position="bottom">
  <van-contact-edit
    :contact-info="editingContact"
    :is-edit="isEdit"
    @save="onSave"
    @delete="onDelete"
  />
</van-popup>
    <!-- 选择收货地址 -->
   
<!-- ------------------------------------- -->
     <router-view></router-view>
<!-- ------------------------------------- -->

<!-- 底栏标签 -->
    <footerMenu></footerMenu>
   <!-- <van-tabbar v-model="active">
  <van-tabbar-item icon="home-o">标签</van-tabbar-item>
  <van-tabbar-item icon="search">标签</van-tabbar-item>
  <van-tabbar-item icon="friends-o">标签</van-tabbar-item>
  <van-tabbar-item icon="setting-o">标签</van-tabbar-item>
   </van-tabbar> -->
<!-- 底栏标签 -->
      
  </div>
   
</template>
<script src = "./vm.js"></script>