<style scoped lang="less" src="./vs.less"></style>
<template>
  <div
    class="discovery"
    id="discovery"
  >
    <h1>发现页面！</h1>
  </div>

</template>
<script src = "./vm.js"></script>