import { mapGetters, mapState, mapMutations, mapActions } from "vuex";
import * as types from 'vuexStore/mutation-types.js'
import sellersDetailsHeader from "components/sellersDetailsHeader";
import shopcart from "components/shopcart";
import axios from "axios";
//导入模拟数据
require("mock/sellersDetails.js");
import { Toast } from 'vant';

export default {
    name: '',
    props: {},
    data() {
        return {
            rsid:""
        };
    },
    components: {
        sellersDetailsHeader,
        shopcart
    },
    created() { },
    //监听器
    watch: {

    },
    //计算属性
    computed: {

    },
    mounted() {
        this.getSellerDetails();
    },

    methods: {
        ...mapMutations([types.SET_SELLERINFO]),
        //返回首页
        gobackfn(){
            this.$router.push({name:`homeindex`})
        },
        //获取商家详情
        getSellerDetails(){
            Toast.loading({
                duration: 0, // 持续展示 toast
                forbidClick: true,
                message: '数据加载中....'
        });


        setTimeout(() => {
            return new Promise((resolve, reject) => {
                //请求验证码接口
                axios.post('/getSellerInfoById', {
                    id: this.$route.query.id
                }).then(res => {
                   console.log(res);
                   this[types.SET_SELLERINFO](res.data.seller);
                    Toast.clear();
                    resolve();
                }).catch(error => {
                    console.log(error);
                    reject();
                });
            });

        }, 1000);

      

    }
  }
};