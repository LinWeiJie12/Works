<style scoped lang="less" src="./vs.less"></style>
<template>
  <div
    class="sellerDetails-ctn"
    id="sellerDetails-container"
  >
   <div
      class="goback-btn"
      @click="gobackfn"
    >
      <img src="./img/返回123.png" alt="" >
    </div>

    <!-- 头部组件 -->
<sellersDetailsHeader></sellersDetailsHeader>
  <!-- 头部组件 -->

 <!-- 导航模块 -->
    <div class="tab border-1px">
      <div class="tab-item">
        <router-link to="/sellerDetails/goods">商品</router-link>
      </div>
      <div class="tab-item">
        <router-link
          to="/sellerDetails/ratings"
          class=""
        >评论</router-link>
      </div>
      <div class="tab-item">
        <router-link
          to="/sellerDetails/sellers"
          class=""
        >商家</router-link>
      </div>
    </div>
    <!-- 导航模块__end -->

    <!-- 子视图 -->
    <div class="app-entry-rv-ctn">
      <transition name="go">
        <keep-alive>
          <router-view></router-view>
        </keep-alive>
      </transition>
    </div>
    <!-- 子视图__end -->

     <!-- 购物车模块 -->

    <shopcart></shopcart>

      <!-- 购物车模块 -->
  </div>

</template>
<script src = "./vm.js"></script>