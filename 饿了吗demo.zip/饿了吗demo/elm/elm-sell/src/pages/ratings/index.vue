<style scoped lang="less" src="./vs.less"></style>
<template>
  <div class="rat">
    <scrollY ref="scrollY2" @change="fchange1">
      <div class="ratings" id="ratings">
        <!-- 评分区域 -->

        <!-- 商家评分 -->
        <div class="sellertext">
          <div class="text">
            <p>{{sellertext.food_score}}</p>
            <i>商家评分</i>
            <stars :starsWidth="starsWidth" class="xing"></stars>
          </div>
        </div>
        <div class="sellerT">
          <div class="w">
            <p>味道</p>
            <p>{{sellertext.overall_score}}</p>
          </div>
          <div class="b">
            <p>包装</p>
            <p>{{sellertext.package_score}}</p>
          </div>
          <div class="p">
            <p>配送</p>
            <p>{{sellertext.rider_score}}</p>
          </div>
        </div>
        <div class="xx"></div>
        <!-- 商家评分 _end-->
        <!-- 评论 -->
        <div class="usertext">
          <div class="category">
            <div>全部30003</div>
            <div>最新12</div>
            <div>好评122</div>
            <div>差评122</div>
            <div>有图122</div>
            <div>味道好122</div>
            <div>送货慢12</div>
          </div>
          <div class="text" v-for="item in textList">
            <div class="photo">
              <img :src="item.img" />
            </div>
            <div class="name">{{item.username}}</div>
            <stars :starsWidth="item.rating"></stars>
            <span>满意</span>
            <div class="time">{{item.rated_at}}</div>
            <div class="counten">{{item.rating_text}}</div>
            <div class="sller-counten" v-if="item.reply.content">{{item.reply.content}}</div>
            <div class="text-img">
              <img :src="item.img1" />
            </div>
          </div>
        </div>
      </div>
    </scrollY>
  </div>
</template>
<script src = "./vm.js"></script>