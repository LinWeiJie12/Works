// import { mapActions } from "vuex";
// import { tool } from "commonJs/tool";
// import { Toast } from "vant";
// import axios from "axios";

//上拉加载更多组件
import scrollY from "components/scrollY";
//导入模拟数据

// require("mock/login.js");
import stars from "components/stars";
import axios from "axios";
//导入模拟数据
require("mock/ratings.js");


export default {
    name: ''
    , props: {}
    , data() {
        return {
            starsWidth: '4'
            , textList: []
            , sellertext: []
            , count: []
        }
    }
    , components: {
        stars
        , scrollY
    }
    , watch: {}
    , computed: {}
    , async mounted() {
        await this.getSellerText();
        await this.getUserText();
        this.$nextTick(() => {
            this.$refs.scrollY2.fire();
        });


    }
    , methods: {
        fchange1() {

        }
        /**
         * 获取用户评论
         */
        , async getUserText() {
            return new Promise((resolve, reject) => {

                setTimeout(() => {

                    axios.post('/comments', {

                    }).then(res => {


                        this.textList = res.data.data


                        resolve();
                    }).catch(error => {
                        console.log(error);
                        console.log("服务异常，请联系管理员!");
                        reject();
                    });
                }, 2000);

            });
        }

        /**
         * 商家评分和评论总数
         */
        , async getSellerText() {
            return new Promise((resolve, reject) => {

                setTimeout(() => {

                    axios.post('/sellerRa', {

                    }).then(res => {

                        console.log(res.data.data.tags);
                        this.sellertext = res.data.data.rating
                        this.count = res.data.data

                        resolve();
                    }).catch(error => {
                        console.log(error);
                        console.log("服务异常，请联系管理员!");
                        reject();
                    });
                }, 500);

            });
        }
    }

}
