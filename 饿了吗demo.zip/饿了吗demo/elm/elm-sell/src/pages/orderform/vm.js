import axios from "axios";
//导入模拟数据
require("mock/orderform.js");
//上拉加载更多组件
import scrollY from "components/scrollY";


export default {
    name: '',
    props: {},
    data() {
        return {
            orderFormlist:[],
            isshuX: false
        };
    },
    components: {

      scrollY
    },
    created() { },
    //监听器
    watch: {

    },
    //计算属性
    computed: {
      
    },
   async mounted() {
      
  

      
      await this.orderFormList();
      setTimeout(() => {
        this.$nextTick(() => {
          //调用组件中公开的方法
          this.$refs.scrollY.fire();
        });


      }, 500);
     

    },
    methods: {
        
      fchange(value){
        //下拉刷新
     if (value > 30) {
       this.isshuX = true;
       setTimeout(() => {
           this.isshuX = false;
           this.$router.go(0);
       }, 1000);
       }
  
     },

      
        /**
         * 获取订单列表数据
         */
        async orderFormList() {
            return new Promise((resolve, reject) => {
              setTimeout(() => {
                //请求验证码接口
                axios.post('/getOrderForm', {
                }).then(res => {
                  console.log(res);
                  this.orderFormlist = res.data.data;
                  console.log(this.orderFormlist);
                  
                  // console.log(this.bannerlist);
                  // console.log(`服务返回的数据：${res.data.msg}`);
                  resolve()
                }).catch(error => {
                  console.log(error);
                  console.log("服务异常，请联系管理员!");
                  reject();
                });
              }, 1000);
            })
      
          },
        
    }
};