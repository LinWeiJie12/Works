<style scoped lang="less" src="./vs.less"></style>
<template>
  <div class="orderform" id="orderform">
    <!-- 刷新 -->
      <div v-if="isshuX" >
        <van-loading size="24px" type="spinner" color="#1989fa">下拉刷新...</van-loading>
      </div>
    <scrollY ref="scrollY"  @change="fchange">
      <div class="abc">
        <div class="orderformlist" v-for="item in orderFormlist">
          <section class="ordertitle">
            <div class="orderimg">
              <img :src="item.img" />
            </div>

            <div class="ordername">
              <span class="spanname">
                {{item.restaurant_name}}
                <span class="spantitle">{{item.formatted_created_at}}</span>
              </span>
              <div class="jt">
                <img src="./img/左箭头.png" alt />
              </div>

              <div class="dingdan">{{'订单已送达'}}</div>
            </div>
          </section>

          <section class="ordercont">
            <span class="spanname1">{{item.restaurant_food}}</span>
            <span class="spanmoney">{{'￥'}}{{item.total_amount}}</span>
          </section>

          <section class="anniu">
            <button class="leftbtn">
              <span>再来一单</span>
            </button>
            <button class="rightbtn">
              <span>评价得金币</span>
            </button>
          </section>
          <div class="foot"></div>
        </div>
      </div>
    </scrollY>
  </div>
</template>
<script src = "./vm.js"></script>